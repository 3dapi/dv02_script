//
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif


#include <stdio.h>

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>


lua_State* g_pL;


int		McLua_DoFile(lua_State*, char*);
void	McCrp_BufEncryption(char* sBuf, int iBuf, char* sPwd);
void	McCrp_BufDecryption(char* sBuf, int iBuf, char* sPwd);


void main()
{
	printf("LUA Execute Script File and Load.\n\n");

	g_pL = lua_open();

	// load Lua libraries
	luaL_openlibs(g_pL);


	char	sScirptFile[] = "script/enc.lua";

	McLua_DoFile(g_pL, sScirptFile);

	
	
	
	
	double result = lua_tonumber(g_pL, lua_gettop(g_pL));
	lua_pop(g_pL, 1);

	printf("The result was: %lf\n", result);
	


	lua_close(g_pL);
}


#include <stdlib.h>
#include <string.h>

int McLua_DoFile(lua_State* pL, char* sFile)
{
	long iBuf=0;
	char* sBuf = NULL;
	FILE* fp = fopen(sFile, "r");

	if(NULL ==fp)
		return -1;
	
	// ������ ���̸� �о�´�.
	fseek(fp, 0, SEEK_END);
	iBuf = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	// ������ ���� ��ŭ �޸𸮸� �����ϰ� �о� �´�.
	sBuf = (char*)malloc(iBuf);
	memset(sBuf, 0, iBuf);
	fread(sBuf, 1, iBuf, fp);
	fclose(fp);


	// ���� ������ ��ȣȭ �Ǿ��ٸ� ���⼭ ��ȣȭ�� �õ��Ѵ�.

	const char sPwd[]="My First Enc";
	McCrp_BufEncryption(sBuf, iBuf, (char*)sPwd);
	

	while(1)
	{
		if( '\n' == sBuf[iBuf-1] ||
			'\r' == sBuf[iBuf-1] ||
			'\0' == sBuf[iBuf-1] ||
			'\t' == sBuf[iBuf-1] ||
			' ' == sBuf[iBuf-1])
			--iBuf;
		else
			break;
	}

	// ��ƿ� �÷� ���´�.
	lua_dobuffer(pL, sBuf, iBuf , sBuf);

	// ����� �޸𸮸� �����Ѵ�.
	free(sBuf);

	return 1;
}



void McCrp_BufEncryption(char* sBuf, int iBuf, char* sPwd)
{
	int iLen = strlen(sPwd)-1;

	for(int i=0; i<iBuf; ++i)
	{
		sBuf[i] ^=sPwd[i%iLen];
	}
}


void McCrp_BufDecryption(char* sBuf, int iBuf, char* sPwd)
{
	int iLen = strlen(sPwd)-1;

	for(int i=0; i<iBuf; ++i)
	{
		sBuf[i] ^=sPwd[i%iLen];
	}
}