//
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>
#include <wincrypt.h>


void McCrp_BufEncryption(char* sBuf, int iBuf, char* sPwd)
{
	int iLen = strlen(sPwd)-1;

	for(int i=0; i<iBuf; ++i)
	{
		sBuf[i] ^=sPwd[i%iLen];
	}
}


void McCrp_BufDecryption(char* sBuf, int iBuf, char* sPwd)
{
	int iLen = strlen(sPwd)-1;

	for(int i=0; i<iBuf; ++i)
	{
		sBuf[i] ^=sPwd[i%iLen];
	}
}



void main()
{
	char sFileSrc[] ="../script/sample.lua";
	char sFileDst[] ="../script/enc.lua";


	long iBuf=0;
	char* sBuf = NULL;
	FILE* fp=NULL;


	fp = fopen(sFileSrc, "rb");

	if(NULL ==fp)
	{
		printf("File open Error\n");
		return ;
	}
	
	// ������ ���̸� �о�´�.
	fseek(fp, 0, SEEK_END);
	iBuf = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	sBuf = (char*)malloc(iBuf);
	memset(sBuf, 0, iBuf);
	fread(sBuf, 1, iBuf, fp);
	fclose(fp);



	const char sPwd[]="My First Enc";
	McCrp_BufEncryption(sBuf, iBuf, (char*)sPwd);


	fp = fopen(sFileDst, "wb");

	if(NULL ==fp)
	{
		printf("File open Error\n");
		return ;
	}


	fwrite(sBuf, 1, iBuf, fp);
	fclose(fp);

	free(sBuf);
}


