

#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>



struct NumArray
{
	int		size;
	double	values[1];
};

static int	Mcl_ArrNew(lua_State*);
static int	Mcl_ArrSet(lua_State*);
static int	Mcl_ArrGet(lua_State*);
static int	Mcl_ArrSize(lua_State*);
static int	LuaOpenLib(lua_State *pL);


static NumArray *checkarray (lua_State *L)
{
	void *ud = luaL_checkudata(L, 1, "LcLua.array");
	luaL_argcheck(L, ud != NULL, 1, "'array' expected");
	return (NumArray *)ud;
}

static int	Mcl_ArrNew(lua_State *L)
{
	int n = luaL_checkint(L, 1);
	size_t nbytes = sizeof(NumArray) + (n - 1)*sizeof(double);
	NumArray *a = (NumArray *)lua_newuserdata(L, nbytes);		// lua_newuserdata �Լ��� �����͸� push�� ���� �޸� �ּ� ��ȯ(���������� api_incr_top(L); �� ȣ��)

	luaL_getmetatable(L, "LcLua.array");
	lua_setmetatable(L, -2);

	a->size = n;
	return 1;  /* new userdatum is already on the stack */
}

static int Mcl_ArrSet(lua_State *L)
{
	NumArray *a = (NumArray *)lua_touserdata(L, 1);
	int		index = luaL_checkint(L, 2);
	double	value = luaL_checknumber(L, 3);

	luaL_argcheck(L, a != NULL, 1, "array expected");
	luaL_argcheck(L, 1 <= index && index <= a->size, 2, "index out of range");

	a->values[index-1] = value;
	return 0;
}

static int Mcl_ArrGet(lua_State *L)
{
	NumArray *a = (NumArray *)lua_touserdata(L, 1);
	int index = luaL_checkint(L, 2);

	luaL_argcheck(L, a != NULL, 1, "array expected");
	luaL_argcheck(L, 1 <= index && index <= a->size, 2, "index out of range");

	lua_pushnumber(L, a->values[index-1]);
	return 1;
}

static int Mcl_ArrSize(lua_State* L)
{
	NumArray *a = checkarray(L);
	lua_pushnumber(L, a->size);
	return 1;

}

static const struct luaL_reg ArrLib [] =
{
	{"new"	,	Mcl_ArrNew},
	{"set"	,	Mcl_ArrSet},
	{"get"	,	Mcl_ArrGet},
	{"size"	,	Mcl_ArrSize},
	{NULL, NULL}
};



int LuaOpenLib(lua_State *L)
{
	luaL_newmetatable(L, "LcLua.array");
	luaL_openlib(L, "array", ArrLib, 0);

	return 1;
}


lua_State* g_pL;


void  main()
{
	g_pL = lua_open();

	luaL_openlibs(g_pL);

	LuaOpenLib(g_pL);

	luaL_dofile(g_pL, "Script.lua");

	lua_close(g_pL);
}


