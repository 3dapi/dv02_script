-- Simple LUA Program

function add ( x, y )
	return x + y
end


function sub ( x, y )
	return x - y
end


function mul ( x, y )
	return x * y
end


function div ( x, y )
	return x / y
end



function ReturnFunction(x, y )
	var1 = add ( x, y )

	print ('add', var1)

	var2 = sub ( x, y )

	print ('sub', var2)

	return var1 * var2
end