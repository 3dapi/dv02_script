

#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif


#include <stdio.h>

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>



lua_State* g_pL;

void main()
{
	double rst;
	int	iFrst=41;
	int	iScnd=22;

	printf("Calling User Define Lua Function in C Code\n");

	g_pL = lua_open();
	
	// load Lua libraries
	luaL_openlibs(g_pL);


	luaL_dofile(g_pL, "script/math.lua");
	

	printf("Input value: %d, %d\n\n", iFrst, iScnd);

	// the function name
	lua_getglobal(g_pL, "add");

	// the first argument
	lua_pushnumber(g_pL, iFrst );

	// the second argument
	lua_pushnumber(g_pL, iScnd );

	// call the function with 2 arguments, return 1 result
	lua_call(g_pL, 2, 1);

	// get the result
	rst = lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	printf( "The result is %lf\n", rst );




	lua_getglobal(g_pL, "sub");
	lua_pushnumber(g_pL, iFrst );
	lua_pushnumber(g_pL, iScnd );
	lua_call(g_pL, 2, 1);

	rst = lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	printf( "The result is %lf\n", rst );






	lua_getglobal(g_pL, "mul");
	lua_pushnumber(g_pL, iFrst );
	lua_pushnumber(g_pL, iScnd );
	lua_call(g_pL, 2, 1);

	rst = lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	printf( "The result is %lf\n", rst );



	lua_getglobal(g_pL, "div");
	lua_pushnumber(g_pL, iFrst );
	lua_pushnumber(g_pL, iScnd );
	lua_call(g_pL, 2, 1);

	rst = lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	printf( "The result is %lf\n", rst );



	printf( "\n\n\n\n");

	printf("Function Call\n\n");

	// the function name
	lua_getglobal(g_pL, "ReturnFunction");
	lua_pushnumber(g_pL, iFrst );
	lua_pushnumber(g_pL, iScnd );

	lua_call(g_pL, 2, 1);
	rst = lua_tonumber(g_pL, -1);
	
	lua_pop(g_pL, 1);

	printf( "The result is %lf\n", rst );


	lua_close(g_pL);

	printf( "\n");
}