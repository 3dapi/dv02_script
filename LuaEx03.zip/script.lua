-- Simple LUA Program


a = array.new(1000)
print(a)


print(array.size(a))
--print(a:size())     --> 1000
--a:set(10, 3.4)
--c =  a:get(10)
--print(c)			--> 3.4

a[10] = 3.4			-- setarray
c= a[10]
print(c)

c= 200
a[1] = c
print(a[1])			-- getarray   --> 3.4



