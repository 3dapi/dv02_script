// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont		= NULL;
	m_pInput		= NULL;
	m_pSprite		= NULL;

	m_bShowState	= TRUE;
	m_pSoundManager	= NULL;
}



HRESULT CMain::Init()
{
	HRESULT		hr =0;

	m_pInput	= new CMcInput;
	m_pInput->Create(m_hWnd);


	if(FAILED(DsDev_CreateSprite(NULL, &m_pSprite, m_pd3dDevice)))
		return -1;

	// ���� �Ŵ��� ����
	m_pSoundManager = new CSoundManager();
	if( FAILED( hr = g_pApp->m_pSoundManager->Initialize( m_hWnd, DSSCL_PRIORITY ) ) )
		return DXTRACE_ERR( TEXT("m_pSoundManager->Initialize"), hr );

	if( FAILED( hr = g_pApp->m_pSoundManager->SetPrimaryBufferFormat( 2, 22050, 16 ) ) )
		return DXTRACE_ERR( TEXT("m_pSoundManager->SetPrimaryBufferFormat"), hr );
	

	// LuaApi_Init() �Լ� ȣ��
	if(FAILED(LuaApiInit()))
		return -1;


	return S_OK;
}



HRESULT CMain::Destroy()
{
	if(FAILED(LuaApiDestroy()))
		return -1;

	SAFE_DELETE(	m_pSprite	);
	SAFE_DELETE(	m_pInput	);

	SAFE_DELETE( m_pSoundManager );

	return S_OK;
}


HRESULT CMain::Restore()
{
	HRESULT hr=-1;

	if(FAILED( CLuaGlue::Lua_FontRestore()))
		return -1;




	m_pd3dDevice->SetRenderState( D3DRS_FOGENABLE, FALSE);
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE);

	// Create a D3D font using D3DX
	D3DXFONT_DESC hFont =
	{
		16, 0
		, FW_NORMAL
		, 1					// Mip Level
		, FALSE				// Italic
		, HANGUL_CHARSET	// Charset
		, OUT_DEFAULT_PRECIS// Output Precision
		, ANTIALIASED_QUALITY// Qulity
		, FF_DONTCARE		// Pitch And Family
		, "Arial"			// FaceName
	};

	if( FAILED( hr = D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;

	
	return S_OK;
}


HRESULT CMain::Invalidate()
{
	if(FAILED( CLuaGlue::Lua_FontInvalid()))
		return -1;


	SAFE_RELEASE( m_pD3DXFont );
	
	return S_OK;
}


HRESULT CMain::FrameMove()
{
	int hr=0;
	
	// ��ǲ�� �����Ѵ�.
	m_pInput->FrameMove();

	// ��ũ��Ʈ�� �����Ѵ�.
	if(FAILED(LuaApiFrameMove()))
		return -1;
	
	return S_OK;
}





HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL
						, 0xFF006699
						, 1.0f
						, 0L );
	
	if(FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	
	if(FAILED(LuaApiRender()))
		return -1;

	
	if(m_bShowState)
		RenderText();

	m_pd3dDevice->EndScene();
	
	return S_OK;
}




HRESULT CMain::RenderText()
{
	D3DCOLOR fontColor		= D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH]	= TEXT("");
	RECT rc;

	sprintf( szMsg, "%s %s", m_strDeviceStats , m_strFrameStats );

	rc.top		= 1;
	rc.bottom	= rc.top + 20;
	rc.left		= 2;
	rc.right	= m_d3dsdBackBuffer.Width - 20;
	
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, fontColor );
	
	return S_OK;
}





LRESULT CMain::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	WPARAM wHi = HIWORD(wParam);
	WPARAM wLo = LOWORD(wParam);

	if(m_pInput)
		m_pInput->MsgProc(hWnd, uMsg, wParam, lParam);

	switch(uMsg)
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				RECT rc;
				GetClientRect( hWnd, &rc );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, uMsg, wParam, lParam );
}


