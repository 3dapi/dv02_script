// Implementation of the CLuaGlue class.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"

lua_State* g_pL;


int LuaStartUp()
{
	int hr=-1;
	g_pL = lua_open();
	
	// load Lua libraries
	luaL_openlibs(g_pL);

	lua_register(g_pL, "Lua_WindowCreate",	CLuaGlue::Lua_WindowCreate);
	lua_register(g_pL, "Lua_WindowTitle",	CLuaGlue::Lua_WindowTitle);

	lua_register(g_pL, "Lua_MousePos",		CLuaGlue::Lua_MousePos);
	lua_register(g_pL, "Lua_MouseEvnt",		CLuaGlue::Lua_MouseEvnt);

	lua_register(g_pL, "Lua_ShowState",		CLuaGlue::Lua_ShowState);
	lua_register(g_pL, "Lua_ChangeMode",	CLuaGlue::Lua_ChangeMode);

	lua_register(g_pL, "Lua_TextureCreate",	CLuaGlue::Lua_TextureCreate);
	lua_register(g_pL, "Lua_TextureDestroy",CLuaGlue::Lua_TextureDestroy);
	lua_register(g_pL, "Lua_TextureWidth",	CLuaGlue::Lua_TextureWidth);
	lua_register(g_pL, "Lua_TextureHeight",	CLuaGlue::Lua_TextureHeight);
	lua_register(g_pL, "Lua_TextureDraw",	CLuaGlue::Lua_TextureDraw);

	lua_register(g_pL, "Lua_SoundCreate",	CLuaGlue::Lua_SoundCreate);
	lua_register(g_pL, "Lua_SoundDestroy",	CLuaGlue::Lua_SoundDestroy);
	lua_register(g_pL, "Lua_SoundPlay",		CLuaGlue::Lua_SoundPlay);
	lua_register(g_pL, "Lua_SoundStop",		CLuaGlue::Lua_SoundStop);
	

	hr = luaL_dofile(g_pL, "script/_main.lua");
	
	// Scirpt�� �ִ� �Լ� ȣ��
	lua_getglobal(g_pL, "LuaApi_Create");
	lua_call(g_pL, 0, 1);

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 0;
}

void LuaClose()
{
	lua_close(g_pL);
}


int LuaApiInit()
{
	int hr=0;
	lua_getglobal(g_pL, "LuaApi_Init");
	lua_call(g_pL, 0, 1);

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 0;
}


int LuaApiDestroy()
{
	int hr=0;
	lua_getglobal(g_pL, "LuaApi_Destroy");
	lua_call(g_pL, 0, 1);

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 0;
}


int	LuaApiFrameMove()
{
	int hr=0;
	lua_getglobal(g_pL, "LuaApi_FrameMove");
	lua_call(g_pL, 0, 1);

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 0;
}


int LuaApiRender()
{
	int hr=0;
	lua_getglobal(g_pL, "LuaApi_Render");
	lua_call(g_pL, 0, 1);

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 0;
}



int CLuaGlue::Lua_WindowCreate(lua_State* pL)
{
	int		n	= lua_gettop(pL);

	char	sClassName[260]={0};

	if(n<6)
	{
		lua_pushnumber(pL, -1);
		return 1;
	}
	int		ScnX = (int)lua_tonumber(pL, 1);
	int		ScnY = (int)lua_tonumber(pL, 2);
	int		ScnW = (int)lua_tonumber(pL, 3);
	int		ScnH = (int)lua_tonumber(pL, 4);
	
	strcpy(sClassName, (char*)lua_tostring(pL, 5));
	int		nMode= (int)lua_tonumber(pL, 6);


	g_pApp->SetWindowClassName(sClassName);
	g_pApp->SetWindowStartX(ScnX);
	g_pApp->SetWindowStartY(ScnY);
	g_pApp->SetWindowWidth(ScnW);
	g_pApp->SetWindowHeight(ScnH);
	g_pApp->SetWindowStartMode(nMode);
	
	lua_pushnumber(pL, 0);
	return 1;
}


int CLuaGlue::Lua_WindowTitle(lua_State* pL)
{
	HWND hWnd = g_pApp->GetHwnd();

	int		n	= lua_gettop(pL);

	char	sMsg[1024]={0};

	strcpy(sMsg, (char*)lua_tostring(pL, 1));
	SetWindowText(hWnd, sMsg);
	return 0;
}


int CLuaGlue::Lua_MousePos(lua_State* pL)
{
	D3DXVECTOR3	v = g_pApp->m_pInput->GetMousePos();
	lua_pushnumber(pL, v.x);
	lua_pushnumber(pL, v.y);
	lua_pushnumber(pL, v.z);

	return 3;
}


int CLuaGlue::Lua_MouseEvnt(lua_State* pL)
{
	lua_pushnumber(pL, g_pApp->m_pInput->BtnState(0) );
	lua_pushnumber(pL, g_pApp->m_pInput->BtnState(1) );
	lua_pushnumber(pL, g_pApp->m_pInput->BtnState(2) );

	return 3;
}


int	CLuaGlue::Lua_ShowState(lua_State* pL)
{
	int		n = lua_gettop(pL);

	if(n<1)
	{
		g_pApp->m_bShowState = FALSE;
		return 0;
	}

	g_pApp->m_bShowState = (INT)lua_tonumber(g_pL, 1);
	return 0;
}


int	CLuaGlue::Lua_ChangeMode(lua_State* pL)
{
	g_pApp->ToggleFullscreen();
	return 0;
}





int CLuaGlue::Lua_TextureCreate(lua_State* pL)
{
	int		n	= lua_gettop(pL);

	char	sFile[MAX_PATH]={0};

	strcpy(sFile, (char*)lua_tostring(pL, 1));

	LPDSTEXTURE	p		= NULL;
	DWORD		dMip	= 1;
	DWORD		dFilter	= D3DX_FILTER_NONE;
	DWORD		dColorKey= 0x00FFFFFF;

	if(FAILED(DsDev_CreateTexture("File", &p, g_pApp->GetDevice(), sFile, &dMip, &dFilter, &dColorKey)))
	{
		lua_pushnumber(pL, 0);
		return 1;
	}

	DWORD	d = (DWORD)p;
	lua_pushnumber(pL, d);
	return 1;
}

int CLuaGlue::Lua_TextureDestroy(lua_State* pL)
{
	int		n	= lua_gettop(pL);
	DWORD	d	= (DWORD)lua_tonumber(pL, 1);

	LPDSTEXTURE	p = (LPDSTEXTURE)d;
	
	if(p)
		delete p;
	
	return 0;
}

int	CLuaGlue::Lua_TextureWidth(lua_State* pL)
{
	int		n	= lua_gettop(pL);
	DWORD	d	= (DWORD)lua_tonumber(pL, 1);

	LPDSTEXTURE	p = (LPDSTEXTURE)d;
	
	if(!p)
	{
		lua_pushnumber(pL, 0);
		return 1;
	}
	
	int		v = p->GetImageWidth();

	lua_pushnumber(pL, v);
	return 1;
}


int	CLuaGlue::Lua_TextureHeight(lua_State* pL)
{
	int		n	= lua_gettop(pL);
	DWORD	d	= (DWORD)lua_tonumber(pL, 1);

	LPDSTEXTURE	p = (LPDSTEXTURE)d;
	
	if(!p)
	{
		lua_pushnumber(pL, 0);
		return 1;
	}
	
	int		v = p->GetImageHeight();

	lua_pushnumber(pL, v);
	return 1;
}


int CLuaGlue::Lua_TextureDraw(lua_State* pL)
{
	int		n	= lua_gettop(pL);
	DWORD	d	= (DWORD)lua_tonumber(pL, 1);

	LPDSTEXTURE	p = (LPDSTEXTURE)d;
	
	if(!p)
		return 0;

	RECT		rc;
	D3DXVECTOR2	vcP(0,0);
	D3DXVECTOR2	vcS(1,1);

	p->GetImageRect(&rc);

	rc.left		= (LONG)lua_tonumber(pL, 2);
	rc.top		= (LONG)lua_tonumber(pL, 3);
	rc.right	= (LONG)lua_tonumber(pL, 4);
	rc.bottom	= (LONG)lua_tonumber(pL, 5);
	
	vcP.x		= (FLOAT)lua_tonumber(pL, 6);
	vcP.y		= (FLOAT)lua_tonumber(pL, 7);		
	
	g_pApp->m_pSprite->Draw(p, &rc, &vcS, &vcP, D3DXCOLOR(1,1,1,1));
	
	return 0;
}




int CLuaGlue::Lua_SoundCreate(lua_State* pL)
{
	int			n = lua_gettop(pL);
	CSound*		p = NULL;
	
	char	sFile[MAX_PATH]={0};

	strcpy(sFile, (char*)lua_tostring(pL,1));

	if(FAILED(g_pApp->m_pSoundManager->Create( &p, sFile, 0, GUID_NULL, 5 )))
	{
		lua_pushnumber(pL, 0);
		return 1;
	}

	DWORD	d = (DWORD)p;
	lua_pushnumber(pL, d);
	return 1;
}

int CLuaGlue::Lua_SoundDestroy(lua_State* pL)
{
	int		n	= lua_gettop(pL);
	DWORD	d	= (DWORD)lua_tonumber(pL, 1);

	CSound*	p = (CSound*)d;
	
	if(p)
		delete p;
	
	return 0;
}

int CLuaGlue::Lua_SoundPlay(lua_State* pL)
{
	int		n	= lua_gettop(pL);

	DWORD	d = (DWORD)lua_tonumber(pL, 1);
	CSound*	p = (CSound*)d;
	
	if(!p)
		return 0;

	if(n>=2)
		p->Play(0, DSBPLAY_LOOPING);
	else
		p->Play(0);
	
	return 0;
}


int CLuaGlue::Lua_SoundStop(lua_State* pL)
{
	int		n	= lua_gettop(pL);

	DWORD	d = (DWORD)lua_tonumber(pL, 1);
	CSound*	p = (CSound*)d;
	
	if(!p)
		return 0;

	p->Stop();
	
	return 0;
}


