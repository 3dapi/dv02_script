// Interface for the IDsSprite class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _IDsSprite_H_
#define _IDsSprite_H_

struct IDsSprite
{
public:
	virtual ~IDsSprite(){};

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL)=0;
	virtual void	Destroy()=0;

	virtual INT		Draw(void* pTx					// IDsTexture*
						, const RECT* pRC			// Draw Region
						, void* pScl				// Scaling
						, void* pPos				// Position
						, DWORD dColor)=0;

	virtual INT		DrawDxTex(void* pTx				// LPDIRECT3DTEXTURE9
						, const SIZE* pImg			// Image Size(width, Height)
						, const RECT* pRC			// Draw Region
						, void* pScl				// Scaling
						, void* pPos				// Position
						, DWORD dColor)=0;


	virtual	void*	GetDevice()=0;					// return	LPDIRECT3DDEVICE9
};

INT	DsDev_CreateSprite(char* cmd
						, IDsSprite** pData
						, void* pDevice		// LPDIRECT3DDEVICE9
						, void* p2=NULL		// No Use
						, void* p3=NULL		// No Use
						, void* p4=NULL		// No Use
					);

#endif

