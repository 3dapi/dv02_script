// Implementation of the CLuaGlue class.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"

lua_State* g_pL;


int LuaStartUp()
{
	int hr=-1;
	g_pL = lua_open();
	
	// load Lua libraries
	luaL_openlibs(g_pL);

	lua_register(g_pL, "Lua_WindowCreate",	CLuaGlue::Lua_WindowCreate);
	lua_register(g_pL, "Lua_WindowTitle",	CLuaGlue::Lua_WindowTitle);


	hr = luaL_dofile(g_pL, "script/_main.lua");
	
	// Scirpt�� �ִ� �Լ� ȣ��
	lua_getglobal(g_pL, "LuaApi_Create");
	lua_call(g_pL, 0, 1);

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 0;
}

void LuaClose()
{
	lua_close(g_pL);
}


int LuaApiInit()
{
	int hr=0;
	lua_getglobal(g_pL, "LuaApi_Init");
	lua_call(g_pL, 0, 1);

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 0;
}


int LuaApiDestroy()
{
	int hr=0;
	lua_getglobal(g_pL, "LuaApi_Destroy");
	lua_call(g_pL, 0, 1);

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 0;
}


int	LuaApiFrameMove()
{
	int hr=0;
	lua_getglobal(g_pL, "LuaApi_FrameMove");
	lua_call(g_pL, 0, 1);

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 0;
}


int LuaApiRender()
{
	int hr=0;
	lua_getglobal(g_pL, "LuaApi_Render");
	lua_call(g_pL, 0, 1);

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 0;
}



int CLuaGlue::Lua_WindowCreate(lua_State* pL)
{
	int		n	= lua_gettop(pL);

	char	sClassName[260]={0};

	if(n<6)
	{
		lua_pushnumber(pL, -1);
		return 1;
	}
	int		ScnX = (int)lua_tonumber(pL, 1);
	int		ScnY = (int)lua_tonumber(pL, 2);
	int		ScnW = (int)lua_tonumber(pL, 3);
	int		ScnH = (int)lua_tonumber(pL, 4);
	
	strcpy(sClassName, (char*)lua_tostring(pL, 5));
	int		nMode= (int)lua_tonumber(pL, 6);


	g_pApp->SetWindowClassName(sClassName);
	g_pApp->SetWindowStartX(ScnX);
	g_pApp->SetWindowStartY(ScnY);
	g_pApp->SetWindowWidth(ScnW);
	g_pApp->SetWindowHeight(ScnH);
	g_pApp->SetWindowStartMode(nMode);
	
	lua_pushnumber(pL, 0);
	return 1;
}


int CLuaGlue::Lua_WindowTitle(lua_State* pL)
{
	HWND hWnd = g_pApp->GetHwnd();

	int		n	= lua_gettop(pL);

	char	sMsg[1024]={0};

	strcpy(sMsg, (char*)lua_tostring(pL, 1));
	SetWindowText(hWnd, sMsg);
	return 0;
}

