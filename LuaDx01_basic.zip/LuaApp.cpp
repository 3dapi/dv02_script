// Program start.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain* g_pApp  = NULL;


INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
	INT		hr;
	CMain d3dApp;
	
	g_pApp  = &d3dApp;
	
	InitCommonControls();
	
	if(FAILED(LuaStartUp()))
		return -1;
	
	if( FAILED( d3dApp.Create( hInst ) ) )
		return 0;
	
	hr = d3dApp.Run();
	
	LuaClose();
	
	return hr;
}

