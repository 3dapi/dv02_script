// LnArray.cpp: implementation of the CLnArray class.
//
//////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


NumArray* CLnArray::Check(lua_State *L)
{
	void *ud = luaL_checkudata(L, 1, "LuaBook.array");
	luaL_argcheck(L, ud != NULL, 1, "array expected");
	return (NumArray *)ud;
}



int	CLnArray::New(lua_State *L)
{
	int n = luaL_checkint(L, 1);
	size_t nbytes = sizeof(NumArray) + (n - 1)*sizeof(double);
	
	// �޸𸮸� �����Ѵ�.
	NumArray *a = (NumArray *)lua_newuserdata(L, nbytes);
	
	luaL_getmetatable(L, "LuaBook.array");
	lua_setmetatable(L, -2);
	a->size = n;
	return 1;  /* new userdatum is already on the stack */
}




int CLnArray::Set(lua_State *L)
{
	NumArray *a = (NumArray *)lua_touserdata(L, 1);
	int index = luaL_checkint(L, 2);
	double value = luaL_checknumber(L, 3);
	
	luaL_argcheck(L, a != NULL, 1, "array expected");
	luaL_argcheck(L, 1 <= index && index <= a->size, 2, "index out of range");
	
	a->values[index-1] = value;
	return 0;
}


int CLnArray::Get(lua_State *L)
{
	NumArray *a = (NumArray *)lua_touserdata(L, 1);
	int index = luaL_checkint(L, 2);
	
	luaL_argcheck(L, a != NULL, 1, "array expected");
	luaL_argcheck(L, 1 <= index && index <= a->size, 2, "index out of range");
	
	lua_pushnumber(L, a->values[index-1]);
	return 1;
}



int CLnArray::Size(lua_State* L)
{
	NumArray *a = Check(L);
	lua_pushnumber(L, a->size);
	return 1;
	
}


static const luaL_reg LnArray [] =
{
	{"new",		CLnArray::New},
	{"set",		CLnArray::Set},
	{"get",		CLnArray::Get},
	{"size",	CLnArray::Size},
	{NULL, NULL}
};



int CLnArray::LuaOpenLib(lua_State *L)
{
	luaL_newmetatable(L, "LuaBook.array");
	luaL_openlib(L, "array", LnArray, 0);
	
	// now the stack has the metatable at index 1 and
	// array at index -2
	// metatable is at index -3
	// "structA" is at index -4
	
	lua_pushstring(L, "__index");
	lua_pushstring(L, "get");
	lua_gettable(L, -3);  /* get array.get */
	lua_settable(L, -4);  /* metatable.__index = array.get */
	
	lua_pushstring(L, "__newindex");
	lua_pushstring(L, "set");
	lua_gettable(L, -3); /* get array.set */
	lua_settable(L, -4); /* metatable.__newindex = array.set */
	
	return 0;
}
