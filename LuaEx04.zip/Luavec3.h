// Interface for the CLuaVec3 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LUAVEC3_H_
#define _LUAVEC3_H_


typedef struct { double a[3]; } vector3;


class CLuaVec3
{
public:
	//Lua API.
	static int	New(lua_State*);
	static int	Set(lua_State*);
	static int	Get(lua_State*);
	
	static int	LuaOpenLib(lua_State *pL);
};


#endif