


#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif



#include <windows.h>
#include <crtdbg.h>
#include <stdio.h>
#include <string.h>

#include <lua/lua.h>


LUA_API int lua_loadstring(lua_State *L, const char *data, const char *chunkname);

inline LUA_API lua_Number lua_popnumber(lua_State *L)
{
	register lua_Number tmp = lua_tonumber(L, lua_gettop(L));
	lua_pop(L, 1);
	return tmp;
}

inline LUA_API const char *lua_popstring(lua_State *L)
{
	register const char *tmp = lua_tostring(L, lua_gettop(L));
	lua_pop(L, 1);
	return tmp;
}



typedef struct luaMemFile
{
	const char *text;
	size_t size;
} luaMemFile;

static const char *readMemFile(lua_State *, void *ud, size_t *size)
{
	// Convert the ud pointer (UserData) to a pointer of our structure
	luaMemFile *luaMF = (luaMemFile *) ud;
	
	// Are we done?
	if(luaMF->size == 0)
		return NULL;
	
	// Read everything at once
	// And set size to zero to tell the next call we're done
	*size = luaMF->size;
	luaMF->size = 0;
	
	// Return a pointer to the readed text
	return luaMF->text;
}

LUA_API int lua_loadstring(lua_State *L, const char *data, const char *chunkname)
{
	luaMemFile luaMF;
	luaMF.text = data;
	luaMF.size = strlen(data);
	return lua_load(L, readMemFile, &luaMF, chunkname);
}



static int alert_lua(const char *str, const char *title = NULL)
{
	return MessageBox(HWND_DESKTOP, str, title, MB_OK);
}

static int alert_glue(lua_State *L)
{
	// Verify the number of parameters, we need atleast one!
	int n = lua_gettop(L);
	if(n < 1)
	{
		lua_pushstring(L, "alert_glue: not enough arguments");
		lua_error(L);
	}
	
	// Get the first argument as a string
	const char *str = lua_tostring(L, 1);
	if(str == NULL)
	{
		lua_pushstring(L, "alert_glue: non-string");
		lua_error(L);
	}
	
	// If there are 2 arguments then also display the title
	if(n == 1)
		lua_pushnumber(L, alert_lua(str));
	else
		lua_pushnumber(L, alert_lua(str, lua_tostring(L, 2)));
	
	// There's one result on the stack
	// (the return value of alert_lua aka MessageBox)
	return 1;
}


const char *testscript = 
{
	"function double(n)\n"
		"  return n * 2\n"
		"end\n"
		"\n"
		"return alert(double(1), 'double(1)=')\n"
};



void main()
{
	// Initialize LUA
	lua_State *L = lua_open();
	
	// Register our alert function
	lua_register(L, "alert", alert_glue);
	
	// Load the command and try to execute it...
	if(lua_loadstring(L, testscript, "test function") == 0)
	{
		// Execute the loaded command...
		// The function takes 0 parameters and will always return 1 result
		if(lua_pcall(L, 0, 1, 0) == 0)
		{
			// There was no error
			// Let's get the result from the stack
			lua_Number result = lua_tonumber(L, lua_gettop(L));
			
			// Some output (using LUA)
			char tmp[64];
			wsprintf(tmp, "The result was : %u!", (int) result);
			lua_getglobal(L, "alert");
			lua_pushstring(L, testscript);
			lua_pushstring(L, tmp);
			lua_call(L, 2, 1);
			lua_pop(L, 1);
		}
		else
		{
			// Some output (using LUA)
			lua_getglobal(L, "alert");
			lua_pushstring(L, testscript);
			lua_pushstring(L, "lua_call error!");
			lua_call(L, 2, 1);
			lua_pop(L, 1);
		}
		
		// Clean-up the stack
		lua_pop(L, 1);
	}
	else
	{
		// There was a lua_load error...
		// Pop the error value from the stack
		lua_pop(L, 1);
		
		// Some output (using LUA)
		lua_getglobal(L, "alert");
		lua_pushstring(L, testscript);
		lua_pushstring(L, "lua_load error!");
		lua_call(L, 2, 1);
		lua_pop(L, 1);
	}
	
	// Let's also try to call the double function
	// (the function will be execute by LUA, neat uh?)
	lua_getglobal(L, "double");
	lua_pushnumber(L, 3);
	lua_call(L, 1, 1);
	_ASSERT(lua_popnumber(L) == 6);
	
	// Verify the stack and clean-up the LUA state
	_ASSERT(lua_gettop(L) == 0);
	lua_close(L);
	
}