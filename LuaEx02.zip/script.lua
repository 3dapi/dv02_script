-- Simple LUA Program


a = array.new(1000)
print(a)


print(a:size())     --> 1000
a:set(10, 3.4)
c =  a:get(10)
print(c)			--> 3.4

