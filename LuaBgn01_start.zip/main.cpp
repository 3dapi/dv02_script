

#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif


#include <stdio.h>

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>

// Lua interpreter
lua_State* g_pL;

void main()
{
	printf("LUA Init and Destroy.\n\n");
	// initialize Lua
	g_pL = lua_open();
	
	// load Lua libraries
	luaL_openlibs(g_pL);
	
	// cleanup Lua
	lua_close(g_pL);
}