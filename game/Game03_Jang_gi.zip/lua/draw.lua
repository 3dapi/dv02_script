------------------���ϼ��������� �׸���
----------------------------------------------------------------
function SelPatternWinDraw(posx, posy)

	Mcl_TextureDraw(g_TxId[26],  0, 0,	g_TxW[26]	,g_TxH[26],	posx, posy)	--���

	--���˹�ġ--1;ة�� ��ة, 2;��ة ة��, 3;��ة ��ة, 4;ة�� ة��

	Mcl_TextureDraw(g_TxId[8],  6*g_TxW[8]/16, 1*g_TxH[8]/2, 7*g_TxW[8]/16, 2*g_TxH[8]/2, 12+posx, 41+posy,	0.45, 0.45)
	Mcl_TextureDraw(g_TxId[8],  4*g_TxW[8]/16, 1*g_TxH[8]/2, 5*g_TxW[8]/16, 2*g_TxH[8]/2, 47+posx, 41+posy,	0.45, 0.45)
	Mcl_TextureDraw(g_TxId[8],  4*g_TxW[8]/16, 1*g_TxH[8]/2, 5*g_TxW[8]/16, 2*g_TxH[8]/2, 94+posx, 41+posy, 0.45, 0.45)
	Mcl_TextureDraw(g_TxId[8],  6*g_TxW[8]/16, 1*g_TxH[8]/2, 7*g_TxW[8]/16, 2*g_TxH[8]/2, 129+posx, 41+posy,0.45, 0.45)

	Mcl_TextureDraw(g_TxId[8],  4*g_TxW[8]/16, 1*g_TxH[8]/2, 5*g_TxW[8]/16, 2*g_TxH[8]/2, 12+posx, 78+posy, 0.45, 0.45)
	Mcl_TextureDraw(g_TxId[8],  6*g_TxW[8]/16, 1*g_TxH[8]/2, 7*g_TxW[8]/16, 2*g_TxH[8]/2, 47+posx, 78+posy,	0.45, 0.45)
	Mcl_TextureDraw(g_TxId[8],  6*g_TxW[8]/16, 1*g_TxH[8]/2, 7*g_TxW[8]/16, 2*g_TxH[8]/2, 94+posx, 78+posy, 0.45, 0.45)
	Mcl_TextureDraw(g_TxId[8],  4*g_TxW[8]/16, 1*g_TxH[8]/2, 5*g_TxW[8]/16, 2*g_TxH[8]/2, 129+posx, 78+posy,0.45, 0.45)

	Mcl_TextureDraw(g_TxId[8],  4*g_TxW[8]/16, 1*g_TxH[8]/2, 5*g_TxW[8]/16, 2*g_TxH[8]/2, 12+posx, 115+posy, 0.45, 0.45)
	Mcl_TextureDraw(g_TxId[8],  6*g_TxW[8]/16, 1*g_TxH[8]/2, 7*g_TxW[8]/16, 2*g_TxH[8]/2, 47+posx, 115+posy, 0.45, 0.45)
	Mcl_TextureDraw(g_TxId[8],  4*g_TxW[8]/16, 1*g_TxH[8]/2, 5*g_TxW[8]/16, 2*g_TxH[8]/2, 94+posx, 115+posy, 0.45, 0.45)
	Mcl_TextureDraw(g_TxId[8],  6*g_TxW[8]/16, 1*g_TxH[8]/2, 7*g_TxW[8]/16, 2*g_TxH[8]/2, 129+posx, 115+posy,0.45, 0.45)

	Mcl_TextureDraw(g_TxId[8],  6*g_TxW[8]/16, 1*g_TxH[8]/2, 7*g_TxW[8]/16, 2*g_TxH[8]/2, 12+posx, 152+posy, 0.45, 0.45)
	Mcl_TextureDraw(g_TxId[8],  4*g_TxW[8]/16, 1*g_TxH[8]/2, 5*g_TxW[8]/16, 2*g_TxH[8]/2, 47+posx, 152+posy, 0.45, 0.45)
	Mcl_TextureDraw(g_TxId[8],  6*g_TxW[8]/16, 1*g_TxH[8]/2, 7*g_TxW[8]/16, 2*g_TxH[8]/2, 94+posx, 152+posy, 0.45, 0.45)
	Mcl_TextureDraw(g_TxId[8],  4*g_TxW[8]/16, 1*g_TxH[8]/2, 5*g_TxW[8]/16, 2*g_TxH[8]/2, 129+posx, 152+posy,0.45, 0.45)

--	Mcl_FontDraw(g_nFnt[3], "��   ��    ��   ��", 15, 40, "0xFF333333") 
--	Mcl_FontDraw(g_nFnt[3], "��   ��    ��   ��", 15, 77, "0xFF333333") 
--	Mcl_FontDraw(g_nFnt[3], "��   ��    ��   ��", 15, 114, "0xFF333333") 
--	Mcl_FontDraw(g_nFnt[3], "��   ��    ��   ��", 15, 151, "0xFF333333") 

	return 0
end

------------------������ ȭ���� �׸���
-----------------------------------------------------
function GameBoardDraw()


	--���˹�ġ--1;�� 2~3;��, 4~5;��, 6~7;ة, 8~9;�, 10~11;��, 12~16;��
	for i=1, 90, 1 do
		if g_SlotTeam[i] == 1 then
			Mcl_TextureDraw(g_TxId[8],  (g_SlotUnit[i]-1)*g_TxW[8]/16, 1*g_TxH[8]/2, g_SlotUnit[i]*g_TxW[8]/16 ,2*g_TxH[8]/2,
					Mcl_Mod(i-1, 9)*80+32 +2*g_TxIdx[7], 
					Mcl_CastInt((i-1)/9)*68+57 +2*g_TxIdx[7])

		else if g_SlotTeam[i] == -1 then
			Mcl_TextureDraw(g_TxId[8],  (g_SlotUnit[i]-1)*g_TxW[8]/16, 0*g_TxH[8]/2, g_SlotUnit[i]*g_TxW[8]/16 ,1*g_TxH[8]/2,
					Mcl_Mod(i-1, 9)*80+32 +2*g_TxIdx[7],
					Mcl_CastInt((i-1)/9)*68+57 +2*g_TxIdx[7])
		end end
	end

	--���� ����
	for i=2, 16, 1 do
		if g_P1PcState[i] == -1 then 
			Mcl_TextureDraw(g_TxId[8],  (i-1)*g_TxW[8]/16, g_TxH[8]/2, i*g_TxW[8]/16 ,2*g_TxH[8]/2,
				Mcl_Mod(i-2, 5)*20+790	+g_TxIdx[7],
				Mcl_CastInt((i-2)/5)*26+260 +g_TxIdx[7],
				0.4, 0.4)
		end
		if g_P2PcState[i] == -1 then 
			Mcl_TextureDraw(g_TxId[8], (i-1)*g_TxW[8]/16, 0, i*g_TxW[8]/16 ,g_TxH[8]/2,
				Mcl_Mod(i-2, 5)*20+906 +g_TxIdx[7], 
				Mcl_CastInt((i-2)/5)*26+260 +g_TxIdx[7],
				0.4, 0.4)
		end
	end

	--���� ���ý�
	if g_PMFlag == 1 then 
	
		--���� ����ani
		Mcl_TextureDraw(g_TxId[24], 
				(g_TxIdx[5]-1)*g_TxW[24]/6, g_MarkSizeFlag*g_TxH[24]/3,	
				g_TxIdx[5]*g_TxW[24]/6 , (g_MarkSizeFlag+1)*g_TxH[24]/3,
				Mcl_Mod(g_PSlotNo-1, 9)*80+28, Mcl_CastInt((g_PSlotNo-1)/9)*68+54)

	else if g_PMFlag == 2 then
		--������ ����
		if g_TurnFlag == 1 then 
			Mcl_TextureDraw(g_TxId[8],  (g_PUnitNo-1)*g_TxW[8]/16, 1*g_TxH[8]/2, g_PUnitNo*g_TxW[8]/16, 2*g_TxH[8]/2,
						g_Mouse[1]-36, g_Mouse[2]-36,  "0x99FFFFFF")

		else if g_TurnFlag == -1 then 
			Mcl_TextureDraw(g_TxId[8],  (g_PUnitNo-1)*g_TxW[8]/16, 0,	g_PUnitNo*g_TxW[8]/16 ,1*g_TxH[8]/2,
						g_Mouse[1]-36, g_Mouse[2]-36,  "0x99FFFFFF")
		end end
		
		--�̵����� ��� ȭ��ǥ ani
		for i=1, 90, 1 do
			if g_ArrowMark[i] == 1 then 
				Mcl_TextureDraw(g_TxId[23],  0, g_TxIdx[4]*g_TxH[23]/2,	g_TxW[23] ,(g_TxIdx[4]+1)*g_TxH[23]/2,	
					Mcl_Mod(i-1, 9)*80+58, Mcl_CastInt((i-1)/9)*68+73)
			end
		end

	end end
end

----------Ÿ�̸Ӹ� �׸���
---------------------------------------------------------------------
function TimerDraw()

	if g_TurnFlag == 1 then 
		
		Mcl_TextureDraw(g_TxId[25],  0, 0, g_TxW[25] ,g_TxH[25]/3, 795, 374,  "0xAAFFFFFF")
		if g_TxIdx[3] <= 5 then
			Mcl_TextureDraw(g_TxId[25],  0, 1*g_TxH[25]/3, g_TxW[25]-(80-g_TxIdx[3]) ,2*g_TxH[25]/3, 795, 374,  "0xAAFFFFFF")
		else
			Mcl_TextureDraw(g_TxId[25],  0, 1*g_TxH[25]/3, g_TxW[25]-(80-g_TxIdx[3]) ,2*g_TxH[25]/3, 795, 374, "0xAAFFFFFF")
		end
		Mcl_FontDraw(g_nFnt[1], string.format("00 : %d", g_TxIdx[3]/4), 812, 394, "0xFF333333")

	else if g_TurnFlag == -1 then 

		Mcl_TextureDraw(g_TxId[25],  0, 0, g_TxW[25] ,g_TxH[25]/3, 930, 374,  "0xAAFFFFFF")
		if g_TxIdx[3] <= 5 then
			Mcl_TextureDraw(g_TxId[25],  0, 1*g_TxH[25]/3, g_TxW[25]-(80-g_TxIdx[3]) ,2*g_TxH[25]/3, 930, 374,  "0xAAFFFFFF")
		else
			Mcl_TextureDraw(g_TxId[25],  0, 1*g_TxH[25]/3, g_TxW[25]-(80-g_TxIdx[3]) ,2*g_TxH[25]/3, 930, 374, "0xAAFFFFFF")
		end
		Mcl_FontDraw(g_nFnt[1], string.format("00 : %d", g_TxIdx[3]/4), 938, 394, "0xFF333333") 
	
	end end

	return 0
end
		

----------��� â�� �׸���
---------------------------------------------------------------------
function TopBarDraw()
	
	Mcl_TextureDraw(g_TxId[9],  0, 0,	g_TxW[9]	,g_TxH[9],	0, 0)

	Mcl_TextureDraw(g_TxId[17],  
		0*g_TxW[17]/3, g_BtFlag_Capture*g_TxH[17]/3, 1*g_TxW[17]/3	,(g_BtFlag_Capture+1)*g_TxH[17]/3,	810, 6)	--ĸó��ư
	Mcl_TextureDraw(g_TxId[17],  
		1*g_TxW[17]/3, g_BtFlag_Option*g_TxH[17]/3, 2*g_TxW[17]/3	,(g_BtFlag_Option+1)*g_TxH[17]/3,	854, 6)	--�ɼǹ�ư
	Mcl_TextureDraw(g_TxId[17],  
		2*g_TxW[17]/3, g_BtFlag_Caution*g_TxH[17]/3, 3*g_TxW[17]/3	,(g_BtFlag_Caution+1)*g_TxH[17]/3,	900, 6)	--�Ű���ư
												           
	Mcl_TextureDraw(g_TxId[16],  
		0*g_TxW[16]/4, g_BtFlag_Minimum*g_TxH[16]/3, 1*g_TxW[16]/4	,(g_BtFlag_Minimum+1)*g_TxH[16]/3,	950, 3)	--�ּ�ȭ��ư

	if g_BtFlag_WinMode >= 0 then
		Mcl_TextureDraw(g_TxId[16],  
			1*g_TxW[16]/4, g_BtFlag_WinMode*g_TxH[16]/3, 2*g_TxW[16]/4	,(g_BtFlag_WinMode+1)*g_TxH[16]/3,	974, 3)	--��������ư
	else 
		Mcl_TextureDraw(g_TxId[16],  
			3*g_TxW[16]/4, g_BtFlag_FullMode*g_TxH[16]/3, 4*g_TxW[16]/4	,(g_BtFlag_FullMode+1)*g_TxH[16]/3,	974, 3)	--Ǯ����ư
	end
	Mcl_TextureDraw(g_TxId[16],  
		2*g_TxW[16]/4, g_BtFlag_Exit*g_TxH[16]/3, 3*g_TxW[16]/4	,(g_BtFlag_Exit+1)*g_TxH[16]/3,	998, 3)	--�����ư

	--ä�� ���� �ؽ�Ʈ
	Mcl_FontDraw(g_nFnt[2], string.format("%s", "[Freeä��-1]"), 80, 6, "0xFFFFFF44")
	--�� ���� �ؽ�Ʈ
	Mcl_FontDraw(g_nFnt[3], string.format("%s", "���ɱ� ���� ����������.."), 155, 8, "0xFFFFFFFF")

	return 0	
end

----------��� â�� �׸���
---------------------------------------------------------------------
function ResultWinDraw(posx, posy)
	
	Mcl_TextureDraw(g_TxId[18],  0, 0,	g_TxW[18]	,g_TxH[18],	posx+20, posy)
	--���Ӱ���ؽ�Ʈ
	if g_ResultFlag == 0 then --���ºν�
		Mcl_TextureDraw(g_TxId[19],  0*g_TxW[19]/3, 0,	1*g_TxW[19]/3	,g_TxH[19],	posx, posy+12)
	else if g_ResultFlag == 1 then --�����÷��̾ �¸���
		Mcl_TextureDraw(g_TxId[19],  1*g_TxW[19]/3, 0,	2*g_TxW[19]/3	,g_TxH[19],	posx, posy+12)
	else if g_ResultFlag == 2 then --�����÷��̾ �й��
		Mcl_TextureDraw(g_TxId[19],  2*g_TxW[19]/3, 0,	3*g_TxW[19]/3	,g_TxH[19],	posx, posy+12)
	end end end

	--Ȯ�ι�ư
	Mcl_TextureDraw(g_TxId[20],  0, 0,	g_TxW[20]	,g_TxH[20]/3,	posx+86, posy+160)

	--����or�Һ��� ���ӸӴ�
	Mcl_FontDraw(g_nFnt[1], string.format("%d", g_GetGameMoney), posx+38, posy+104, "0xFFFFFF44")
	--��������
	Mcl_FontDraw(g_nFnt[1], string.format("%d", g_UserLevel), posx+38, posy+134, "0xFFFFFF44")
	--���� ����Ʈ
	Mcl_FontDraw(g_nFnt[1], string.format("%d", g_GetLevelPt), posx+98, posy+134, "0xFFFFFF44")

	return 0
end

----------���ӽ��� â�� �׸���
---------------------------------------------------------------------
function GameStartWinDraw(posx, posy)

	Mcl_TextureDraw(g_TxId[21],  0, 0,	g_TxW[21]	,g_TxH[21],	posx, posy)	--���ӽ���â
	Mcl_TextureDraw(g_TxId[22],  0, 0,	g_TxW[22]	,g_TxH[22]/2,	posx+98, posy+30)	--���ӽ����ؽ�Ʈ

	return 0
end

