--
-- Begin Phase Script
--

Lsys.DoFile("Script/input.lua")


D3DMX_PI = 3.141592654

mtWorld =
{
	  1.0, 0.0, 0.0, 0.0
	, 0.0, 1.0, 0.0, 0.0
	, 0.0, 0.0, 1.0, 0.0
	, 0.0, 0.0, 0.0, 1.0
}


function Lua_Init()
	Ld3d.SetClearColor("0xFF006699")

	g_nFnt	= Lfont.New("����", 24, 1, 1, "0XFFFFFFFF", "0XFF111111", 0, 1)
	LxCam.SetEye  (0, 5., 2., -5.)
	LxCam.SetLook (0, 0., 0.,  0.)
	LxCam.SetUp   (0, 0., 1.,  0.)
	LxCam.SetBasis(0, 5., 2., -5.)
	LxCam.SetType (0, 1)	-- 1��Ī ī�޶�� ��ȯ(2�̸� 3��Ī)


	--						vtx type,		  pt type, Primitive Num,  Vertex Num

	--					Model Name			 Texture Folder Name
	g_nXmsh	= Lxms.New("Texture/tiger.x", "Texture/")

	if g_nXmsh < 0 then
		return -1
	end

	--			commend			folder name
	-- Lxms.Query("Load Texture", "Texture")



	-- Material Setup
	g_nMtl = Lmtl.New(		1,	1,	0	-- Ambient r, g, b
						,	1,	1 ,	0	-- Diffuse r, g, b
						,	0,	0 ,	0	-- Specular r, g, b
						,	0,	0 ,	0	-- Emissive r, g, b
						,	10			-- Power
						)


	-- Lighting Setup
	g_nLgt = Llgt.New(	"DIRECTIONAL"
						,	0,	0,	0	-- Ambient r, g, b
						,	1,	1 ,	1	-- Diffuse r, g, b
						,	0,	0 ,	0	-- Specular r, g, b

						,	0,	0 ,	0	-- Position x, y, z
						,	0,	0 ,	0	-- Direction x, y, z

						,	1000	--Range	
						,	0	--Fall	
						,	0	--Attn0	
						,	0	--Attn1	
						,	0	--Attn2	
						,	0	--Theta	
						,	0	--Phi	
						)

	return 0

end


function Lua_Destroy()
	return 0
end


function Lua_FrameMove()
	UpdateInput()

	-- ascii 37 is Left, 39 is Right
	if 1 == g_Keyboard[37] then
		return 4
	elseif 1 == g_Keyboard[39] then
		return 6
	end

-- 'W'
	if 3 == g_Keyboard[64+23] then 
		LxCam.MoveForward(0, 1);
	end

	-- 'S'
	if 3 == g_Keyboard[64+19] then 
		LxCam.MoveForward(0, -1);
	end

	-- 'D'
	if 3 == g_Keyboard[64+4] then 
		LxCam.MoveSideward(0, 1);
	end

	-- 'A'
	if 3 == g_Keyboard[64+1] then 
		LxCam.MoveSideward(0, -1);
	end


	if 3 == MouseEvntR then 
		local ex, ey, ez = Lin.MouseDelta()

		sMsg = string.format("Input: %f %f %f", ex, ey, ez)
		print(sMsg)
		LxCam.RotateYaw(0, ex, 0.1);
		LxCam.RotatePitch(0, ey, 0.1);
	end

	LxCam.FrameMove()




	-- ������ļ���
	fTick = Lutil.GetTickCount()
	fAngle = fTick/500.0

	fCos = math.cos(fAngle)
	fSin = math.sin(fAngle)

--	mtWorld[ (2-1) * 4 + 3] =  fSin
--	mtWorld[ (3-1) * 4 + 2] = -fSin

--	mtWorld[ (2-1) * 4 + 2] =  fCos
--	mtWorld[ (3-1) * 4 + 3] =  fCos

--	sMsg = string.format("��: %f", fCos)
--	Lsys.WindowTitle(sMsg)

	dR, dF, dB = Lmtl.GetDiffuse(g_nMtl)

--	sMsg = string.format("Diffuse: %f %f %f", dR, dF, dB)
--	Lsys.WindowTitle(sMsg)


	LgtX = math.cos(fTick/350)
	LgtY = 1.0
	LgtZ = math.sin(fTick/350)

	Llgt.SetDirection(LgtX, LgtY, LgtZ)

	return 0

end

function Lua_Render()
	Ltex.Draw(g_nTex, 0, 0, Ltex.Width(g_nTex), Ltex.Height(g_nTex), 0, 0)


	LxCam.SetTransformView(0)
	LxCam.SetTransformProj(0)

	LxUtil.Command("Render Grid")

	-- ������ļ���
	--Ld3d.SetTransform( "WORLD", mtWorld)
--	Ld3d.SetTransform( "WORLD", 
--	, mtWorld[ 1], mtWorld[ 2], mtWorld[ 3], mtWorld[ 4]
--	, mtWorld[ 5], mtWorld[ 6], mtWorld[ 7], mtWorld[ 8]
--	, mtWorld[ 9], mtWorld[10], mtWorld[11], mtWorld[12]
--	, mtWorld[13], mtWorld[14], mtWorld[15], mtWorld[16])

	Ld3d.SetTransform( "WORLD", mtWorld)

	Ld3d.SetRenderState("CullMode", "NONE")

	Lmtl.SetMaterial(g_nMtl)

	Llgt.SetLight(LgtX, 0)
	Llgt.LightEnable(LgtX, 1)

	Ld3d.SetRenderState( "LIGHTING", "FALSE" )
	Ld3d.SetRenderState( "AMBIENT", "0x00202020" )

--	Ld3d.SetRenderState("Zenable", "FALSE")
	Ltex.SetTexture(g_nTex2, 0)
	Lxms.Render(g_nXmsh)
	Ld3d.SetRenderState("ZENABLE", "TRUE")

	Lfont.Draw(g_nFnt, "X-File �� ������", 100, 50, "0xFFFFFFFF")
	return 0
end
