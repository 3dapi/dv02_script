--
-- Begin Phase Script
--

Lsys.DoFile("Script/input.lua")


function Lua_Init()
	Ld3d.SetClearColor("0xFF006699")

	g_nFnt	= Lfont.New("HY����M", 32, 1, 0, "0XFFFF0000", "0XFFFFFF00", 1, 1)
	g_nTex	= Ltex.New("Texture/bg_01.bmp", "0xFFFF00FF")

	--						vtx type,		  pt type, Primitive Num,  Vertex Num
	g_nVtx	= Lvtx.New("Diffuse", "TRIANGLE LIST",             1,  3)


	if g_nVtx < 0 then
		return -1
	end

	-- Lock
	if Lvtx.Lock(g_nVtx) < 0 then
		return -1
	end

	--			vtx, array Idx,    x,    y,   z,   color(r,g,b,a 0~1)
	Lvtx.SetVtx(g_nVtx,      0, -1.5, -1.5, 0.0,	 1, 0, 0, 1);
	Lvtx.SetVtx(g_nVtx,      1,  1.5, -1.5, 0.0,	 0, 1, 0, 1);
	Lvtx.SetVtx(g_nVtx,      2,  0.0,  1.5, 0.0,	 0, 0.5, 1, 1);

	-- Lock�� �ɾ����� �ݵ�� UnLock
	Lvtx.UnLock(g_nVtx)

	return 0
end


function Lua_Destroy()
	return 0
end

D3DMX_PI = 3.141592654

mtWorld =
{
	  _11 = 0.0, _12 = 0.0, _13 = 0.0, _14 = 0.0
	, _21 = 0.0, _22 = 1.0, _23 = 0.0, _24 = 0.0
	, _31 = 0.0, _32 = 0.0, _33 = 1.0, _34 = 0.0
	, _41 = 0.0, _42 = 0.0, _43 = 0.0, _44 = 1.0
}


function Lua_FrameMove()
	UpdateInput()

	-- ascii 37 is Left, 39 is Right
	if 1 == g_Keyboard[37] then
		return 6
	elseif 1 == g_Keyboard[39] then
		return 8
	end


	-- ���� ����
	a = 100
	b = 34
	c = a%b

	-- ������ļ���
	iTime  = Lutil.GetTickCount() % 1000
	fAngle = iTime * 2.0 * D3DMX_PI / 1000.0

	fCos = math.cos(fAngle)
	fSin = math.sin(fAngle)

	mtWorld._13 = -fSin
	mtWorld._31 =  fSin

	mtWorld._11 =  fCos
	mtWorld._33 =  fCos


--	sMsg = string.format("��: %d %d", c, iTime)
--	Lsys.WindowTitle(sMsg)

	return 0

end

function Lua_Render()
	Ltex.Draw(g_nTex, 0, 0, Ltex.Width(g_nTex), Ltex.Height(g_nTex), 0, 0)
--	Ltex.SetTexture(g_nTex, 0)

	-- ������ļ���
	Ld3d.SetTransform( "WORLD"
	, mtWorld._11, mtWorld._12, mtWorld._13, mtWorld._14
	, mtWorld._21, mtWorld._22, mtWorld._23, mtWorld._24
	, mtWorld._31, mtWorld._32, mtWorld._33, mtWorld._34
	, mtWorld._41, mtWorld._42, mtWorld._43, mtWorld._44)

	-- �����(ī�޶�)����
	Ld3d.SetTransform( "VIEW", 0.0, 3.0, -5.0
						     , 0.0, 0.0,  0.0
							 , 0.0, 1.0,  0.0 )

	-- �������� ��� ����
	Ld3d.SetTransform( "PROJECTION", D3DMX_PI/4.0, 800./600.0, 1.0, 4000.0)



	Ld3d.SetRenderState("CullMode", "NONE")
	Ld3d.SetRenderState("Zenable", "FALSE")
	Lvtx.Render(g_nVtx)
	Ld3d.SetRenderState("ZENABLE", "TRUE")

	Lfont.Draw(g_nFnt, "���� ��ȯ + �ﰢ�� �׸���", 100, 50, "0xFFFFFFFF")
	return 0
end
