--
-- Begin Phase Script
--

Lsys.DoFile("Script/input.lua")


function Lua_Init()
	Ld3d.SetClearColor("0xFF006699")
	
	g_nFnt	= Lfont.New("HY��������M", 24, 2, 0, "0XFFFFFFFF", "0XFF111111", 0, 1)

	-- Camera Setup
	LxCam.SetEye  (0, 500, 300, -500)
	LxCam.SetLook (0, 500, 250,    0)
	LxCam.SetUp   (0,   0,   1,    0)
	LxCam.SetBasis(0, 500, 300, -500)

	LxCam.SetType (0, 1)	-- 1��Ī ī�޶�� ��ȯ(2�̸� 3��Ī)


	-- LxMapi: Outdoor Map class
	LxMapi.New("Map/grave01.bod", "Data/TblTex.dat", "Data/TblMdl.dat")

	m_pSkyBox	= Lxms.New("Model/SKY/skydome.x", "Texture/EtcAll/")

	return 0

end


function Lua_Destroy()
	return 0
end



mtWorld=
{
	  16.0,  0.0,    0.0, 0.0
	,  0.0, 10.0,    0.0, 0.0
	,  0.0,  0.0,   16.0, 0.0
	,  0.0, -4000.0, 0.0, 1.0
}


Rotate =0

function Lua_FrameMove()
	UpdateInput()

	-- ascii 37 is Left, 39 is Right
	if 1 == g_Keyboard[37] then
		return 3
	elseif 1 == g_Keyboard[39] then
		return 5
	end


	-- 18
	local hr =-1

	if 1 == g_Keyboard[64+18] then
		local hr = LxMapi.New("Map/grave02.bod", "Data/TblTex.dat", "Data/TblMdl.dat")

		if hr < 0 then
			return -1
		end
	elseif 1 == g_Keyboard[64+20] then
		hr = LxMapi.New("Map/grave03.bod", "Data/TblTex.dat", "Data/TblMdl.dat")

		if hr < 0 then
			return -1
		end
	end


-- 'W'
	if 3 == g_Keyboard[64+23] then 
		LxCam.MoveForward(0, 4);
	end

	-- 'S'
	if 3 == g_Keyboard[64+19] then 
		LxCam.MoveForward(0, -4);
	end

	-- 'D'
	if 3 == g_Keyboard[64+4] then 
		LxCam.MoveSideward(0, 4);
	end

	-- 'A'
	if 3 == g_Keyboard[64+1] then 
		LxCam.MoveSideward(0, -4);
	end


	if 3 == MouseEvntR then 
		local ex, ey, ez = Lin.MouseDelta()
		LxCam.RotateYaw(0, ex, 0.2);
		LxCam.RotatePitch(0, ey, 0.2);
	end

	LxCam.FrameMove()
	LxMapi.FrameMove()


	local dBgn = Lsys.GetTime()
	Rotate = Rotate + dBgn/200000000
	
	if Rotate> 360. then
		Rotate = Rotate - 360.
	end

	local rad = Rotate * 3.141592
	local fCos= math.cos(rad)
	local fSin= math.sin(rad)


	mtWorld[1] = 16*fCos
--	mtWorld[2] = 0
	mtWorld[3] =-16*fSin

--	mtWorld[5] = 0
	mtWorld[6] =10
--	mtWorld[7] = 0

	mtWorld[ 9]=16*fSin
--	mtWorld[10]= 0
	mtWorld[11]=16*fCos

	local cx, cy, cz = LxCam.GetEye(0)

	mtWorld[13] = cx
	mtWorld[14] = cy - 3500
	mtWorld[15] = cz


	return 0

end

function Lua_Render()
	Ltex.Draw(g_nTex, 0, 0, Ltex.Width(g_nTex), Ltex.Height(g_nTex), 0, 0)

	--Setup transform
	LxCam.SetTransformVP(0)

	LxUtil.Command("Render Grid")


	Ld3d.SetRenderState( "LIGHTING", "FALSE" )
	Ld3d.SetRenderState( "FOGENABLE", "TRUE" )
	Ld3d.SetTransform("WORLD", mtWorld)

	Ld3d.SetSamplerState( 0, "MINFILTER", "LINEAR" )
	Ld3d.SetSamplerState( 0, "MAGFILTER", "LINEAR" )
	Ld3d.SetSamplerState( 0, "MIPFILTER", "LINEAR" )
	Ld3d.SetSamplerState( 0, "ADDRESSU", "CLAMP" )
	Ld3d.SetSamplerState( 0, "ADDRESSV", "CLAMP" )
	Lxms.Render(m_pSkyBox)
	Ld3d.SetTransformI( "WORLD")
	
	Ld3d.SetRenderState( "LIGHTING", "TRUE" )
	LxMapi.Render()



	Lfont.Draw(g_nFnt, "�ǿ� ����������", 100, 50, "0xFFFFFFFF")
	return 0
end
