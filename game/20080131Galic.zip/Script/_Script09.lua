--
-- Begin Phase Script
--

Lsys.DoFile("Script/input.lua")


D3DMX_PI = 3.141592654

mtWorld =
{
	  _11 = 1.0, _12 = 0.0, _13 = 0.0, _14 = 0.0
	, _21 = 0.0, _22 = 1.0, _23 = 0.0, _24 = 0.0
	, _31 = 0.0, _32 = 0.0, _33 = 1.0, _34 = 0.0
	, _41 = 0.0, _42 = 0.0, _43 = 0.0, _44 = 1.0
}


function Lua_Init()
	Ld3d.SetClearColor("0xFF006699")

	g_nFnt	= Lfont.New("HY����M", 32, 1, 0, "0XFFFF0000", "0XFFFFFF00", 1, 1)
	g_nTex1	= Ltex.New("Texture/bg_01.bmp", "0xFFFF00FF")
	g_nTex2	= Ltex.New("Texture/banana.bmp","0x00000000")

	--						vtx type,		  pt type, Primitive Num,  Vertex Num
	g_nVtx	= Lvtx.New("Normal Diffuse Texture1", "TRIANGLE STRIP",   2*50-2,  2*50)


	if g_nVtx < 0 then
		return -1
	end

	-- Lock
	if Lvtx.Lock(g_nVtx) < 0 then
		return -1
	end


	for i=0, 50-1, 1 do
		theta = (2*D3DMX_PI*i)/(50-1)

		local posX = math.sin(theta)
		local posY = -1.0
		local posZ = math.cos(theta)

		local norX = math.sin(theta)
		local norX = 0.0
		local norX = math.cos(theta)

		local r = 255/255
		local g = 255/255
		local b = 255/255
		local a = 255/255

		local u = i/(50. - 1.)
		local v = 1

		Lvtx.SetPos(g_nVtx, 2*i+0, posX, posY, posZ)
		Lvtx.SetNormal(g_nVtx, 2*i+0, norX, norY, norZ)
		Lvtx.SetDiffuse(g_nVtx, 2*i+0, r, g, b, a)
		Lvtx.SetUV(g_nVtx, 2*i+0, 0, u, v)

		posY = 1.0
		u = i/(50. - 1.)
		v = 0

		r = 128/255
		g = 128/255
		b = 128/255
		a = 128/255

		Lvtx.SetPos(g_nVtx, 2*i+1, posX, posY, posZ)
		Lvtx.SetNormal(g_nVtx, 2*i+1, norX, norY, norZ)

		Lvtx.SetDiffuse(g_nVtx, 2*i+1, r, g, b, a)
		Lvtx.SetUV(g_nVtx, 2*i+1, 0, u, v)
	end


	-- Lock�� �ɾ����� �ݵ�� UnLock
	Lvtx.UnLock(g_nVtx)


	-- Material Setup
	g_nMtl = Lmtl.New(		1,	1,	0	-- Ambient r, g, b
						,	1,	1 ,	0	-- Diffuse r, g, b
						,	0,	0 ,	0	-- Specular r, g, b
						,	0,	0 ,	0	-- Emissive r, g, b
						,	10			-- Power
						)


	-- Lighting Setup
	g_nLgt = Llgt.New(	"DIRECTIONAL"
						,	0,	0,	0	-- Ambient r, g, b
						,	1,	1 ,	1	-- Diffuse r, g, b
						,	0,	0 ,	0	-- Specular r, g, b

						,	0,	0 ,	0	-- Position x, y, z
						,	0,	0 ,	0	-- Direction x, y, z

						,	1000	--Range	
						,	0	--Fall	
						,	0	--Attn0	
						,	0	--Attn1	
						,	0	--Attn2	
						,	0	--Theta	
						,	0	--Phi	
						)


	return 0
end


function Lua_Destroy()
	return 0
end


function Lua_FrameMove()
	UpdateInput()

	-- ascii 37 is Left, 39 is Right
	if 1 == g_Keyboard[37] then
		return 8
	elseif 1 == g_Keyboard[39] then
		return 10
	end


	-- ������ļ���
	fTick = Lutil.GetTickCount()
	fAngle = fTick/500.0

	fCos = math.cos(fAngle)
	fSin = math.sin(fAngle)

	mtWorld._23 =  fSin
	mtWorld._32 = -fSin

	mtWorld._22 =  fCos
	mtWorld._33 =  fCos

--	sMsg = string.format("��: %f", fCos)
--	Lsys.WindowTitle(sMsg)

	DiffuseR, DiffuseG, DiffuseB = Lmtl.GetDiffuse(g_nMtl)

--	sMsg = string.format("Diffuse: %f %f %f", DiffuseR, DiffuseG, DiffuseB)
--	Lsys.WindowTitle(sMsg)


	LgtX = math.cos(fTick/350)
	LgtY = 1.0
	LgtZ = math.sin(fTick/350)

	Llgt.SetDirection(LgtX, LgtY, LgtZ)

	return 0

end

function Lua_Render()
	Ltex.Draw(g_nTex, 0, 0, Ltex.Width(g_nTex), Ltex.Height(g_nTex), 0, 0)

	-- ������ļ���
	--Ld3d.SetTransform( "WORLD", mtWorld)
	Ld3d.SetTransform( "WORLD"
	, mtWorld._11, mtWorld._12, mtWorld._13, mtWorld._14
	, mtWorld._21, mtWorld._22, mtWorld._23, mtWorld._24
	, mtWorld._31, mtWorld._32, mtWorld._33, mtWorld._34
	, mtWorld._41, mtWorld._42, mtWorld._43, mtWorld._44)

	-- �����(ī�޶�)����
	Ld3d.SetTransform( "VIEW", 0.0, 3.0, -5.0
						     , 0.0, 0.0,  0.0
							 , 0.0, 1.0,  0.0 )

	-- �������� ��� ����
	Ld3d.SetTransform( "PROJECTION", D3DMX_PI/4.0, 800./600.0, 1.0, 4000.0)

	Ld3d.SetRenderState("CullMode", "NONE")

	Lmtl.SetMaterial(g_nMtl)

	Llgt.SetLight(LgtX, 0)
	Llgt.LightEnable(LgtX, 1)

	Ld3d.SetRenderState( "LIGHTING", "TRUE" )
	Ld3d.SetRenderState( "AMBIENT", "0x00202020" )

--	Ld3d.SetRenderState("Zenable", "FALSE")
	Ltex.SetTexture(g_nTex2, 0)
	Lvtx.Render(g_nVtx)
	Ld3d.SetRenderState("ZENABLE", "TRUE")

	Lfont.Draw(g_nFnt, "�ؽ��� ����", 100, 50, "0xFFFFFFFF")
	return 0
end
