--
-- Begin Phase Script
--

Lsys.DoFile("Script/input.lua")


function Lua_Init()
	Lsys.ShowState( 1 )
	Ld3d.SetClearColor("0xFF006699")

	g_nFnt	= Lfont.New("HY����M", 32, 1, 0, "0XFFFF0000", "0XFFFFFF00", 1, 1)
	g_nTex	= Ltex.New("Texture/bg_01.bmp", "0xFFFF00FF")


	g_nSnd1 = Lsmd.New("Media/track2.wav")
	g_nSnd2 = Lsmd.New("Media/skiing.avi")

	Lsmd.Play(g_nSnd1)
	Lsmd.Play(g_nSnd2)
	

	--						vtx type,		  pt type, Primitive Num,  Vertex Num
	g_nVtx	= Lvtx.New("RHW Diffuse", "TRIANGLE LIST",             1,  3)


	if g_nVtx < 0 then
		return -1
	end

	-- Lock
	if Lvtx.Lock(g_nVtx) < 0 then
		return -1
	end

	--			vtx, array Idx,     x,     y,   z,   w,   color(r,g,b,a 0~1)
	Lvtx.SetVtx(g_nVtx,      0, 300.0, 100.0, 0.5, 1.0,	   1, 0, 0, 1);
	Lvtx.SetVtx(g_nVtx,      1, 500.0, 500.0, 0.5, 1.0,	   0, 0, 1, 1);
	Lvtx.SetVtx(g_nVtx,      2, 100.0, 500.0, 0.5, 1.0,	   0, 1, 0, 1);

	-- Lock�� �ɾ����� �ݵ�� UnLock
	Lvtx.UnLock(g_nVtx)

	return 0
end


function Lua_Destroy()
	return 0
end


function Lua_FrameMove()
	UpdateInput()

	-- ascii 37 is Left, 39 is Right
	if 1 == g_Keyboard[37] then
		return 5
	elseif 1 == g_Keyboard[39] then
		return 7
	end


	-- ���� ���� Modulator ����
--	a = 100
--	b = 34
--	c = a%b

--	sMsg = string.format("��: %d", c)
--	Lsys.WindowTitle(sMsg)

	return 0

end

function Lua_Render()

	Ltex.Draw(g_nTex, 0, 0, Ltex.Width(g_nTex), Ltex.Height(g_nTex), 0, 0)

	Ld3d.SetRenderState("ZENABLE", "FALSE")
	Lvtx.Render(g_nVtx)
	Ld3d.SetRenderState("ZENABLE", "TRUE")

	local hr = Lsmd.Draw(g_nSnd2, 0, 0, 400, 300, "0xBBFFFFAA")

	if hr <0 then
		Lsmd.Reset(g_nSnd2)
	end


	Lfont.Draw(g_nFnt, "2D�� RHW + Diffuse �ﰢ�� �׸���", 100, 50, "0xFFFFFFFF")


	return 0
end
