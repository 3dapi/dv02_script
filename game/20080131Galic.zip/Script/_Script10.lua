--
-- Begin Phase Script
--

Lsys.DoFile("Script/input.lua")


D3DX_PI		= 3.141592654
RAND_MAX		= 32767

m_mtViw =
{
	  1.0, 0.0, 0.0, 0.0
	, 0.0, 1.0, 0.0, 0.0
	, 0.0, 0.0, 1.0, 0.0
	, 0.0, 0.0, 0.0, 1.0
}

m_mtPrj =
{
	  1.0, 0.0, 0.0, 0.0
	, 0.0, 1.0, 0.0, 0.0
	, 0.0, 0.0, 1.0, 0.0
	, 0.0, 0.0, 0.0, 1.0
}

m_vEyePt={0,0,0}

mtWorld =
{
	  1.0, 0.0, 0.0, 0.0
	, 0.0, 1.0, 0.0, 0.0
	, 0.0, 0.0, 1.0, 0.0
	, 0.0, 0.0, 0.0, 1.0
}

mtWorld2=
{
	 30.0,  0.0,  0.0, 0.0
	, 0.0, 30.0,  0.0, 0.0
	, 0.0,  0.0, 30.0, 0.0
	, 0.0,  0.0,  0.0, 1.0
}


-- Simple function to define "hilliness" for terrain
function HeightField(x, y)

	return 9 * ( math.cos( x/20. + 0.2 ) * math.cos( y/15.-0.2) + 1.)
end


function IsTreePositionValid(nTree, idx)
	local x0
	local y0
	local z0

	local x1
	local y1
	local z1
	
	x0, y0, z0 = Lxbill.GetPos(nTree, idx)

	for i=0, idx-1, 1 do
		x1, y1, z1 = Lxbill.GetPos(nTree, i)

		local fDeltaX = math.abs( x0 - x1 )
		local fDeltaZ = math.abs( z0 - z1)

		local pp = fDeltaX ^ 2 + fDeltaZ ^ 2
		
		if 300.0 > pp then
			return 0
		end

	end
	
	return 1
end


NUM_TREES = 500


function Lua_Init()
	Ld3d.SetClearColor("0xFF006699")

	g_nFnt	= Lfont.New("HY����M", 32, 1, 0, "0XFFFF0000", "0XFFFFFF00", 1, 1)
	g_nTex1	= Ltex.New("Texture/bg_01.bmp", "0xFFFF00FF")
	g_nTex2	= Ltex.New("Texture/banana.bmp","0x00000000")

	--					Model Name				 Texture Folder Name
	m_pSkyBox	= Lxms.New("Texture/skybox2.x", "Texture/")
	m_pTerrain	= Lxms.New("Texture/seafloor.x", "Texture/")


	g_nBillTex1	= Ltex.New("Texture/Tree04.dds","0xFF000000", "Linear")
	g_nBillTex2	= Ltex.New("Texture/Tree05.dds","0xFF000000", "Linear")
	g_nBillTex3	= Ltex.New("Texture/Tree06.dds","0xFF000000", "Linear")

	m_pTree		= Lxbill.New(NUM_TREES)

	local pTxBill = {}

	pTxBill[1] = Ltex.Pointer(g_nBillTex1)
	pTxBill[2] = Ltex.Pointer(g_nBillTex2)
	pTxBill[3] = Ltex.Pointer(g_nBillTex3)



	-- Setup Billboard
	for i=0, NUM_TREES-1, 1 do
		
		local fTheta  = 2.0 * D3DX_PI* Lutil.Rand(360)/ 360.
		local fRadius = Lutil.Rand(340) * 0.3

		local x  = fRadius * math.sin(fTheta)
		local z  = fRadius * math.cos(fTheta)
		local y  = HeightField( x, z )

		Lxbill.SetPos(m_pTree, i, x, y, z)



		local fWidth  = 1.0 + 0.2 * (1+ Lutil.Rand(11))
		local fHeight = 1.4 + 0.4 * (1+ Lutil.Rand(11))
		
		-- Each tree is a random color between red and green
		local xr = 0.6 + Lutil.Rand(41) * 0.01
		local xg = 0.6 + Lutil.Rand(41) * 0.01
		local xb = 0
		local xa = 1


		fWidth  = fWidth *1
		fHeight = fHeight*1



		Lxbill.SetDimension(m_pTree, i, -fWidth, 0, fWidth, 2*fHeight)
		Lxbill.SetDiffuse(m_pTree, i, xr, xg, xb, xa)

		-- Pick a random texture for the tree
		local nIdx = Lutil.Rand(3) + 1

		Lxbill.SetTexPointer(m_pTree, i, pTxBill[nIdx])
		
	end

	Lxbill.SetupVtxBuf(m_pTree)
	




	-- Add some "hilliness" to the terrain

	nGeo=Lxms.GetGeomety(m_pTerrain)


	for i=0, nGeo-1, 1 do
		local iVtx
		iVtx = Lxms.GetVtxNum(m_pTerrain, i)	--�Է��� �ε���, ����� �ε����� �ش��ϴ� ���ؽ� ��

		if iVtx>0 then
			Lxms.Lock(m_pTerrain, i)

			for j=0, iVtx-1, 1 do
				local x
				local y
				local z
				local w
				local h

				x, y, z, w = Lxms.GetPos(m_pTerrain, i, j)

				y = HeightField( x, z )
				
				Lxms.SetPos(m_pTerrain, i, j,   x, y, z, 1)

			end--for

			Lxms.Unlock(i)

		end -- if
	end	-- for



	return 0

end


function Lua_Destroy()
	return 0
end


function Lua_FrameMove()
	UpdateInput()

	-- ascii 37 is Left, 39 is Right
	if 1 == g_Keyboard[37] then
		return 9
	elseif 1 == g_Keyboard[39] then
		return -1
	end


	-- q��ļ���
	m_dbGetTime = Lutil.TimeGetTime()
	fTime = m_dbGetTime * 0.0003

	---- ����� ����
	m_vEyePt	={ 150.0, 150.0, 150.0 }
	vLookatPt	={ 0.0, 0.0, 0.0 }
	vUpVec		={ 0.0, 1.0, 0.0 }

	m_vEyePt[1] = 25.0*math.cos( 0.8 * ( fTime ) )
	m_vEyePt[3] = 25.0*math.sin( 0.8 * ( fTime ) )
	m_vEyePt[2] = 10 + HeightField( m_vEyePt[1], m_vEyePt[3] )

	vLookatPt[1] = 25.0*math.cos( 0.8 * ( fTime + 0.5 ) )
	vLookatPt[3] = 25.0*math.sin( 0.8 * ( fTime + 0.5 ) )
	vLookatPt[2] = m_vEyePt[2] - 1.0


	-- Set up a rotation matrix to orient the billboard towards the camera.

	Lxbill.SetupCamera( m_pTree
						, m_vEyePt[1], m_vEyePt[2], m_vEyePt[3]
						, vLookatPt[1], vLookatPt[2], vLookatPt[3]
						, vUpVec[1], vUpVec[2], vUpVec[3])


	Lxbill.FrameMove( m_pTree)

	return 0

end

function Lua_Render()
--	Ltex.Draw(g_nTex1, 0, 0, Ltex.Width(g_nTex1), Ltex.Height(g_nTex1), 0, -100)

	-- �����(ī�޶�)����
	Ld3d.SetTransform( "VIEW"
						, m_vEyePt[1], m_vEyePt[2], m_vEyePt[3]
						, vLookatPt[1], vLookatPt[2], vLookatPt[3]
						, vUpVec[1], vUpVec[2], vUpVec[3])

	-- �������� ��� ����
	Ld3d.SetTransform( "PROJECTION"
						, D3DX_PI/4.0
						, 800./600.0
						, 1.0
						, 4000.0)

	Ld3d.SetRenderState( "CULLMODE",	"NONE" )
	Ld3d.SetRenderState( "DITHERENABLE","TRUE" )
	Ld3d.SetRenderState( "ZENABLE",		"TRUE" )
	Ld3d.SetRenderState( "LIGHTING",	"FALSE" )

	-- Set up the default texture states
	Ld3d.SetTextureStageState( 0, "COLORARG1", "TEXTURE" )
	Ld3d.SetTextureStageState( 0, "COLORARG2", "DIFFUSE" )
	Ld3d.SetTextureStageState( 0, "COLOROP", "MODULATE" )

	Ld3d.SetTextureStageState( 0, "ALPHAARG1", "TEXTURE" )
	Ld3d.SetTextureStageState( 0, "ALPHAOP", "SELECTARG1" )

	Ld3d.SetSamplerState( 0, "MINFILTER", "LINEAR" )
	Ld3d.SetSamplerState( 0, "MAGFILTER", "LINEAR" )
	Ld3d.SetSamplerState( 0, "MIPFILTER", "LINEAR" )
	Ld3d.SetSamplerState( 0, "ADDRESSU", "CLAMP" )
	Ld3d.SetSamplerState( 0, "ADDRESSV", "CLAMP" )


	Ld3d.SetTransform( "WORLD", mtWorld)	-- ������ļ���
	Lxms.Render(m_pTerrain)
	Ld3d.SetTransformI( "WORLD")			-- ���� ���ȯ��

	Ld3d.SetTransform("WORLD", mtWorld2)
	Lxms.Render(m_pSkyBox)
	Ld3d.SetTransformI( "WORLD")


	Lxbill.Render(m_pTree)


	Lfont.Draw(g_nFnt, "������ ������", 100, 50, "0xFFFFFFFF")
	return 0
end

