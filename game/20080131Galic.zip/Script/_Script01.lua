--
-- Ime Script
--
-- Lime.Enable(0, 1)														// 0: Enable, 1: Disable
-- Lime.IsEnable()															// Is Enable? return 0, 1
-- Lime.Str()																// GetString
-- Lime.StrBeam()															// Get String with Beam
-- Lime.StrStar()															// Get String with Star
-- Lime.Set()																// Ime Set: Active and It will be all clear
-- Lime.Reset()																// Ime Reset: Disable and It will be all clear


Lsys.DoFile("Script/input.lua")


function Lua_Init()
	Ld3d.SetClearColor("0xFF006699")
	g_nFnt	= Lfont.New("HY��������M", 24, 2, 0, "0XFFFFFFFF", "0XFF111111", 1, 1)
	Lsys.ShowState(0)

--	Lime.Set()

	strMsg = "�ѱ� IME: �����Ϸ��� Enter Key�� �ſ� ġ����"

	return hr

end


function Lua_Destroy()
	-- ����� �������� IME�� ��Ȱ��ȭ ��Ų��.
	Lime.Reset()
	return 0
end


strMsg={0}

function Lua_FrameMove()
	UpdateInput()

	-- ascii 37 is Left, 39 is Right
	if 1 == g_Keyboard[37] then
		return -1
	elseif 1 == g_Keyboard[39] then
		return 2
	end


--	if 1 == Lime.IsEnable() then
		strMsgT = Lime.StrBeam()
		Lsys.WindowTitle(strMsgT)
--	end


	if 1 == g_Keyboard[13] then
		if 1 == Lime.IsEnable() then
			strMsg = Lime.Str()
			Lime.Reset()			
		else
			Lime.Set()
		end
	end

	return 0

end

function Lua_Render()
	LxUtil.Command("Render Grid")
	Lfont.Draw(g_nFnt, strMsg, 100, 50, "0xFFFFFFFF")

	return 0
end


