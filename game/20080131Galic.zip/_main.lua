
--
-- �ʱ� ����
-- Date: 2006-10-19

function Lua_Create()
	Lsys.ScriptFile( 1, "Script/_Script01.lua")
	Lsys.ScriptFile( 2, "Script/_Script02.lua")
	Lsys.ScriptFile( 3, "Script/_Script03.lua")
	Lsys.ScriptFile( 4, "Script/_Script04.lua")
	Lsys.ScriptFile( 5, "Script/_Script05.lua")
	Lsys.ScriptFile( 6, "Script/_Script06.lua")
	Lsys.ScriptFile( 7, "Script/_Script07.lua")
	Lsys.ScriptFile( 8, "Script/_Script08.lua")
	Lsys.ScriptFile( 9, "Script/_Script09.lua")

--	Lsys.ConsoleSet(1)														-- Using Console window
	Lsys.SetClearColor("0xFF006699")
	Lsys.ShowCursor(1)														--���� ���콺�����͸� ������

	hr = Lsys.CreateWindow(-1, -1, 1024, 768, "Galic Soft(��) Game Application(v0.8)", 0)			-- Window create. position x, position y, screen width, screen height, title, fullmode?...


	return hr
end

