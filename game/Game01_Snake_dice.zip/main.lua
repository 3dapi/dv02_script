-- File: script.lua
-- Owner: Shim, Vegatron
-- Date: 2006-03-13
-- Update:
-- LuaApp.exe File call main.lua. main.lua is main script file.

-- Reseverd Function.
-- Lua_Create()
-- Lua_Init()
-- Lua_Destroy()
-- Lua_FrameMove()
-- Lua_Render()



-- Mcl_ Functions.

-- Mcl_CreateWindow(position_x, position_y, "title", FullMode)			// Window Create		
-- Mcl_Release()														// Window Release
-- Mcl_Sleep( time_milli_sceond)										// Sleep

-- Mcl_KeyboardAll()													// keyboard All Key
-- Mcl_KeyboardOne( ascii )												// keyboard One Key
-- Mcl_MousePos()														// Mouse Position x, y, z
-- Mcl_MouseEvnt()														// Mouse Event Left, Right and M Button

-- Mcl_SetWindowTitle("title")											// Window Title
-- Mcl_MessageBox("Message", "Title", option)							// Window Box

-- Mcl_GetScnSize()														// ȭ���� ũ�⸦ ��������
-- Mcl_GetWindowStyle()												
-- Mcl_SetWindowStyle( style)											// window Style
-- Mcl_ShowState( Show )												// State ���̱� Show value is 1 or 0
-- Mcl_ChangeMode()														// Full <--> Window
-- Mcl_SetClearColor( Color )											// ���ȭ�� Ŭ���� ������ Color is ARGB color
-- Mcl_GetClearColor()													// ���ȭ�� Ŭ���� ���� ��������

-- Mcl_TextureLoad( "File_Name" )										// �̹��� ���� �ε� return texture index
-- Mcl_TextureRelease( index )											// �̹��� ���� ����
-- Mcl_TextureWidth( index )											// �̹��� ���� �ʺ�
-- Mcl_TextureHeight( index	)											// �̹��� ���� ����
-- Texture index, image region left, top, right, bottom
	-- screen position x, screen position y

-- Mcl_TextureDraw( texture_index
--					, Image_left
--					, Image_top
--					, Image_right
--					, Image_bottom
--					, screen_position_x
--					, screen_position_y	)								// �̹��� �׸���

-- Mcl_SoundLoad( "File_Name")											// ���� ���� �ε� return sound index
-- Mcl_SoundRelease( index )											// ���� ���� ����
-- Mcl_SoundPlay( index )												// ���� �÷���
-- Mcl_SoundStop( index )												// ���� Stop
-- Mcl_SoundReset( index )												// ���� Reset

-- Mcl_FontLoad("Font_Name", Height, Style:Thin,Normal,Bold, Italic?)	// ��Ʈ �ε� return font index
-- Mcl_FontRelease( index )												// ��Ʈ ����
-- Mcl_FontDraw( index, "String", screen_position_x, screen_position_y, "color")

-- Mcl Utilities
-- Mcl_GetTime()														// return time value after program start
-- Mcl_Mod(v1, v2)														// Modulate return v1 % v2
-- Mcl_Rand(v1)															// Randdom return rand()%v1
-- Mcl_SetConsole(v1)													// Console window. For error or message
-- Mcl_SendConsole(v1)													// Send String to colsole
-- Mcl_CastInt(v1)														// Casting Integer



dofile("script/input.lua")


function Lua_Create()
	-- Using Console window
	Mcl_SetConsole(0)
	Mcl_SetClearColor("0x00000000")

	-- Window create. position x, position y, screen width, screen height, , title, fullmode?...
	hr = Mcl_CreateWindow(10, 10, 800, 600, "mackerel", 0)
	return hr
end

g_TxId	={}
g_TxW	={}
g_TxH	={}

g_Snd = {}

g_NowPos = {}
g_NextPos = {}
g_NowPosX = {}
g_NowPosY = {}
g_PosXflag = {}
g_StartFlag	= {}
g_AvatarAnim = {}
g_AvatarFrame = {}

g_WarpUp = {}
g_WarpDown = {}
g_WarpPos = {}

g_nFnt ={}

g_TxTime ={}
g_TxIdx ={}


function Lua_Init()
	Mcl_SetWindowTitle( "Snake Dice !!!")
	g_TxId[1]	= Mcl_TextureLoad("Texture/dice1.png")
	g_TxId[2]	= Mcl_TextureLoad("Texture/dice2.png")
	g_TxId[3]	= Mcl_TextureLoad("Texture/dice3.png")
	g_TxId[4]	= Mcl_TextureLoad("Texture/dice4.png")
	g_TxId[5]	= Mcl_TextureLoad("Texture/dice5.png")
	g_TxId[6]	= Mcl_TextureLoad("Texture/dice6.png")

	g_TxW[1]	= Mcl_TextureWidth(	g_TxId[1]	)
	g_TxH[1]	= Mcl_TextureHeight(g_TxId[1]	)

	g_TxId[7]	= Mcl_TextureLoad("Texture/player_lmove.png")
	g_TxId[8]	= Mcl_TextureLoad("Texture/player_rmove.png")
	g_TxId[9]	= Mcl_TextureLoad("Texture/player_idle1.png")
	g_TxId[10]	= Mcl_TextureLoad("Texture/player_idle2.png")

	g_TxW[2]	= Mcl_TextureWidth(	g_TxId[7]	)
	g_TxH[2]	= Mcl_TextureHeight(g_TxId[7]	)

	g_TxId[11]	= Mcl_TextureLoad("Texture/board.png")
	g_TxW[3]	= Mcl_TextureWidth(	g_TxId[11]	)
	g_TxH[3]	= Mcl_TextureHeight(g_TxId[11]	)

	g_Snd[1]	= Mcl_SoundLoad("Sound/damage.wav")
	g_Snd[2]	= Mcl_SoundLoad("Sound/trample.wav")
	g_Snd[3]	= Mcl_SoundLoad("Sound/warpdown.wav")
	g_Snd[4]	= Mcl_SoundLoad("Sound/warpup.wav")
	g_Snd[5]	= Mcl_SoundLoad("Sound/move3.wav")
	g_Snd[6]	= Mcl_SoundLoad("Sound/bigcheer.wav")
	g_Snd[7]	= Mcl_SoundLoad("Sound/start.wav")

	g_nFnt[1]	= Mcl_FontLoad("Arial", 15, 0,  0)
	g_nFnt[2]	= Mcl_FontLoad("����ü", 20,1, 0)
	g_nFnt[3]	= Mcl_FontLoad("�ü�ü", 25,2, 1)

	g_Dice		= 0
	
	g_WarpUp	= 0
	g_WarpDown	= 0
	g_WarpPos	= 0

	g_PlayerTotal	= 4
	g_Turn	= 0
	g_RepeatFlag	= 0
	g_EndFlag	= 0

	for i=0, 5, 1 do
		g_NowPos[i]		= 0
		g_NextPos[i]	= 0
		g_NowPosX[i]	= -10
		g_NowPosY[i]	= 0
		g_PosXflag[i]	= 1
		g_StartFlag[i]	= 0
		g_AvatarAnim[i] = 0
		g_AvatarFrame[i]= 0.3
	end

	g_MoveTimeFlag	= 0

	Mcl_ShowState(0)


	-- Animation�� ���� �޸𸮸� �Ҵ��ϰ� �ε����� Ÿ���� �����Ѵ�.
	for i=1, 1000, 1 do 
		g_TxTime[i] =0
		g_TxIdx[i] =0
	end

	return 1
end

	

function Lua_Destroy()
	return 1
end

-- Data update
function Lua_FrameMove()

	-- Update Keyboard and Mouse
	UpdateInput()


	if 1 == g_Keyboard[65] then
	end

	if (1 == g_Mouse[4] and g_Mouse[1] >= 510 and g_Mouse[1] <= 630 and g_Mouse[2] >= 450 and g_Mouse[2] <= 560 and g_TxIdx[1] == 14 and g_EndFlag == 0) 
		or (1 == g_Mouse[4] and g_Mouse[1] >= 510 and g_Mouse[1] <= 630 and g_Mouse[2] >= 450 and g_Mouse[2] <= 560 and g_StartFlag[g_Turn] == 0 and g_EndFlag == 0) then
			
			if 	g_RepeatFlag == 1 then
				g_RepeatFlag = 0
			else
				if g_Turn == g_PlayerTotal then
					g_Turn = 1
				else g_Turn = g_Turn + 1
				end
			end

			g_Dice = Mcl_Rand(6) + 1
			--Dice Sound
			Mcl_SoundPlay(g_Snd[2])

			if g_StartFlag[g_Turn] == 1 then
				g_NextPos[g_Turn] = g_NowPos[g_Turn] + (g_Dice*10)
				end
			--��ŸƮ�� ������ ó��
			if g_StartFlag[g_Turn] == 0 then
				g_StartFlag[g_Turn] = 1
				g_NowPosX[g_Turn] = 0
				g_NextPos[g_Turn] = g_NowPos[g_Turn] + (g_Dice-1)*10
				end
		
			g_TxIdx[1] = 0
	end

	if 1 == g_Keyboard[66] then
		Mcl_SoundPlay(g_Snd[7])
		for i=0, 5, 1 do
			g_NowPos[i]		= 0
			g_NextPos[i]	= 0
			g_NowPosX[i]	= -10
			g_NowPosY[i]	= 0
			g_PosXflag[i]	= 1
			g_StartFlag[i]	= 0
			g_AvatarAnim[i] = 0
			g_AvatarFrame[i]= 0.3
		end
		g_Turn	= 0
		g_RepeatFlag	= 0
		g_EndFlag	= 0
	end

	if 1 == g_Mouse[5] then
		Mcl_ShowState(1)
	else
		Mcl_ShowState(0)
	end


	-- Get Current Time
	fCurTime = Mcl_GetTime()

	
	-- Setting Animation Index for Dice

	if	fCurTime > (g_TxTime[1]+0.07) then
		g_TxIdx[1]	= g_TxIdx[1] + 1
		g_TxTime[1] = fCurTime

		if g_TxIdx[1]>=15 then
			g_MoveTimeFlag = fCurTime
			g_TxIdx[1] = 14
		end
	end
	-- Setting Animation Index for Mario

	if	(g_TxTime[1] == g_MoveTimeFlag) and fCurTime > (g_TxTime[7]+g_AvatarFrame[g_Turn]) and g_EndFlag == 0 then
		g_TxIdx[7]	= g_TxIdx[7] + 1
		g_TxTime[7] = fCurTime

		if (g_WarpUp == 0) then
			if (g_NowPos[g_Turn] < g_NextPos[g_Turn]) then

				if g_PosXflag[g_Turn] == 1 then 
					g_AvatarAnim[g_Turn]	= 8
					g_AvatarFrame[g_Turn]	= 0.06 
					end
				if g_PosXflag[g_Turn] == -1 then 
					g_AvatarAnim[g_Turn]	= 7 
					g_AvatarFrame[g_Turn]	= 0.06
					end

				g_NowPosX[g_Turn] = g_NowPosX[g_Turn] + g_PosXflag[g_Turn]

				if g_NowPosX[g_Turn] == 91 then 
					g_NowPosX[g_Turn] = g_NowPosX[g_Turn] - 1
					g_NowPosY[g_Turn] = g_NowPosY[g_Turn] + 1
					g_NowPos[g_Turn] = g_NowPos[g_Turn] + 10
					g_PosXflag[g_Turn] = g_PosXflag[g_Turn] * -1

				else
					if g_NowPosX[g_Turn] == -1 then 
						g_NowPosX[g_Turn] = g_NowPosX[g_Turn] + 1
						g_NowPosY[g_Turn] = g_NowPosY[g_Turn] + 1
						g_NowPos[g_Turn] = g_NowPos[g_Turn] + 10
						g_PosXflag[g_Turn] = g_PosXflag[g_Turn] * -1
					else
						g_NowPos[g_Turn] = g_NowPos[g_Turn] + 1
					end
				end

				if (g_NowPos[g_Turn] > 990) then 
					Mcl_SoundPlay(g_Snd[6])
					g_EndFlag = 1
				end
				
				Mcl_SoundPlay(g_Snd[5])

			end

			if (g_NowPos[g_Turn] == g_NextPos[g_Turn]) then

				for i=1, g_PlayerTotal, 1 do
					if (g_NowPos[g_Turn] == g_NowPos[i]) and (i ~= g_Turn) and (g_StartFlag[i] == 1) then

						Mcl_SoundPlay(g_Snd[1])

						g_NowPos[i]		= 0
						g_NextPos[i]	= 0
						g_NowPosX[i]	= -10
						g_NowPosY[i]	= 0
						g_PosXflag[i]	= 1
						g_StartFlag[i]	= 0
						g_AvatarAnim[i] = 0
						g_AvatarFrame[i]= 0.3

						g_RepeatFlag = 1
						end
				end

				g_AvatarAnim[g_Turn]		= 10
				g_AvatarFrame[g_Turn]		= 0.5

				--������ �÷��̾�ƹ�Ÿ�� ǥ��
				if 	g_RepeatFlag == 1 then
					g_AvatarAnim[g_Turn]		= 9
					g_AvatarFrame[g_Turn]		= 0.5
				else
					if g_Turn == g_PlayerTotal then
						g_AvatarAnim[1]		= 9
						g_AvatarFrame[1]	= 0.5
					else
						g_AvatarAnim[g_Turn+1]		= 9
						g_AvatarFrame[g_Turn+1]		= 0.5
					end
				end
				--���� ���ǹ� �׷�	
				if g_NowPos[g_Turn] == 30 then 
					g_WarpPos = 150
					g_WarpUp = 1	end
				if g_NowPos[g_Turn] == 70 then
					g_WarpPos = 110
					g_WarpUp = 1 	end
				if g_NowPos[g_Turn] == 190 then 
					g_WarpPos = 730
					g_WarpUp = 1	end
				if g_NowPos[g_Turn] == 170 then 
					g_WarpPos = 370
					g_WarpUp = 1	end
				if g_NowPos[g_Turn] == 230 then 
					g_WarpPos = 350
					g_WarpUp = 1	end
				if g_NowPos[g_Turn] == 310 then 
					g_WarpPos = 550
					g_WarpUp = 1	end
				if g_NowPos[g_Turn] == 330 then 
					g_WarpPos = 450
					g_WarpUp = 1	end
				if g_NowPos[g_Turn] == 390 then 
					g_WarpPos = 590
					g_WarpUp = 1	end
				if g_NowPos[g_Turn] == 470 then 
					g_WarpPos = 530
					g_WarpUp = 1	end
				if g_NowPos[g_Turn] == 690 then 
					g_WarpPos = 870
					g_WarpUp = 1	end
				if g_NowPos[g_Turn] == 750 then 
					g_WarpPos = 850
					g_WarpUp = 1	end
				if g_NowPos[g_Turn] == 790 then 
					g_WarpPos = 990
					g_WarpUp = 1	end
				if g_NowPos[g_Turn] == 890 then 
					g_WarpPos = 910
					g_WarpUp = 1	end

				if g_NowPos[g_Turn] == 210 then 
					g_WarpPos = 10
					g_WarpDown = 1	end
				if g_NowPos[g_Turn] == 270 then 
					g_WarpPos = 50
					g_WarpDown = 1	end
				if g_NowPos[g_Turn] == 290 then 
					g_WarpPos = 90
					g_WarpDown = 1	end
				if g_NowPos[g_Turn] == 430 then 
					g_WarpPos = 250
					g_WarpDown = 1	end
				if g_NowPos[g_Turn] == 570 then 
					g_WarpPos = 410
					g_WarpDown = 1	end
				if g_NowPos[g_Turn] == 650 then 
					g_WarpPos = 130
					g_WarpDown = 1	end
				if g_NowPos[g_Turn] == 670 then 
					g_WarpPos = 510
					g_WarpDown = 1	end
				if g_NowPos[g_Turn] == 710 then 
					g_WarpPos = 490
					g_WarpDown = 1	end
				if g_NowPos[g_Turn] == 830 then 
					g_WarpPos = 610
					g_WarpDown = 1	end
				if g_NowPos[g_Turn] == 930 then 
					g_WarpPos = 630
					g_WarpDown = 1	end
				if g_NowPos[g_Turn] == 950 then 
					g_WarpPos = 810
					g_WarpDown = 1	end
				if g_NowPos[g_Turn] == 970 then 
					g_WarpPos = 770
					g_WarpDown = 1	end
			end
		end

		if (g_WarpUp == 1) or (g_WarpDown == 1) then
			g_NextPos[g_Turn] = g_WarpPos
			g_NowPos[g_Turn] = g_WarpPos

--			g_AvatarFrame[g_Turn]	= 0.3

			if g_WarpDown == 1 then 
--				g_AvatarAnim[g_Turn]	= 10 
				Mcl_SoundPlay(g_Snd[3])
				end
			if g_WarpUp == 1 then 
--				g_AvatarAnim[g_Turn]	= 9 
				Mcl_SoundPlay(g_Snd[4])
				end

			--���� ��ġ Update
			if (g_WarpPos >= 0 and g_WarpPos <= 99) or
				 (g_WarpPos >= 200 and g_WarpPos <= 299) or
				 (g_WarpPos >= 400 and g_WarpPos <= 499) or
				 (g_WarpPos >= 600 and g_WarpPos <= 699) or
				 (g_WarpPos >= 800 and g_WarpPos <= 899) then

				 g_NowPosX[g_Turn] = Mcl_Mod(g_WarpPos, 100)
				 g_PosXflag[g_Turn] = 1
			end
			if (g_WarpPos >= 100 and g_WarpPos <= 199) or
				 (g_WarpPos >= 300 and g_WarpPos <= 399) or
				 (g_WarpPos >= 500 and g_WarpPos <= 599) or
				 (g_WarpPos >= 700 and g_WarpPos <= 799) or
				 (g_WarpPos >= 900 and g_WarpPos <= 999) then

				 g_NowPosX[g_Turn] = 90 - Mcl_Mod(g_WarpPos, 100)
				 g_PosXflag[g_Turn] = -1
			end
			g_NowPosY[g_Turn] = Mcl_CastInt(g_WarpPos / 100)

			g_WarpUp = 0
			g_WarpDown = 0

			for i=1, g_PlayerTotal, 1 do
					if (g_NowPos[g_Turn] == g_NowPos[i]) and (i~=g_Turn) and (g_StartFlag[i] == 1) then

						Mcl_SoundPlay(g_Snd[1])

						g_NowPos[i]		= 0
						g_NextPos[i]	= 0
						g_NowPosX[i]	= -10
						g_NowPosY[i]	= 0
						g_PosXflag[i]	= 1
						g_StartFlag[i]	= 0
						g_AvatarAnim[i] = 0
						g_AvatarFrame[i]= 0.3

						g_RepeatFlag = 1
					end
			end
		end
		--�ƹ�Ÿ �ִϸ��̼� ����
		if g_TxIdx[7] >=5 then
			g_TxIdx[7] = 0
		end
	end
	 -- ���� ����
--	local sMsg = string.format("Turn = %d / NowPos = %d %d ", g_Turn, g_NowPos[g_Turn], g_NowPosX[g_Turn])
--	Mcl_SetWindowTitle( " ", sMsg)

end

-- Game Render
function Lua_Render()

	if (g_EndFlag == 1) then
		Mcl_TextureDraw(g_TxId[11],
				0, 0	,g_TxW[3]	,g_TxH[3],	0,	0)
		Mcl_FontDraw(g_nFnt[2], "������ ����Ǿ���", 100, 230, "0xFFFF00FF")
		Mcl_FontDraw(g_nFnt[3], "�ٽ� ������ B Ű�Դϴ�.", 100, 260, "0xFFFFFFFF")
	else
		-- Draw BG
		Mcl_TextureDraw(g_TxId[11],
				0, 0	,g_TxW[3]	,g_TxH[3],	0,	0)
		
		-- Draw Dice
		Mcl_TextureDraw(g_TxId[g_Dice],
				g_TxIdx[1] * g_TxW[1] / 15,0	,(g_TxIdx[1]+1) * g_TxW[1]/15	,g_TxH[1],510,460)

		-- Draw Avatar (now Position)
		for i=1, g_PlayerTotal, 1 do
			Mcl_TextureDraw(g_TxId[g_AvatarAnim[i]],
					g_TxW[2] * (g_TxIdx[7])/5, 0, g_TxW[2]* (g_TxIdx[7]+1)/5, g_TxH[2], 7+ 5*(g_NowPosX[i]), 540-59*g_NowPosY[i])

		end
	end

	return 1
end
