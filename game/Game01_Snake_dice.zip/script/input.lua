-- File: Input.lua
-- Owner: Heesung Oh, copy reft
-- Date: 2005-03-08
-- Update
-- Description: Keyboard and mouse control
-- g_Keyboard: Keyboard array. Index 1~256. it is matched ASCII.
-- g_Mouse: Mouse array. g_Mouse[1]: mouse position x, g_Mousep[2]: mouse position y, g_Mouse[3]: mouse z position
-- g_Mouse[4]: Left button down, g_Mouse[5]: Right Button down, g_Mouse[6]: M button down


g_Keyboard={}
g_Mouse ={}


function UpdateInput()

	for i=1, 256, 1 do
		g_Keyboard[i] = Mcl_KeyboardOne(i)
	end

	-- Get mouse postion
	MouseX, MouseY, MouseZ = Mcl_MousePos()

	-- Get mouse event
	MouseEvntL, MouseEvntR, MouseEvntM = Mcl_MouseEvnt()

	g_Mouse[1] = MouseX
	g_Mouse[2] = MouseY
	g_Mouse[3] = MouseZ

	g_Mouse[4]=MouseEvntL
	g_Mouse[5]=MouseEvntR
	g_Mouse[6]=MouseEvntM
	
	return 0
end




