-- Reseverd Function
-- Lua_Create()
-- Lua_Init()
-- Lua_Destroy()
-- Lua_FrameMove()
-- Lua_Render()



function Lua_Create()
	hr = Mcl_CreateWindow(10, 10, 700, 700, "mackerel", 0)
	return hr
end

g_TxId	={}
g_TxW	={}
g_TxH	={}

g_Dice  ={}
g_Mouse ={}

g_Snd = {}

g_Dice = {}
g_PosNum = {}
g_PosFlagX = {}
g_PosFlagY = {}

g_nFnt ={}

g_MarioFlag = {}

g_TxTime ={}
g_TxIdx ={}


function Lua_Init()

	local sMessage = string.format("���콺: %d %d \n", g_Mouse[1], g_Mouse[2])
	Mcl_SendConsole(sMessage)


	g_TxId[1]	= Mcl_TextureLoad("Texture/dice1.png")
	g_TxId[2]	= Mcl_TextureLoad("Texture/dice2.png")
	g_TxId[3]	= Mcl_TextureLoad("Texture/dice3.png")
	g_TxId[4]	= Mcl_TextureLoad("Texture/dice4.png")
	g_TxId[5]	= Mcl_TextureLoad("Texture/dice5.png")
	g_TxId[6]	= Mcl_TextureLoad("Texture/dice6.png")

	g_TxW[1]	= Mcl_TextureWidth(	g_TxId[1]	)
	g_TxH[1]	= Mcl_TextureHeight(	g_TxId[1]	)

	g_TxId[7]	= Mcl_TextureLoad("Texture/mario.png")
	g_TxW[2]	= Mcl_TextureWidth(	g_TxId[7]	)
	g_TxH[2]	= Mcl_TextureHeight(	g_TxId[7]	)

	g_TxId[8]	= Mcl_TextureLoad("Texture/board1.png")
	g_TxW[3]	= Mcl_TextureWidth(	g_TxId[8]	)
	g_TxH[3]	= Mcl_TextureHeight(	g_TxId[8]	)

	g_Snd[1]	= Mcl_SoundLoad("Sound/bounce.wav")
	g_Snd[2]	= Mcl_SoundLoad("Sound/trample.wav")

	g_nFnt[1]	= Mcl_FontLoad("Arial", 15, 0,  0)
	g_nFnt[2]	= Mcl_FontLoad("����ü", 20,1, 0)
	g_nFnt[3]	= Mcl_FontLoad("�ü�ü", 25,2, 1)

	g_Dice		= 0
	g_PosNum	= -1
	g_PosFlagX	= 0
	g_PosFlagY	= 0
	g_MarioFlag	= 0

	Mcl_ShowState(0)

	-- Animation�� ���� �޸𸮸� �Ҵ��ϰ� �ε����� Ÿ���� �����Ѵ�.
	for i=1, 1000, 1 do 
		g_TxTime[i] =0
		g_TxIdx[i] =0
	end

	return 1
end

	

function Lua_Destroy()
	return 1
end

-- Data update
function Lua_FrameMove()
	Key1 = Mcl_KeyboardOne(65)
	Key2 = Mcl_KeyboardOne(66)
	Key3 = Mcl_KeyboardOne(67)

	MouseX, MouseY, MouseZ = Mcl_MousePos()
	MouseEvntL, MouseEvntR, MouseEvntM = Mcl_MouseEvnt()

	g_Mouse[1] = MouseX
	g_Mouse[2] = MouseY
	g_Mouse[3] = MouseZ

	g_Mouse[4]=MouseEvntL
	g_Mouse[5]=MouseEvntR
	g_Mouse[6]=MouseEvntM


	if 1 == Key1 then
	end

	if 1 == g_Mouse[4] and g_Mouse[1] >= 596 and g_Mouse[2] >= 567  then

		g_Dice = Mcl_Rand(6) + 1
		--Dice Sound
		Mcl_SoundPlay(g_Snd[2])

		function Lua_Render()
		
			-- Draw BG
			Mcl_TextureDraw(g_TxId[8]		, 0							,0	,g_TxW[3]						,g_TxH[3],	0,	0)
			-- Draw Dice5
			Mcl_TextureDraw(g_TxId[g_Dice]	, g_TxIdx[1] * g_TxW[1] / 15,0	,(g_TxIdx[1]+1) * g_TxW[1]/15	,g_TxH[1],596,567)

			return 1
		end

		if  g_TxIdx[1] == 14 then 
			g_TxIdx[1] = 0
			g_PosNum = g_PosNum + g_Dice
			
			--Position(X) Update
			if (g_PosNum >= 0 and g_PosNum <= 9) or
				 (g_PosNum >= 20 and g_PosNum <= 29) or
				 (g_PosNum >= 40 and g_PosNum <= 49) or
				 (g_PosNum >= 60 and g_PosNum <= 69) or
				 (g_PosNum >= 80 and g_PosNum <= 89) then

				 g_PosFlagX = Mcl_Mod(g_PosNum, 10)
			end

			if (g_PosNum >= 10 and g_PosNum <= 19) or
				 (g_PosNum >= 30 and g_PosNum <= 39) or
				 (g_PosNum >= 50 and g_PosNum <= 59) or
				 (g_PosNum >= 70 and g_PosNum <= 79) or
				 (g_PosNum >= 90 and g_PosNum <= 99) then

				 g_PosFlagX = 9 - Mcl_Mod(g_PosNum, 10)
			end

			g_PosFlagY = g_PosNum / 10

--			if g_PosNum == 4 then g_PosNum = 16 end
--			if g_PosNum == 8 then g_PosNum = 12 end

			function Lua_Render()
			
				-- Draw Super Mario
				Mcl_TextureDraw(g_TxId[7], g_TxW[2] * 17/18, 0, g_TxW[2], g_TxH[2], 5+ 58*(g_PosFlagX), 630-70*g_PosFlagY)

				return 1
			end

			 -- ���� ����
			local sMsg = string.format("Dice = %d / PosNum = %d / Ypos = %d", g_Dice, g_PosNum, g_PosFlagY)
			Mcl_SetWindowTitle( " ", sMsg)

		end
	end

	if 1 == Key2 then
		Mcl_SoundPlay(g_Snd[1])
	end

	if 1 == Key3 then
		-- Game Render
	end
	

	if 1 == g_Mouse[5] then
		Mcl_ShowState(1)
	else
		Mcl_ShowState(0)


	-- Font Draw
	Mcl_FontDraw(g_nFnt[2], "�̺�Ʈ ������� A Key�Դϴ�.", 100, 230, "0xFFFF00FF")
	Mcl_FontDraw(g_nFnt[3], "����� B Ű�Դϴ�.", 100, 260, "0xFFFFFFFF")

	Mcl_TextureDraw(g_TxId[8], 0,0,g_TxW[3],g_TxH[3],0,0)

	-- Draw Super Mario
--	Mcl_TextureDraw(g_TxId[7], g_TxIdx[7] * g_TxW[2]/18, 0, (g_TxIdx[7]+1) * g_TxW[2]/18, g_TxH[2], 10, 630)

	return 1
end

