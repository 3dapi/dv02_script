-- Game Render
function phase()
	function Lua_Render()

		-- Draw Animation BMP
		Mcl_TextureDraw(
				g_TxId[2]
			,	g_TxIdx[2] * g_TxW[2]/30
			,	0
			,	(g_TxIdx[2]+1) * g_TxW[2]/30
			,	g_TxH[2]
			,	g_Mouse[1]
			,	g_Mouse[2])


		-- Draw Super Mario
		Mcl_TextureDraw(
				g_TxId[1]
			,	g_TxIdx[1] * g_TxW[1]/18
			,	0
			,	(g_TxIdx[1]+1) * g_TxW[1]/18
			,	g_TxH[1]
			,	300
			,	400)



		-- Font Draw
		Mcl_FontDraw(g_nFnt[1], sMsg, 100, 200, "0xFF00FFFF")
		Mcl_FontDraw(g_nFnt[2], "�̺�Ʈ ������� A Key�Դϴ�.", 100, 230, "0xFFFF00FF")
		Mcl_FontDraw(g_nFnt[3], "����� B Ű�Դϴ�.", 100, 260, "0xFFFFFFFF")

		

		return 1
	end
end

