

#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif


#include <stdio.h>

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>


lua_State* g_pL;


void main()
{
	printf("LUA Execute Script File and Load.\n\n");

	g_pL = lua_open();

	// load Lua libraries
	luaL_openlibs(g_pL);	
	
	
	
	// Load Script from File
	luaL_dofile(g_pL, "script/sample.lua");

	double result = lua_tonumber(g_pL, lua_gettop(g_pL));
	lua_pop(g_pL, 1);

	printf("The result was: %lf\n", result);
	


	lua_close(g_pL);
}