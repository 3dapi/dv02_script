-- Description: Texture Application

-- g_TxId: Texture Id Array
-- g_TxW: Texture width array
-- g_TxH: Texture height array

-- g_TxTime: Time for texture animation
-- g_TxIdx: Index for texture animation


g_TxId	={}
g_TxW	={}
g_TxH	={}

g_TxTime ={}
g_TxIdx ={}



function GameInit()
	g_TxId[1]	= Mcl_TextureLoad(		"Texture/mario.png")
	g_TxW[1]	= Mcl_TextureWidth(	g_TxId[1]	)
	g_TxH[1]	= Mcl_TextureHeight(	g_TxId[1]	)

	g_TxId[2]	= Mcl_TextureLoad(		"Texture/animate.png")
	g_TxW[2]	= Mcl_TextureWidth(		g_TxId[2]	)
	g_TxH[2]	= Mcl_TextureHeight(	g_TxId[2]	)

	Mcl_ShowState(0)

	-- Animation�� ���� �޸𸮸� �Ҵ��ϰ� �ε����� Ÿ���� �����Ѵ�.
	for i=1, 1000, 1 do 
		g_TxTime[i] =0
		g_TxIdx[i] =0
	end

	return 0
end



function GameUpdate()
	-- Get Current Time
	fCurTime = Mcl_GetTime()

	
	-- Setting Animation Index for Mario

	if	fCurTime > (g_TxTime[1]+0.2) then
		g_TxIdx[1]	= g_TxIdx[1] + 1
		g_TxTime[1] = fCurTime

		if g_TxIdx[1]>=18 then
			g_TxIdx[1] = 0
		end
	end


	-- Setting Animation Index for Animation BMP file

	if	fCurTime > (g_TxTime[2]+0.033) then
		g_TxIdx[2]	= g_TxIdx[2] + 1
		g_TxTime[2] = fCurTime

		if g_TxIdx[2]>=30 then
			g_TxIdx[2] = 0
		end
	end

	return 0
end



function GameRender()

	-- Draw Super Mario
	-- Texture index, image region left, top, right, bottom
	-- screen position x, screen position y
	Mcl_TextureDraw(
			g_TxId[1]
		,	g_TxIdx[1] * g_TxW[1]/18
		,	0
		,	(g_TxIdx[1]+1) * g_TxW[1]/18
		,	g_TxH[1]
		,	240
		,	160)

	
	-- Draw Animation BMP
	Mcl_TextureDraw(
			g_TxId[2]
		,	g_TxIdx[2] * g_TxW[2]/30
		,	0
		,	(g_TxIdx[2]+1) * g_TxW[2]/30
		,	g_TxH[2]
		,	400
		,	300)


	return 0
end


function GameDestroy()

end
