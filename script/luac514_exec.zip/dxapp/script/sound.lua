-- Description: Sound Application

-- g_Snd: Sound Array

g_Snd = {}

function GameInit()
	g_Snd[1]	= Mcl_SoundLoad("Sound/bounce.wav")

	Mcl_ShowState(0)

	Mcl_SoundPlay(g_Snd[1])
	return 0
end



function GameUpdate()
	return 0
end



function GameRender()
	return 0
end


function GameDestroy()
	return 0
end