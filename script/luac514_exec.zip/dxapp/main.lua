--*****************************************************************************
-- Simple Lua Application
--
-- Date: 2005-03-08
--
--*****************************************************************************


-- Game loop script file load.
--dofile("script/texture.lua")
--dofile("script/font.lua")
--dofile("script/sound.lua")

dofile("script/input.lua")
dofile("script/game.lua")

Lsys=
{
	CreateWindow = Mcl_CreateWindow
}


-- Lua Api for system environment
function Lua_Create()
	-- Window create. position x, position y, screen width, screen height, , title, fullmode?...
	hr = Lsys.CreateWindow(-1, -1, 800, 600, "mackerel", 0)
	return hr
end


-- game data init
function Lua_Init()
	return GameInit()
end


function Lua_Destroy()
	return GameDestroy()
end


-- Data update
function Lua_FrameMove()
	GameUpdate()
	return 0
	
end

function Lua_Render()
	return	GameRender()
end


