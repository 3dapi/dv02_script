fr = io.open ("test.txt","r")

while true do
	local line = fr:read("*line") -- all line

	if nil == line then break end

	print(line, "\n")
end

fr:close()

