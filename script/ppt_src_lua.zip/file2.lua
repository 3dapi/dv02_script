

print "-------------------------------------------------------------------------\n\n"
print "���� ����2: �������� �б�        ----------------------------------------\n\n"
print "-------------------------------------------------------------------------\n"

fr = io.open ("unit_lvl.csv","r")	-- ���� �ڵ� ���


count = 0

while 2 > count do
	local line = fr:read("*line")	-- �� �� �б�
	count = count + 1
	print(line, "\n")
end

print "-------------------------------------------------------------------------\n"


function escape(s)
	if string.find(s, '[,"]') then
		s = '"' .. string.gsub(s, '"', '""') .. '"'
	end
	return s
end


pattern = "(%S+),(%S+),(%S+),(%S+),(%S+),(%S+),(%S+),(%S+),(%S+)"

while true do
	local line = fr:read("*line")	-- �� �� �б�

	if nil == line then break end

	s1, s2, s3, s4, s5, s6, s7, s8, s9 = string.match(line, pattern)
	print(s1, s2, s3, s4, s5, s6, s7, s8, s9, "\n")

	print "-------------------------------------------------------------------------\n"

end


fr:close()


