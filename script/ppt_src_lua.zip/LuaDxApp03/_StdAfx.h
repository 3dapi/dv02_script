// 
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __StdAfx_H_
#define __StdAfx_H_

#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "dxerr9.lib")

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "dsound.lib")
#pragma comment(lib, "dxguid.lib")

#ifndef _DEBUG
	#pragma comment(lib, "Lua514.lib"				)	// Release Lua.lib
	#pragma comment(lib, "lib/DsSpirte.lib"		)
#else
	#pragma comment(lib, "Lua514_.lib"				)	// Debug Lua.lib
	#pragma comment(lib, "lib/DsSprite_.lib"	)
#endif


#define _WIN32_WINNT 0x0400

#include <vector>

#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tchar.h>

#include <d3dx9.h>
#include <dxerr9.h>

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>

#include "include/IDsTexture.h"
#include "include/IDsSprite.h"

#include "DxUtil.h"
#include "DsUtil.h"
#include "D3DEnum.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DUtil.h"

#include "resource.h"

#include "_McType.h"
#include "McUtil.h"


#include "Main.h"

#endif


