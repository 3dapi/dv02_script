// Implementation of the Utility Functions.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


void McUtil_ErrMsgBox(TCHAR *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	MessageBox(NULL, s, "Err", MB_OK | MB_ICONERROR);
}


char* McUtil_Forming(const char *Format, ...)
{
	static	char s[8192];
	static INT	n;
	va_list		v;
	
	memset(s, 0, 8192);
	va_start(v, Format);
	vsprintf(s, Format, v);
	va_end(v);
	
	return	s;
}


HANDLE	g_hCon;
DWORD	g_dWritten;

BOOL	g_bCon = true;


void	McUtil_SetConsole(BOOL bCon)
{
	g_bCon = bCon;
}

void McUtil_AllocConsole()
{
	if(!g_bCon)
		return;

	AllocConsole();
	g_hCon = GetStdHandle(STD_OUTPUT_HANDLE);
}


void	McUtil_SendConsole(TCHAR *s)
{
	if(g_bCon)
	{
		WriteConsole(g_hCon, s, strlen(s), &g_dWritten, NULL);
		printf(s);
	}
}

