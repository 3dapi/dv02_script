

#include "_StdAfx.h"


lua_State* g_pL;



int		g_dScnX;
int		g_dScnY;
int		g_dScnW;
int		g_dScnH;

char	g_sCls[256];
int		g_bFull;


// Basic Game Logic Function
int Lua_Init();
int Lua_Destroy();

int Lua_Update();

int Lua_Run();


// Lua Glue Function
static int Lua_Create(lua_State* );
static int Lua_Release(lua_State* );
static int Lua_Sleep(lua_State*	);



int main()
{
	INT hr=-1;
	g_pL = lua_open();
	
	// load Lua libraries
	luaL_openlibs(g_pL);

	CLnArray::LuaOpenLib(g_pL);
	CLuaVec3::LuaOpenLib(g_pL);

	
	lua_register(g_pL, "Lua_Sleep", Lua_Sleep);
	lua_register(g_pL, "Lua_Create", Lua_Create);
	lua_register(g_pL, "Lua_Release", Lua_Create);


	luaL_dofile(g_pL, "script/Script.lua");


	if(FAILED(hr=Lua_Init()))
	{
		printf("Game Init Failed\n");
		return -1;
	}
	
	Lua_Run();
	Lua_Destroy();
	
	lua_close(g_pL);


	return 1;
}



int Lua_Init()
{
	int hr;

	printf("Engine Start\n");

	// Scirpt�� �ִ� �Լ� ȣ��
	lua_getglobal(g_pL, "GameInit");
	lua_call(g_pL, 0, 1);

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 1;
}



int Lua_Destroy()
{
	int hr;

	lua_getglobal(g_pL, "GameDestroy");
	lua_call(g_pL, 0, 1);

	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	printf("Engine Destroy\n");

	if(FAILED(hr))
		return -1;

	return 1;
}



int Lua_Run()
{
	printf("Engine Run\n");

	while(1)
	{
		if(FAILED(Lua_Update()))
			break;
	}

	return 1;
}



int Lua_Update()
{
	int hr;

	lua_getglobal(g_pL, "GameUpdate");
	lua_call(g_pL, 0, 1);

	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 1;
}


// Lua Glue Function

static int Lua_Create(lua_State *L)
{
	int n = lua_gettop(L);

	if(n<4)
		return 0;

	g_dScnX = (int)lua_tonumber(L, 1);
	g_dScnY = (int)lua_tonumber(L, 2);
	g_dScnW = (int)lua_tonumber(L, 3);
	g_dScnH = (int)lua_tonumber(L, 4);

	g_sCls[256];
	memset(g_sCls, 0, sizeof(g_sCls));
	strcpy(g_sCls, lua_tostring(L, 5));

//	strcpy(g_sCls ,luaL_optstring(L, 5, NULL));

	g_bFull = (int)lua_tonumber(L, 6);

//	printf("Screen: %d %d %d %d %s %d\n", g_dScnX, g_dScnY, g_dScnW, g_dScnH, g_sCls, g_bFull);


	lua_pushnumber(L, 1);
	// lua_pushnumber �� ��ŭ ����
	return 1;
}


static int Lua_Release(lua_State *L)
{
	printf("Lua Release\n");
	
	return 0;
}


static int Lua_Sleep(lua_State *L)
{
	int n = lua_gettop(L);

	if(n<1)
		Sleep(1000);

	int nMilliSecond = (int)lua_tonumber(L, 1);

//	nMilliSecond = luaL_optint(L, 1, NULL);
	
	Sleep(nMilliSecond);

	return 0;
}