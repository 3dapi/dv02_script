-- Simple LUA Program

function GameInit()
	print("Script Game Init")
	succeed = Lua_Create(100, 100, 800, 600, "mackerel", 0)

	a = array.new(1000)
	a[10] = 3.4         -- setarray
	c= a[10]
	print(c)


	b = vector3(1,2,3)

	b.x = 30
	b.y = 40
	b.z = 50

	print(b.x)
	print(b.y)
	print(b.z)



	return succeed
end


function GameDestroy()
	return 1
end

c = 0

function GameUpdate()
	Lua_Sleep(500)

	c = c+2

	if c>2 then
		return -1
	end

	print("Script Game Update:", c)

	return 1
end

