// LnArray.h: interface for the CLnArray class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LNARRAY_H__67EA36CF_F8AA_40E0_884C_FB5029A1EC5D__INCLUDED_)
#define AFX_LNARRAY_H__67EA36CF_F8AA_40E0_884C_FB5029A1EC5D__INCLUDED_


struct NumArray
{
	int		size;
	double	values[1];
};

class CLnArray  
{
public:
	CLnArray();
	virtual ~CLnArray();


	static NumArray*	Check(lua_State *L);
	static int			New(lua_State *L);
	static int			Set(lua_State *L);
	static int			Get(lua_State *L);
	static int			Size(lua_State* L);


	static int	LuaOpenLib(lua_State *L);

};

#endif
