#ifndef _LUABIND_H_
#define _LUABIND_H_


template<class T> 
class LuaBind
{
	struct userdataType
	{
		T *pT;
	};

public:
	typedef int (T::*mfp)(lua_State *L );

	struct RegType
	{
		const char *name; 
		mfp mfunc;
	};
	
	// ��ü�� ��ƿ� ���.
	static void Register(lua_State *L)
	{
		lua_newtable(L);  // table �� ���� �����.
		int methods = lua_gettop(L); // ���� ������ ����

		luaL_newmetatable(L,T::className);
		int metatable = lua_gettop(L);

		lua_pushstring(L,T::className);
		lua_pushvalue(L,methods);
		lua_settable(L,LUA_GLOBALSINDEX);

		lua_pushliteral(L,"__metatable");
		lua_pushvalue(L,methods);
		lua_settable(L,metatable);

		lua_pushliteral(L,"__index");
		lua_pushvalue(L,methods);
		lua_settable(L,metatable);

		lua_pushliteral(L,"__tostring");
		lua_pushcfunction(L,tostring_T);
		lua_settable(L,metatable);

		lua_pushliteral(L,"__gc");
		lua_pushcfunction(L,gc_T);
		lua_settable(L,metatable);

		lua_newtable(L);
		int mt = lua_gettop(L);
		lua_pushliteral(L,"__call");
		lua_pushcfunction(L,new_T);
		lua_pushliteral(L,"new");
		lua_pushvalue(L,-2); // dup new_T function
		lua_settable(L,methods);
		lua_settable(L,mt);
		lua_setmetatable(L,methods);

		for( RegType *l = T::methods; l->name; l++)
		{ 
			lua_pushstring(L,l->name);
			lua_pushlightuserdata(L,(void*)l);
			lua_pushcclosure(L,thunk,1);
			lua_settable(L,methods);
		}
		lua_pop(L,2);
	}

	static T *check(lua_State *L,int narg)
	{
		userdataType *ud =
			static_cast<userdataType*>(luaL_checkudata(L,narg,T::className));

		if( !ud ) luaL_typerror(L,narg,T::className);
		return ud->pT;
	}
private:

	// ����Լ� �߼�
	static int thunk(lua_State *L)
	{
		T *obj = check(L,1);
		lua_remove(L,1);

		RegType *l = static_cast<RegType*>(lua_touserdata(L,lua_upvalueindex(1)));

		return (obj->*(l->mfunc))(L); 
	}
	
	// create a new T object and 
	// push onto the Lua stack a userdata containing a pointer to T object
	static int new_T(lua_State *L) 
	{
		int size;
		size = lua_gettop(L);
		lua_remove(L,1);
		size = lua_gettop(L);
		T *obj = new T(L);
		userdataType *ud = 
			static_cast<userdataType*>(lua_newuserdata(L,sizeof(userdataType)));
		ud->pT = obj;

		luaL_getmetatable(L,T::className);
		lua_setmetatable(L,-2);
		return 1;	
	}

	// garbage colletion metamethod
	static int gc_T(lua_State *L)  
	{
		userdataType *ud = static_cast<userdataType*>(lua_touserdata(L,1));
		T *obj = ud->pT;

		delete obj;
		return 0;
	}

	static int tostring_T(lua_State *L)
	{
		char buff[32];
		userdataType *ud = static_cast<userdataType*>(lua_touserdata(L,1));
		T *obj = ud->pT;
		sprintf(buff,"%p",obj);
		
		lua_pushfstring(L,"%s (%s)",T::className,buff);
		return 1;
	}

	LuaBind();  

};


#endif