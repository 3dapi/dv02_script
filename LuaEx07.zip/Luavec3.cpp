// Implementation of the CLuaVec3 class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


int	CLuaVec3::New(lua_State *L)
{
	int n = luaL_checkint(L, 1);
	int _cnt = lua_gettop(L);

	// �޸𸮸� �����Ѵ�.
	vector3* v = (vector3 *)lua_newuserdata(L, sizeof(vector3));

//	v=(vector3*)lua_touserdata(L,-1);
	
	if (_cnt>1)
	{
		v->a[0]=luaL_check_number(L,1);
		v->a[1]=luaL_check_number(L,2);
		v->a[2]=luaL_check_number(L,3);
	}
	else
		v->a[0] = v->a[1] = v->a[2] = 0;

	luaL_getmetatable(L, "LuaBook.vectors");
	lua_setmetatable(L, -2);				// �̰� �߿��ϴ�. �̰��� ������ ��Ÿ ���̺��� ������ �ȵȴ�.

	return 1;	// new userdatum is already on the stack
}




int CLuaVec3::Set(lua_State *L)
{
	vector3 *v	=	(vector3 *)lua_touserdata(L, 1);
	const char* i=luaL_check_string(L,2);
	double t=luaL_check_number(L,3);
	
	switch (*i)	 /* lazy! */
	{
		case 'x': case 'r': v->a[0]=t; break;
		case 'y': case 'g': v->a[1]=t; break;
		case 'z': case 'b': v->a[2]=t; break;
		default: break;
	}
	
	return 0;
}


int CLuaVec3::Get(lua_State *L)
{
	vector3*	v = (vector3 *)lua_touserdata(L, 1);
	const char* i =luaL_check_string(L,2);
	
	switch (*i) /* lazy! */
	{
		case 'x': case 'r': lua_pushnumber(L,v->a[0]); break;
		case 'y': case 'g': lua_pushnumber(L,v->a[1]); break;
		case 'z': case 'b': lua_pushnumber(L,v->a[2]); break;
		default: lua_pushnumber(L,0.0); break;
	}
	
	return 1;
}




static const luaL_reg LuaVec3 [] =
{
	{"set",		CLuaVec3::Set},
	{"get",		CLuaVec3::Get},
	{NULL, NULL}
};



int CLuaVec3::LuaOpenLib(lua_State *L)
{
	lua_register(L, "vector3",	CLuaVec3::New);
	luaL_newmetatable(L, "LuaBook.vectors");
	luaL_openlib(L, "vectors", LuaVec3, 0);
	
	// now the stack has the metatable at index 1 and
	// vector3 at index -2
	// metatable is at index -3
	// "structA" is at index -4
	
	lua_pushstring(L, "__index");
	lua_pushstring(L, "get");
	lua_gettable(L, -3);  /* get vector3.get */
	lua_settable(L, -4);  /* metatable.__index = vector3.get */
	
	lua_pushstring(L, "__newindex");
	lua_pushstring(L, "set");
	lua_gettable(L, -3); /* get vector3.set */
	lua_settable(L, -4); /* metatable.__newindex = vector3.set */
	
	return 0;
}
