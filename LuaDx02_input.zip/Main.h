// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_

class CMain : public CD3DApplication
{
protected:
	ID3DXFont*		m_pD3DXFont;        // D3DX font    
	
public:
	CMcInput*		m_pInput;			// Input
	INT				m_bShowState;
	
public:
	CMain();
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
	
	virtual HRESULT Init();
	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	virtual HRESULT Destroy();
	virtual HRESULT Render();
	virtual HRESULT FrameMove();
	
	HRESULT			RenderText();
};

extern CMain*		g_pApp;

#define		GHWND		g_pApp->m_hWnd
#define		GDEVICE		g_pApp->m_pd3dDevice


#endif