-- Texture Class
Texture={}

-- Texture Member Function
function Texture.Init(Tx)
	Tx.iW	=Mcl_TextureWidth(Tx.Id)
	Tx.iH	=Mcl_TextureHeight(Tx.Id)
end

function Texture.Draw(Tx, x, y, sX, sY, c)
	Mcl_TextureDraw(Tx.Id, 0, 0, Tx.iW, Tx.iH, x, y, sX, sY, c)
end


for i=1, 100, 1 do
	Texture[i]={}
	Texture[i].Id=-1
	Texture[i].iW=0
	Texture[i].iH=0
end



dofile("script/input.lua")


function Lua_Create()
	-- Using Console window
	Mcl_SetConsole(0)
	Mcl_SetClearColor("0x00000000")

	-- Window create. position x, position y, screen width, screen height, , title, fullmode?...
	hr = Mcl_CreateWindow(10, 10, 1024, 768, "Lenna", 0)

	return hr
end

function Lua_Init()
	g_nFnt1	= Mcl_FontLoad("HY�¹�M", 14, 1,  0)

	Texture[2].Id	= Mcl_TextureLoad("Texture/Lenna.jpg");	Texture.Init(Texture[2])

	return 1
end


function Lua_Destroy()
	Mcl_NetDestroy()
	return 1
end


nSndMsg= 1


function Lua_FrameMove()
	UpdateInput()

	return 1
end

function Lua_Render()
	Mcl_FontDraw(g_nFnt1, sTitle, 180, 300, "0xFFFFFF00")
	Texture.Draw(Texture[2], 300, 300, 0.5, 0.5, "0x80FFFFFF")
		
	return 1
end
