-- File: script.lua
-- Owner: Shim
-- Date: 2006-03-10
-- Update:
-- LuaApp.exe File call script.lua. script.lua is main script file.

-- Reseverd Function.
-- Lua_Create()
-- Lua_Init()
-- Lua_Destroy()
-- Lua_FrameMove()
-- Lua_Render()



-- Mcl_ Functions.

-- Mcl_CreateWindow(position_x, position_y, "title", FullMode)			// Window Create		
-- Mcl_Release()														// Window Release
-- Mcl_Sleep( time_milli_sceond)							// Sleep

-- Mcl_KeyboardAll()													// keyboard All Key
-- Mcl_KeyboardOne( ascii )												// keyboard One Key
-- Mcl_MousePos()														// Mouse Position x, y, z
-- Mcl_MouseEvnt()														// Mouse Event Left, Right and M Button

-- Mcl_SetWindowTitle("title")											// Window Title
-- Mcl_MessageBox("Message", "Title", option)							// Window Box

-- Mcl_GetScnSize()														// ȭ���� ũ�⸦ ��������
-- Mcl_GetWindowStyle()												
-- Mcl_SetWindowStyle( style)											// window Style
-- Mcl_ShowState( Show )												// State ���̱� Show value is 1 or 0
-- Mcl_ChangeMode()														// Full <--> Window
-- Mcl_SetClearColor( Color )											// ���ȭ�� Ŭ���� ������ Color is ARGB color
-- Mcl_GetClearColor()													// ���ȭ�� Ŭ���� ���� ��������

-- Mcl_TextureLoad( "File_Name" )										// �̹��� ���� �ε� return texture index
-- Mcl_TextureRelease( index )											// �̹��� ���� ����
-- Mcl_TextureWidth( index )											// �̹��� ���� �ʺ�
-- Mcl_TextureHeight( index	)											// �̹��� ���� ����
-- Texture index, image region left, top, right, bottom
	-- screen position x, screen position y

-- Mcl_TextureDraw( texture_index
--					, Image_left
--					, Image_top
--					, Image_right
--					, Image_bottom
--					, screen_position_x
--					, screen_position_y	)								// �̹��� �׸���

-- Mcl_SoundLoad( "File_Name")											// ���� ���� �ε� return sound index
-- Mcl_SoundRelease( index )											// ���� ���� ����
-- Mcl_SoundPlay( index )												// ���� �÷���
-- Mcl_SoundStop( index )												// ���� Stop
-- Mcl_SoundReset( index )												// ���� Reset

-- Mcl_FontLoad("Font_Name", Height, Style:Thin,Normal,Bold, Italic?)	// ��Ʈ �ε� return font index
-- Mcl_FontRelease( index )												// ��Ʈ ����
-- Mcl_FontDraw( index, "String", screen_position_x, screen_position_y, "color")

-- Mcl Utilities
-- Mcl_GetTime()														// return time value after program start
-- Mcl_Mod(v1, v2)														// Modulate return v1 % v2
-- Mcl_Rand(v1)															// Randdom return rand()%v1
-- Mcl_SetConsole(v1)													// Console window. For error or message
-- Mcl_SendConsole(v1)													// Send String to colsole
-- Mcl_CastInt(v1)														// Casting Integer

-- File: Input.lua
-- Owner: Heesung Oh, copy reft
-- Date: 2005-03-08
-- Update
-- Description: Keyboard and mouse control
-- g_Keyboard: Keyboard array. Index 1~256. it is matched ASCII.
-- g_Mouse: Mouse array. g_Mouse[1]: mouse position x, g_Mousep[2]: mouse position y, g_Mouse[3]: mouse z position
-- g_Mouse[4]: Left button down, g_Mouse[5]: Right Button down, g_Mouse[6]: M button down


g_Keyboard={}
g_Mouse ={}


function UpdateInput()

	for i=1, 256, 1 do
		g_Keyboard[i] = Mcl_KeyboardOne(i)
	end

	-- Get mouse postion
	MouseX, MouseY, MouseZ = Mcl_MousePos()

	-- Get mouse event
	MouseEvntL, MouseEvntR, MouseEvntM = Mcl_MouseEvnt()

	g_Mouse[1] = MouseX
	g_Mouse[2] = MouseY
	g_Mouse[3] = MouseZ

	g_Mouse[4]=MouseEvntL
	g_Mouse[5]=MouseEvntR
	g_Mouse[6]=MouseEvntM
	
	return 0
end

g_attack ={}
g_defens ={}

