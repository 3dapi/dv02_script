// Main.cpp: implementation of the CMain class.
//
//////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_dwCreationWidth           = 1024;
	m_dwCreationHeight          = 768;
	strcpy(m_strClassName, TEXT( "Particles" ));

	m_pFont                     = NULL;
	
	m_iLst						=0;
	memset(m_vLst, 0, sizeof m_vLst);
}




void CMain::AddParticle(D3DXVECTOR3 position, D3DXVECTOR3 trajectory, D3DCOLOR diffuse, float mass)
{
	sprintf(m_vLst[m_iLst++], "Pos(%3.f %3.f %3.f),  Direction(%3.f %3.f %3.f), Color(%ld), Mass: %3.f"
		, position.x, position.y, position.z
		, trajectory.x, trajectory.y, trajectory.z
		,	diffuse, mass);
}




HRESULT CMain::OneTimeSceneInit()
{
	SendMessage( m_hWnd, WM_PAINT, 0, 0 );
	
	return S_OK;
}


HRESULT CMain::FinalCleanup()
{
	return S_OK;
}



HRESULT CMain::Init()
{
	m_Script.Initialize();
	m_Script.doFile("init.lua");


	// Init the font
	LOGFONT LogFont;
	
	memset(&LogFont, 0, sizeof LogFont);
	
	LogFont.lfHeight = 18;
	LogFont.lfWeight = FW_BOLD;
	LogFont.lfCharSet = HANGEUL_CHARSET;
	strcpy(LogFont.lfFaceName, "Arial");
	D3DXCreateFontIndirect(m_pd3dDevice, &LogFont, &m_pFont);
	
	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE(	m_pFont	);
	SAFE_DELETE( m_pFont );
	m_Script.Terminate();

	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pFont->OnResetDevice();
	
	return S_OK;
}





HRESULT CMain::Invalidate()
{
	m_pFont->OnLostDevice();
	
	return S_OK;
}



HRESULT CMain::FrameMove()
{
	return S_OK;
}



HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.0f, 0L );
	
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	RenderText();
	
	return m_pd3dDevice->EndScene();
}


HRESULT CMain::RenderText()
{
	D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH] = TEXT("");
	RECT rc;
	ZeroMemory( &rc, sizeof(rc) );       
	
	
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	
	// Output display stats
	INT nNextLine = 0; 
	
	sprintf( szMsg, "%s %s", m_strDeviceStats, m_strFrameStats );

	nNextLine += 20; rc.top = nNextLine; rc.bottom = rc.top + 20;   
	m_pFont->DrawText( szMsg, -1, &rc, 0, fontColor );
	

	nNextLine += 20; rc.top = nNextLine; rc.bottom = rc.top + 20;   

	for(int i=0; i<m_iLst; ++i)
	{
		nNextLine += 20; rc.top = nNextLine; rc.bottom = rc.top + 20; 
		m_pFont->DrawText( m_vLst[i], -1, &rc, 0, 0xFFFF33FF);
	}
		

	return S_OK;
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
		case WM_PAINT:
			break;
	
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}

