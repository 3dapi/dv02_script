// script.h: interface for the Cscript class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __SCRIPT_H__
#define __SCRIPT_H__


extern "C"	// For implementing LUA
{
 #include <lua.h>
 #include <lualib.h>
}


class CScript  
{
public:
	CScript();
	virtual ~CScript();
	
	void Initialize();
	void Terminate();

	void doFile( const char* filename);

	void SetVar( const char* varname, double value);
	void SetVar( const char* varname, const char* value);

public:
	static lua_State* m_lua;
};

#endif // __SCRIPT_H__
