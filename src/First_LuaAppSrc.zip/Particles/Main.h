
#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
public:
	BOOL                    m_bLoadingApp;          // TRUE, if the app is loading
	ID3DXFont*				m_pFont;                // Font for drawing text

	CScript					m_Script;
	INT						m_iLst;
	char					m_vLst[32][128];
	
protected:
	virtual HRESULT OneTimeSceneInit();
	virtual HRESULT FinalCleanup();
	
	virtual HRESULT Init();
	virtual HRESULT Destroy();
	
	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT FrameMove();
	virtual HRESULT Render();
	
	HRESULT RenderText();
	
public:
	LRESULT MsgProc(HWND, UINT, WPARAM, LPARAM);
	CMain();

	void AddParticle(D3DXVECTOR3, D3DXVECTOR3, D3DCOLOR, float);
};

extern CMain*	g_pApp;

#endif
