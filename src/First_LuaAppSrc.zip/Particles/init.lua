pos = vector3(1, 2, 3)
traj= vector3(4, 5, 6)
diff= vector3(7, 8, 9)

AddParticle( pos, traj, diff, 10)

traj.x = 10
AddParticle( pos, traj, diff, 20)

traj.x = 20
AddParticle( pos, traj, diff, 30)
