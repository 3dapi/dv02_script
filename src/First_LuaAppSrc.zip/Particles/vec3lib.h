#ifndef __VEC3LIB_H__
#define __VEC3LIB_H__

LUALIB_API int lua_vec3libopen (lua_State *L);

typedef struct { double a[3]; } Vector3;

static int TAG; /* lazy! */

#endif // __VEC3LIB_H__