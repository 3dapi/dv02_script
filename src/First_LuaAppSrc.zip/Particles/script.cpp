// script.cpp: implementation of the Cscript class.
//
//////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


lua_State* CScript::m_lua = NULL;			// Give the m_lua handle an initial value


// functions exposed to lua
// Called in lua like so:
//   AddParticle( vector3 pos, vector3 traj, vector3 diff, double mass )
// l_addparticle
//       pos - position
//		 traj- trajectory
//       diff- diffuse color
//       mass- particle mass
int l_addparticle( lua_State *L )
{
	// Read in the position of the new particle
	// The particle is in the vec3 format.  We need to convert this user data
	// to a vector that the Particle System can deal with.
	Vector3* pos;
	pos = (Vector3 *) lua_touserdata(L,1);
	D3DXVECTOR3 dxpos;
	dxpos.x = pos->a[0]; dxpos.y = pos->a[1]; dxpos.z = pos->a[2];
	
	// read in the trajectory of the particle
	Vector3* traj;
	traj = (Vector3 *) lua_touserdata(L,2);
	D3DXVECTOR3 dxtraj;
	dxtraj.x = traj->a[0]; dxtraj.y = traj->a[1]; dxtraj.z = traj->a[2];
	
	// read in the diffuse color of the particle
	Vector3* diff;
	diff = (Vector3 *) lua_touserdata(L,3);
	D3DCOLOR diffuse = D3DCOLOR_XRGB( (int)diff->a[0], (int)diff->a[1], (int)diff->a[2] );
	
	// read in the mass of the particle
	double mass;
	mass = lua_tonumber( L, 4);
	
	g_pApp->AddParticle(dxpos, dxtraj, diffuse, mass);
	
	return 1;
}

// l_settexture
//       tex - texture file name
int l_settexture( lua_State *L )
{
	return 1;
}




CScript::CScript()
{
	
}

CScript::~CScript()
{
	Terminate();
}

void CScript::Initialize()
{
	// Initialize lua
	m_lua = lua_open(0);
	lua_baselibopen(m_lua);
	lua_iolibopen(m_lua);
	lua_strlibopen(m_lua);
	lua_mathlibopen(m_lua);
	lua_vec3libopen(m_lua);
	
	lua_register( m_lua, "AddParticle", l_addparticle);
}

void CScript::Terminate()
{
}


void CScript::doFile( const char* filename)
{
	lua_dofile( m_lua, filename );
}


void CScript::SetVar( const char* varname, double value)
{
	lua_pushnumber( m_lua, value);
	lua_setglobal( m_lua, varname);
}

void CScript::SetVar( const char* varname, const char* value)
{
	lua_pushstring( m_lua, value);
	lua_setglobal( m_lua, varname);
}