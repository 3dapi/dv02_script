
#ifndef __STDAFX_H_
#define __STDAFX_H_

#define	STRICT
#define	DIRECTINPUT_VERSION 0x0800

#include <list>
#include <string.h>

#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>


#include <dinput.h>

#include <d3d9.h>
#include <D3DX9.h>
#include <D3dx9math.h>
#include <D3dx9core.h>
#include <D3dx9tex.h>
#include <DXErr9.h>
#include <tchar.h>

#define		GDEVICE		g_pApp->m_pd3dDevice


#include "DXUtil.h"
#include "D3DUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "resource.h"

#include "script.h"
#include "vec3lib.h"


#include "Main.h"


#endif