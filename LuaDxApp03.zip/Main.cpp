// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain*		g_pApp  = NULL;
HINSTANCE	g_hInst = NULL;
lua_State*	g_pL;



std::vector<IDsTexture* >	m_vTx	;			// Texture
std::vector<CSound*	>		m_vSnd	;			// Sound
std::vector<ID3DXFont* >	m_vFnt	;			// Font



INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
	CMain d3dApp;
	
	g_pApp  = &d3dApp;
	g_hInst = hInst;
	
	g_pL = lua_open();
	
	// load Lua libraries
	luaL_openlibs(g_pL);
	

	lua_register(g_pL, "Mcl_CreateWindow"	,	Mcl_CreateWindow	);
	lua_register(g_pL, "Mcl_Release"		,	Mcl_Release			);
	lua_register(g_pL, "Mcl_Sleep"			,	Mcl_Sleep			);

	lua_register(g_pL, "Mcl_KeyboardAll"	,	Mcl_KeyboardAll		);
	lua_register(g_pL, "Mcl_KeyboardOne"	,	Mcl_KeyboardOne		);
	lua_register(g_pL, "Mcl_MousePos"		,	Mcl_MousePos		);
	lua_register(g_pL, "Mcl_MouseEvnt"		,	Mcl_MouseEvnt		);

	lua_register(g_pL, "Mcl_SetWindowTitle"	,	Mcl_SetWindowTitle	);
	lua_register(g_pL, "Mcl_MessageBox"		,	Mcl_MessageBox	);
	
	lua_register(g_pL, "Mcl_GetScnSize"		,	Mcl_GetScnSize		);
	lua_register(g_pL, "Mcl_GetWindowStyle"	,	Mcl_GetWindowStyle	);
	lua_register(g_pL, "Mcl_SetWindowStyle"	,	Mcl_SetWindowStyle	);
	lua_register(g_pL, "Mcl_ShowState"		,	Mcl_ShowState		);
	lua_register(g_pL, "Mcl_ChangeMode"		,	Mcl_ChangeMode		);
	lua_register(g_pL, "Mcl_SetClearColor"	,	Mcl_SetClearColor	);
	lua_register(g_pL, "Mcl_GetClearColor"	,	Mcl_GetClearColor	);

	lua_register(g_pL, "Mcl_TextureLoad"	,	Mcl_TextureLoad		);
	lua_register(g_pL, "Mcl_TextureRelease"	,	Mcl_TextureRelease	);
	lua_register(g_pL, "Mcl_TextureWidth"	,	Mcl_TextureWidth	);
	lua_register(g_pL, "Mcl_TextureHeight"	,	Mcl_TextureHeight	);
	lua_register(g_pL, "Mcl_TextureDraw"	,	Mcl_TextureDraw		);

	lua_register(g_pL, "Mcl_SoundLoad"		,	Mcl_SoundLoad		);
	lua_register(g_pL, "Mcl_SoundRelease"	,	Mcl_SoundRelease	);
	lua_register(g_pL, "Mcl_SoundPlay"		,	Mcl_SoundPlay		);
	lua_register(g_pL, "Mcl_SoundStop"		,	Mcl_SoundStop		);
	lua_register(g_pL, "Mcl_SoundReset"		,	Mcl_SoundReset		);

	lua_register(g_pL, "Mcl_FontLoad"		,	Mcl_FontLoad		);
	lua_register(g_pL, "Mcl_FontRelease"	,	Mcl_FontRelease		);
	lua_register(g_pL, "Mcl_FontDraw"		,	Mcl_FontDraw		);

	lua_register(g_pL, "Mcl_GetTime"		,	Mcl_GetTime			);
	lua_register(g_pL, "Mcl_Mod"			,	Mcl_Mod				);
	lua_register(g_pL, "Mcl_Rand"			,	Mcl_Rand			);
	lua_register(g_pL, "Mcl_SetConsole"		,	Mcl_SetConsole		);
	lua_register(g_pL, "Mcl_SendConsole"	,	Mcl_SendConsole		);
	lua_register(g_pL, "Mcl_CastInt"		,	Mcl_CastInt			);
	

	int hr = luaL_dofile(g_pL, "main.lua");
	
	
	
	InitCommonControls();
	
	if( FAILED( d3dApp.Create( hInst ) ) )
	{
		lua_close(g_pL);
		return 0;
	}
	
	d3dApp.Run();
	
	lua_close(g_pL);

	return 1;
}


CMain::CMain()
{
	m_dScnX	= 100;
	m_dScnY	= 100;

	m_dScnW	= 800;
	m_dScnH	= 600;

	memset(m_KeyCur, 0, sizeof(m_KeyCur));

	m_mouseX =0;
	m_mouseY =0;
	m_mouseZ =0;
	m_mouseEvnt=0;

	m_dWindowStyle = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_VISIBLE;

	strcpy(m_sCls, "LuaApp" );
	
	m_d3dEnum.AppUsesDepthBuffer   = TRUE;
	
	m_bStartFull				= false;
	m_bShowCursorWhenFullscreen	= true;

	m_pSprite					= NULL;
	m_pD3DXFont					= NULL;
	m_pSndMn					= NULL;
	m_pSound					= NULL;

	m_dColor = 0xFF006699;

	m_bShowState	= TRUE;

	srand( timeGetTime() );
}



HRESULT CMain::Init()
{
	HRESULT hr;

	if(FAILED(DsDev_CreateSprite(NULL, &m_pSprite, m_pd3dDevice)))
		return -1;


	D3DXFONT_DESC hFont = { 20, 0, FW_NORMAL, 1, FALSE,
		HANGUL_CHARSET, OUT_DEFAULT_PRECIS,
		ANTIALIASED_QUALITY, FF_DONTCARE, "Arial" };

	if( FAILED( hr = D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return hr;


	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, m_dColor, 1.0f, 0L );
	m_pd3dDevice->Present(0,0,0,0);

	
	m_pSndMn = new CSoundManager();
	
	if( FAILED( hr = m_pSndMn->Initialize( m_hWnd, DSSCL_PRIORITY ) ) )
		return hr;
	
	if( FAILED( hr = m_pSndMn->SetPrimaryBufferFormat( 2, 22050, 16 ) ) )
		return hr;
	
	m_pSndMn->Create( &m_pSound, "Sound/bounce.wav", 0, GUID_NULL, 1 );


	
	

	// Lua�� �ִ� Lua_Init()�Լ��� ȣ��
	lua_getglobal(g_pL, "Lua_Init");

	if (lua_pcall(g_pL, 0, 1, 0) != 0)
	{
		McUtil_ErrMsgBox(McUtil_Forming("Lua_Init Failed: %s",  lua_tostring(g_pL, -1)));
		return -1;
	}

	// get the result
	hr = (HRESULT)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return S_OK;
}



HRESULT CMain::Destroy()
{
	int hr;

	SAFE_RELEASE(	m_pD3DXFont	);

	// ��ũ��Ʈ�� �ִ� Lua_Destroy() �Լ��� ȣ��
	lua_getglobal(g_pL, "Lua_Destroy");
	
	if (lua_pcall(g_pL, 0, 1, 0) != 0)
	{
		McUtil_ErrMsgBox(McUtil_Forming("Lua_Destroy Failed: %s",  lua_tostring(g_pL, -1)));
		return -1;
	}

	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	printf("Engine Destroy\n");

	if(FAILED(hr))
		return -1;


	// ��Ʈ�� �����..
	{
		std::vector<ID3DXFont* >::iterator	_F	= m_vFnt.begin();
		std::vector<ID3DXFont* >::iterator	_L	= m_vFnt.end();

		for(; _F !=_L; ++_F)
		{
			(*_F)->Release();
		}

		m_vFnt.clear();
	}


	// �ؽ�ó�� �����
	{
		std::vector<IDsTexture* >::iterator	_F	= m_vTx.begin();
		std::vector<IDsTexture* >::iterator	_L	= m_vTx.end();

		for(; _F !=_L; ++_F)
		{
			delete (*_F);
		}

		m_vTx.clear();
	}

	// ���带 �����.
	int iSize = m_vSnd.size();

	for(int i=0; i<iSize; ++i)
	{
		SAFE_DELETE(	m_vSnd[i]	);
	}

	m_vSnd.clear();

	SAFE_DELETE( m_pSound );
	SAFE_DELETE( m_pSndMn );

	SAFE_DELETE(	m_pSprite	);
	
	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();

	int iSize = m_vFnt.size();

	for(int i=0; i<iSize; ++i)
	{
		m_vFnt[i]->OnResetDevice();
	}
	
	
	return S_OK;
}


HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	int iSize = m_vFnt.size();

	for(int i=0; i<iSize; ++i)
	{
		m_vFnt[i]->OnLostDevice();
	}
	
	return S_OK;
}


HRESULT CMain::FrameMove()
{
	int hr;
	
//	if( m_pSound )
//		m_pSound->Play();

	// Keyboard�� ���콺�� �����Ѵ�.
	POINT mouse;
	
	memset(m_KeyCur, 0, sizeof(m_KeyCur));
	::GetKeyboardState(m_KeyCur);

	for(int i=0; i<256; ++i)
		m_KeyCur[i] = (m_KeyCur[i] & 0x80) ? 1: 0;
	
	::GetCursorPos(&mouse);
	::ScreenToClient(m_hWnd, &mouse );
	
	m_mouseX = mouse.x;
	m_mouseY = mouse.y;





	// ��� �Լ��� ȣ���Ѵ�.
	lua_getglobal(g_pL, "Lua_FrameMove");

//	lua_call(g_pL, 0, 1);

	if (lua_pcall(g_pL, 0, 1, 0) != 0)
	{
		McUtil_ErrMsgBox(McUtil_Forming("Lua_FrameMove Failed: %s",  lua_tostring(g_pL, -1)));
		return -1;
	}

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);


	if(FAILED(hr))
		return -1;
	
	return S_OK;
}





HRESULT CMain::Render()
{
	int hr;

	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, m_dColor, 1.0f, 0L );
	
	if(FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	

	// ��� �Լ��� ȣ���Ѵ�.
	lua_getglobal(g_pL, "Lua_Render");
	
	if (lua_pcall(g_pL, 0, 1, 0) != 0)
	{
		McUtil_ErrMsgBox(McUtil_Forming("Lua_Render Failed: %s",  lua_tostring(g_pL, -1)));
		return -1;
	}

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(m_bShowState)
		RenderText();

	m_pd3dDevice->EndScene();
	
	return S_OK;
}




HRESULT CMain::RenderText()
{
	D3DCOLOR fontColor		= D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH]	= TEXT("");
	RECT rc;

	sprintf( szMsg, "%s %s", m_strDeviceStats , m_strFrameStats );

	rc.top		= 1;
	rc.bottom	= rc.top + 20;
	rc.left		= 2;
	rc.right	= m_d3dsdBackBuffer.Width - 20;
	
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, fontColor );
	
	return S_OK;
}






LRESULT CMain::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	WPARAM wHi = HIWORD(wParam);
	WPARAM wLo = LOWORD(wParam);

	switch(uMsg)
	{
		case WM_MOUSEWHEEL:
		{
			m_mouseZ += short( wHi);

			return 0;
		}

		case WM_LBUTTONDOWN	:
		{
			return 0;
		}
		case WM_LBUTTONUP:
		{
			return 0;
		}
		case WM_LBUTTONDBLCLK:
		{
			return 0;
		}

		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				TCHAR strMsg[MAX_PATH];
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				RECT rc;
				GetClientRect( hWnd, &rc );
				DrawText( hDC, strMsg, -1, &rc, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, uMsg, wParam, lParam );
}


void CMain::SetWindowTitle(char* sMsg)
{
	SetWindowText(m_hWnd, sMsg);
}



int CMain::LuaCreateWindow()
{
	int hr;

	lua_getglobal(g_pL, "Lua_Create");
	
	if (lua_pcall(g_pL, 0, 1, 0) != 0)
	{
		McUtil_ErrMsgBox(McUtil_Forming("Lua_Create Failed: %s",  lua_tostring(g_pL, -1)));
		return -1;
	}

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 1;
}



static int Mcl_CreateWindow(lua_State *pLua)
{
	int hr=-1;

	// ��ũ��Ʈ�� �����͸� �޾Ƽ�..
	int n = lua_gettop(pLua);

	if(n<4)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	g_pApp->m_dScnX = (int)lua_tonumber(pLua, 1);
	g_pApp->m_dScnY = (int)lua_tonumber(pLua, 2);
	g_pApp->m_dScnW = (int)lua_tonumber(pLua, 3);
	g_pApp->m_dScnH = (int)lua_tonumber(pLua, 4);

	strcpy(g_pApp->m_sCls, lua_tostring(pLua, 5));

	g_pApp->m_bStartFull = (int)lua_tonumber(pLua, 6)? true : false;

	return 0;
}


static int Mcl_Release(lua_State *pLua)
{
//	printf("Lua Release\n");
	
	return 0;
}


static int Mcl_Sleep(lua_State *pLua)
{
	int n = lua_gettop(pLua);

	if(n<1)
		Sleep(1000);

	int nMilliSecond = (int)lua_tonumber(pLua, 1);
	
	Sleep(nMilliSecond);

	return 0;
}



static int Mcl_KeyboardAll(lua_State *pLua)
{
	for(int i=0; i<256; ++i)
		lua_pushnumber(pLua, g_pApp->m_KeyCur[i]);
	
	return 256;
}


static int Mcl_KeyboardOne(lua_State *pLua)
{
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		g_pApp->m_bShowState = FALSE;
		return 0;
	}

	int _nKey = (int)lua_tonumber(pLua, 1);

	lua_pushnumber(pLua, g_pApp->m_KeyCur[_nKey]);
	return 1;
}




static int Mcl_MousePos(lua_State *pLua)
{
	lua_pushnumber(pLua, g_pApp->m_mouseX);
	lua_pushnumber(pLua, g_pApp->m_mouseY);
	lua_pushnumber(pLua, g_pApp->m_mouseZ);

	return 3;
}


static int Mcl_MouseEvnt(lua_State *pLua)
{
	lua_pushnumber(pLua, g_pApp->m_KeyCur[VK_LBUTTON]);
	lua_pushnumber(pLua, g_pApp->m_KeyCur[VK_RBUTTON]);
	lua_pushnumber(pLua, g_pApp->m_KeyCur[VK_MBUTTON]);

	return 3;
}


static int Mcl_GetScnSize(lua_State *pLua)
{
	lua_pushnumber(pLua, g_pApp->m_dScnW);
	lua_pushnumber(pLua, g_pApp->m_dScnH);
	
	return 1;
}



static int Mcl_SetWindowTitle(lua_State *pLua)
{
	char sMsg[1024];

	int n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	memset(sMsg, 0, sizeof(sMsg));

	for(int i=1; i<=n; ++i)
	{
		char sRcv[512];
		memset(sRcv, 0, sizeof(sRcv));

		if (!lua_isnumber(pLua, i)) 
		{
			sprintf(sRcv, " %s", lua_tostring(pLua, i));
			strcat(sMsg, sRcv);
		}
		
		else
		{
			double fRcvNumber = lua_tonumber(pLua, i);
			sprintf(sRcv, " %6.3f", fRcvNumber);
			strcat(sMsg, sRcv);
		}
	}

	g_pApp->SetWindowTitle(sMsg);
	
	return 0;
}


static int Mcl_MessageBox(lua_State *pLua)
{
	char sMsg[1024];
	char sTitle[1024];

	int n = lua_gettop(pLua);

	if(n<1)
	{
		MessageBox(g_pApp->m_hWnd, NULL, NULL, 0);
		return 0;
	}

	if(n<2)
	{
		memset(sMsg, 0, sizeof(sMsg));
		sprintf(sMsg, "%s", lua_tostring(pLua, 1));
		MessageBox(g_pApp->m_hWnd, sMsg, NULL, 0);

		return 0;
	}

	if(n<3)
	{
		memset(sMsg, 0, sizeof(sMsg));
		memset(sTitle, 0, sizeof(sTitle));

		sprintf(sMsg, "%s", lua_tostring(pLua, 1));
		sprintf(sTitle, "%s", lua_tostring(pLua, 2));

		MessageBox(g_pApp->m_hWnd, sMsg, sTitle, 0);

		return 0;
	}

	if(n<4)
	{
		memset(sMsg, 0, sizeof(sMsg));
		memset(sTitle, 0, sizeof(sTitle));

		sprintf(sMsg, "%s", lua_tostring(pLua, 1));
		sprintf(sTitle, "%s", lua_tostring(pLua, 2));
		int uType = (int)lua_tonumber(pLua, 3);

		MessageBox(g_pApp->m_hWnd, sMsg, sTitle, uType);

		return 0;
	}
	
	return 0;
}


static int Mcl_SetWindowStyle(lua_State *pLua)
{
	return 0;
}

static int Mcl_GetWindowStyle(lua_State *pLua)
{
	lua_pushnumber(pLua, g_pApp->m_dWindowStyle);

	return 1;
}


static int	Mcl_ShowState(lua_State *pLua)
{
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		g_pApp->m_bShowState = FALSE;
		return 0;
	}

	g_pApp->m_bShowState = (INT)lua_tonumber(pLua, 1);
	return 0;
}


static int	Mcl_ChangeMode(lua_State *pLua)
{
	g_pApp->ToggleFullscreen();
	return 0;
}


static int	Mcl_SetClearColor(lua_State *pLua)
{
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		g_pApp->m_bShowState = FALSE;
		return 0;
	}

	g_pApp->m_dColor = (DWORD)lua_tonumber(pLua, 1);
	return 0;
}

static int	Mcl_GetClearColor(lua_State *pLua)
{
	lua_pushnumber(pLua, g_pApp->m_dColor);
	return 1;
}



// Texture
static int	Mcl_TextureLoad(lua_State *pLua)
{
	int		n = lua_gettop(pLua);
	char	sFile[512];
	DWORD	dc=0x00FFFFFFFF;

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	else if(n < 2)
	{
		memset(sFile, 0, sizeof(sFile));
		strcpy(sFile, lua_tostring(pLua, 1));
	}

	else if(n < 3)
	{
		memset(sFile, 0, sizeof(sFile));
		strcpy(sFile, lua_tostring(pLua, 1));
		dc = (DWORD)lua_tonumber(pLua, 2);
	}

	else
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	

	IDsTexture*	pTexture	= NULL;
	int nKey = m_vTx.size();

	
	DWORD	dMip	=	1;
	DWORD	dFilter	=	D3DX_FILTER_NONE;
	DWORD	dColorKey=	0x0;

	if(FAILED(DsDev_CreateTexture("FILE", &pTexture, g_pApp->m_pd3dDevice, sFile, &dMip, &dFilter, &dColorKey) ))
	{
		printf("Create Texture Failed: %s\n", sFile);
		pTexture = NULL;

		lua_pushnumber(pLua, -1);
		return 1;
	}

	m_vTx.push_back(pTexture);

	// Key�� ���� �ش�.
	lua_pushnumber(pLua, nKey);
	return 1;
}




static int Mcl_TextureRelease(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = m_vTx.size();
	
	if(_nKey>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	std::vector<IDsTexture* >::iterator	it;

	it = m_vTx.begin() + _nKey;
	m_vTx.erase(it);

	iSize = m_vTx.size();

	// ���� �ִ� ����� �����ش�.
	lua_pushnumber(pLua, iSize);
	return 1;
}


static int Mcl_TextureWidth(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = m_vTx.size();

	if(_nKey>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	lua_pushnumber(pLua, (int)m_vTx[_nKey]->GetImageWidth() );
	return 1;
}


static int Mcl_TextureHeight(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = m_vTx.size();

	if(_nKey>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	lua_pushnumber(pLua, (int)m_vTx[_nKey]->GetImageHeight() );
	return 1;
}



static int Mcl_TextureDraw(lua_State *pLua)
{
	DWORD		_nKey;
	RECT		pRc;
	D3DXVECTOR2	pPos;
	DWORD		dC=D3DXCOLOR(1,1,1,1);

	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	pRc.left	= (LONG)lua_tonumber(pLua, 2);
	pRc.top		= (LONG)lua_tonumber(pLua, 3);
	pRc.right	= (LONG)lua_tonumber(pLua, 4);
	pRc.bottom	= (LONG)lua_tonumber(pLua, 5);

	pPos.x		= (FLOAT)lua_tonumber(pLua, 6);
	pPos.y		= (FLOAT)lua_tonumber(pLua, 7);


	int iSize = m_vTx.size();
	
	if(_nKey>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	IDsTexture*	pTx = m_vTx[_nKey];

	g_pApp->m_pSprite->Draw(pTx, &pRc, NULL, &pPos, dC);
	return 0;
}



// sound
static int	Mcl_SoundLoad(lua_State *pLua)
{
	int		n = lua_gettop(pLua);
	char	sFile[512];

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}
	else if(n < 2)
	{
		memset(sFile, 0, sizeof(sFile));
		strcpy(sFile, lua_tostring(pLua, 1));
	}
	else
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}


	CSound* pSnd = NULL;
	int	nKey = m_vSnd.size();

	g_pApp->m_pSndMn->Create( &pSnd, sFile, 0, GUID_NULL, 1 );

	if(NULL == pSnd)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	m_vSnd.push_back(pSnd);

	// Key�� ���� �ش�.
	lua_pushnumber(pLua, nKey);
	return 1;
}



static int Mcl_SoundRelease(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = m_vSnd.size();

	if(_nKey>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	std::vector<CSound* >::iterator	it;

	it = m_vSnd.begin() + _nKey;
	SAFE_DELETE(	m_vSnd[_nKey]	);
	m_vSnd.erase(it);

	iSize = m_vSnd.size();

	// ���� �ִ� ����� �����ش�.
	lua_pushnumber(pLua, iSize);
	
	return 1;
}



static int Mcl_SoundPlay(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = m_vSnd.size();

	if(_nKey>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	int hr = m_vSnd[_nKey]->Play();
	lua_pushnumber(pLua, hr);
	return 1;
}



static int Mcl_SoundStop(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = m_vSnd.size();

	if(_nKey>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	lua_pushnumber(pLua, m_vSnd[_nKey]->Stop());
	return 1;
}




static int Mcl_SoundReset(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = m_vSnd.size();

	if(_nKey>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	lua_pushnumber(pLua, m_vSnd[_nKey]->Reset());
	return 1;
}


// Font
// Name, Height, Font Weight , Italic
static int	Mcl_FontLoad(lua_State *pLua)
{
	int		n = lua_gettop(pLua);
	char	sName[64];
	LONG	lH =10;
	LONG	lW =FW_NORMAL;
	BYTE	iL =0;


	if(n<3)
	{
		lua_pushnumber(pLua, -1);
//		MessageBox(0, 0, 0, 0);
		McUtil_ErrMsgBox("Font Load Error");
		return 1;
	}

	memset(sName, 0, sizeof(sName));
	strcpy(sName, lua_tostring(pLua, 1));
	lH = (DWORD)lua_tonumber(pLua, 2);
	lW = (BYTE)lua_tonumber(pLua, 3);
	iL = (BYTE)lua_tonumber(pLua, 4);
	

	if(0 == lW)
		lW = FW_THIN;
	else if(1 == lW)
		lW = FW_NORMAL;
	else 
		lW = FW_BOLD;

	D3DXFONT_DESC hFont = { lH, 0, lW, 1, iL,
		HANGUL_CHARSET, OUT_DEFAULT_PRECIS,
		ANTIALIASED_QUALITY, FF_DONTCARE };

	strcpy(hFont.FaceName, sName);

	ID3DXFont*	pFnt = NULL;
	int	nKey = m_vFnt.size();

	if( FAILED( D3DXCreateFontIndirect( g_pApp->m_pd3dDevice, &hFont, &pFnt ) ) )
	{
		printf("Create Font Failed: %s\n", sName);
		lua_pushnumber(pLua, -1);
		return 1;
	}

	m_vFnt.push_back(pFnt);

	// Key�� ���� �ش�.
	lua_pushnumber(pLua, nKey);
	return 1;
}




static int Mcl_FontRelease(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = m_vFnt.size();

	if(_nKey>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}


	std::vector<ID3DXFont* >::iterator	it;

	it = m_vFnt.begin() + _nKey;
	SAFE_DELETE(	m_vFnt[_nKey]	);
	m_vFnt.erase(it);

	iSize = m_vFnt.size();

	// ���� �ִ� ����� �����ش�.
	lua_pushnumber(pLua, iSize);
	
	return 1;
}



static int Mcl_FontDraw(lua_State *pLua)
{
	char	sMsg[1024]={0};
	DWORD	_nKey;
	RECT	pRc;
	
	DWORD	fontColor=D3DXCOLOR(1,1,1,1);
	char	sColor[32];

	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey =		 (DWORD)lua_tonumber(pLua, 1);
	strcpy(sMsg, (char*)lua_tostring(pLua, 2));
	pRc.left	= (LONG)lua_tonumber(pLua, 3);
	pRc.top		= (LONG)lua_tonumber(pLua, 4);
	
	strcpy(sColor, lua_tostring(pLua, 5));
	sscanf(sColor,"%x", &fontColor);

	int iSize = m_vFnt.size();

	if(_nKey>=iSize)
	{
//		MessageBox(0,0,0,0);
		McUtil_ErrMsgBox("Font Draw Error");
		lua_pushnumber(pLua, -1);
		return 1;
	}

	ID3DXFont*		pFont = m_vFnt[_nKey];
	D3DXFONT_DESC	hFont;
	pFont->GetDesc(&hFont);

	pRc.right	= pRc.left + (strlen(sMsg) +1) * hFont.Height;
	pRc.bottom	= pRc.top + hFont.Height + 2;

	pFont->DrawText(NULL, sMsg, -1, &pRc, 0, fontColor );

	return 0;
}



static int	Mcl_GetTime(lua_State *pLua)
{
	lua_pushnumber(pLua, g_pApp->m_fTimeCur);
	return 1;
}


static int	Mcl_Mod(lua_State *pLua)
{
	DWORD v1= (DWORD)lua_tonumber(pLua, 1);
	DWORD v2= (DWORD)lua_tonumber(pLua, 2);

	DWORD v3 = v1 %v2;
	
	lua_pushnumber(pLua, v3);

	return 1;
}



static int Mcl_Rand(lua_State *pLua)
{
	DWORD v1= (DWORD)lua_tonumber(pLua, 1);
	DWORD v3 = rand() %v1;
	
	lua_pushnumber(pLua, v3);

	return 1;
}


static int Mcl_SetConsole(lua_State *pLua)
{
	INT v1= (INT)lua_tonumber(pLua, 1);
	McUtil_SetConsole(v1);

	return 0;
}



static int Mcl_SendConsole(lua_State *pLua)
{
	char* v1= (char*)lua_tostring(pLua, 1);
	McUtil_SendConsole(v1);

	return 0;
}


static int	Mcl_CastInt(lua_State *pLua)
{
	INT v1= (INT)lua_tonumber(pLua, 1);

	lua_pushnumber(pLua, v1);

	return 1;
}