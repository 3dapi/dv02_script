-- File: Game.lua
-- Owner: Heesung Oh, Copy Left
-- Date: 2005-03-08
-- Update:

-- Description: Game logic file

-- g_TxId: Texture Id Array
-- g_TxW: Texture width array
-- g_TxH: Texture height array

-- g_Snd: Sound Array
-- g_nFnt: Font Array

-- g_TxTime: Time for texture animation
-- g_TxIdx: Index for texture animation






g_TxId	={}
g_TxW	={}
g_TxH	={}

g_Snd = {}

g_nFnt ={}

g_TxTime ={}
g_TxIdx ={}



function GameInit()
	g_TxId[1]	= Mcl_TextureLoad(		"Texture/mario.png")
	g_TxW[1]	= Mcl_TextureWidth(		)
	g_TxH[1]	= Mcl_TextureHeight(	g_TxId[1]	)

	g_TxId[2]	= Mcl_TextureLoad(		"Texture/animate.png")
	g_TxW[2]	= Mcl_TextureWidth(		g_TxId[2]	)
	g_TxH[2]	= Mcl_TextureHeight(	g_TxId[2]	)

	g_Snd		= Mcl_SoundLoad("Sound/bounce.wav")

	g_nFnt[1]	= Mcl_FontLoad("Arial", 15, 0,  0)
	g_nFnt[2]	= Mcl_FontLoad("����ü", 20,1, 0)
	g_nFnt[3]	= Mcl_FontLoad("�ü�ü", 25,2, 1)

	Mcl_ShowState(0)

	-- Animation�� ���� �޸𸮸� �Ҵ��ϰ� �ε����� Ÿ���� �����Ѵ�.
	for i=1, 1000, 1 do 
		g_TxTime[i] =0
		g_TxIdx[i] =0
	end

	-- keybord �ʱ�ȭ
	for i=1, 256, 1 do 
		g_Keyboard[i] =0
	end

	return 1
end



function GameUpdate()
	-- Key 'A' Test
	if 1 == g_Keyboard[65] then
		Mcl_MessageBox("Hello World", "Send from Script", 48)
	end

	-- Key 'B' Test
	if 1 == g_Keyboard[66] then
		Mcl_SoundPlay(g_Snd)
	end

	if 1 == g_Mouse[5] then
		Mcl_ShowState(1)
	else
		Mcl_ShowState(0)
	end


	-- Get Current Time
	fCurTime = Mcl_GetTime()

	
	-- Setting Animation Index for Mario

	if	fCurTime > (g_TxTime[1]+0.2) then
		g_TxIdx[1]	= g_TxIdx[1] + 1
		g_TxTime[1] = fCurTime

		if g_TxIdx[1]>=18 then
			g_TxIdx[1] = 0
		end
	end


	-- Setting Animation Index for Animation BMP file

	if	fCurTime > (g_TxTime[2]+0.033) then
		g_TxIdx[2]	= g_TxIdx[2] + 1
		g_TxTime[2] = fCurTime

		if g_TxIdx[2]>=30 then
			g_TxIdx[2] = 0
		end
	end

	-- ���� ���� ����¹�
	-- 1: Using operator ..
	sMsg = "Mouse: " .. g_Mouse[1] .. " " .. g_Mouse[2]

	-- 2: string Object
	sMsg = string.format("Mouse: %d %d", g_Mouse[1], g_Mouse[2])





	-- Set Window Title
	Mcl_SetWindowTitle( "Current Time is", fCurTime)

	-- Send Message to console window
	local sMessage = string.format("Current Time: %f \n", fCurTime)
	Mcl_SendConsole(sMessage)


	-- Casting Int
	local sCast = string.format("Current Time: %f \n", Mcl_CastInt(fCurTime))
	Mcl_SendConsole(sCast)


	
	
	return 1
end



function GameRender()

	-- Draw Super Mario
	-- Texture index, image region left, top, right, bottom
	-- screen position x, screen position y
	Mcl_TextureDraw(
			g_TxId[1]
		,	g_TxIdx[1] * g_TxW[1]/18
		,	0
		,	(g_TxIdx[1]+1) * g_TxW[1]/18
		,	g_TxH[1]
		,	300
		,	400)

	
	-- Draw Animation BMP
	Mcl_TextureDraw(
			g_TxId[2]
		,	g_TxIdx[2] * g_TxW[2]/30
		,	0
		,	(g_TxIdx[2]+1) * g_TxW[2]/30
		,	g_TxH[2]
		,	g_Mouse[1]
		,	g_Mouse[2])


	
	
	-- Font Draw
	-- Font Index, Message, screen x, screen y, color
	Mcl_FontDraw(g_nFnt[1], sMsg, 100, 200, "0xFF00FFFF")
	Mcl_FontDraw(g_nFnt[2], "�̺�Ʈ ������� A Key�Դϴ�.", 100, 230, "0xFFFF00FF")
	Mcl_FontDraw(g_nFnt[3], "����� B Ű�Դϴ�.", 100, 260, "0xFFFFFFFF")

	return 1
end


function GameDestroy()

end