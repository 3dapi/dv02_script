// Interface for the Utility Functions.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MCUTIL_H_
#define _MCUTIL_H_


void	McUtil_ErrMsgBox(TCHAR *format,...);
char*	McUtil_Forming(const char *fmt, ...);
void	McUtil_SetConsole(BOOL bCon);
void	McUtil_AllocConsole();
void	McUtil_SendConsole(TCHAR *s);


#endif