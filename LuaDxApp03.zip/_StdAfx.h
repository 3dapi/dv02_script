// 
//
////////////////////////////////////////////////////////////////////////////////


#pragma once


#ifndef __StdAfx_H_
#define __StdAfx_H_


#pragma warning( disable : 4018)
#pragma warning( disable : 4100)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)
#pragma warning( disable : 4996)


#define STRICT
#define _WIN32_WINNT			0x0400
#define _WIN32_WINDOWS			0x0400
#define DIRECTINPUT_VERSION		0x0800
#define DIRECTSOUND_VERSION		0x0800


#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "DxErr.lib")
#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "dsound.lib")

#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)
	#pragma comment(lib, "lib/DsSprite.lib")
#else
	#pragma comment(lib, "Lua_.lib"	)
	#pragma comment(lib, "lib/DsSprite_.lib")
#endif


#include <vector>

#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tchar.h>

#include <d3d9.h>
#include <d3dx9.h>
#include <DxErr.h>
#include <dsound.h>

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>

#include "include/IDsTexture.h"
#include "include/IDsSprite.h"

#include "DXUtil.h"
#include "D3DUtil.h"
#include "dsutil.h"

#include "D3DEnum.h"
#include "D3DSettings.h"
#include "D3DApp.h"

#include "resource.h"

#include "_McType.h"
#include "McUtil.h"


#include "Main.h"

#endif


