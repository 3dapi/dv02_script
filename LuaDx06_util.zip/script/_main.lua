-------------------------------------------------------------------------------
-- Reseverd Function
-- LuaApi_Create()		: ���α׷� ����
-- LuaApi_Init()		: ���� ������ �ʱ�ȭ
-- LuaApi_Destroy()		: ���� ������ ����
-- LuaApi_FrameMove()	: ���� ������ ����
-- LuaApi_Render()		: ���� ������ ������
-------------------------------------------------------------------------------
-- Mouse Position
g_MouseX = 0
g_MouseY = 0
g_MouseZ = 0

-- Mouse Event 1: Down, 2: Up, 3: Press
g_MouseL = 0
g_MouseR = 0
g_MouseM = 0


function LuaApi_Create()
	hr = Lua_WindowCreate(100, 10, 1024, 768, "mackerel", 0)
	return hr
end


g_TxI	={}	-- Texture Id
g_TxW	={}	-- Texture Width
g_TxH	={}	-- Texture Height

g_Snd	={}	-- Sound
g_Fnt	={}	-- Font

g_AniIdx ={} -- Animation �ε���
g_AniTic ={} -- Animation Ÿ��


function LuaApi_Init()
	g_TxI[1]	= Lua_TextureCreate(	"Texture/mario.png")
	g_TxW[1]	= Lua_TextureWidth(		g_TxI[1]	)
	g_TxH[1]	= Lua_TextureHeight(	g_TxI[1]	)

	g_TxI[2]	= Lua_TextureCreate(	"Texture/animate.png")
	g_TxW[2]	= Lua_TextureWidth(		g_TxI[2]	)
	g_TxH[2]	= Lua_TextureHeight(	g_TxI[2]	)


	-- ���� ����
	g_Snd[1]	= Lua_SoundCreate("Sound/bounce.wav")

	-- ��Ʈ ����
	g_Fnt[1]	= Lua_FontCreate(30, 4, "HY����L")
	g_Fnt[2]	= Lua_FontCreate(14, 9, "�ü�")



	-- Animation�� ���� �޸𸮸� �Ҵ�� �ʱ�ȭ
	for i=1, 100, 1 do 
		g_AniIdx[i] =0
		g_AniTic[i] =0
	end

	return 0
end


function LuaApi_Destroy()
	-- �ؽ�ó �Ҹ�
	Lua_TextureDestroy(g_TxI[1])
	Lua_TextureDestroy(g_TxI[2])

	-- ���� �Ҹ�
	Lua_SoundDestroy(g_Snd[1])

	-- ��Ʈ �Ҹ�
	Lua_FontDestroy(g_Fnt[1])
	Lua_FontDestroy(g_Fnt[2])

	return 0
end


function LuaApi_FrameMove()
	-- ���콺 ó��
	g_MouseX, g_MouseY, g_MouseZ = Lua_MousePos()
	g_MouseL, g_MouseR, g_MouseM = Lua_MouseEvnt()

	-- sound play
	if 1 == g_MouseR then
		Lua_SoundPlay(g_Snd[1])
	end


	-- Get Current Time(1/1000 second)
	local Time = Lua_GetTime()

	
	-- Setting Animation Index for Mario
	if	Time > (g_AniTic[1]+200) then
		g_AniIdx[1]	= g_AniIdx[1] + 1
		g_AniTic[1] = Time

		if g_AniIdx[1]>=18 then
			g_AniIdx[1] = 0
		end
	end


	-- Setting Animation Index for Animation BMP file

	if	Time > (g_AniTic[2]+33.33) then
		g_AniIdx[2]	= g_AniIdx[2] + 1
		g_AniTic[2] = Time

		if g_AniIdx[2]>=30 then
			g_AniIdx[2] = 0
		end
	end

	return 0

end


function LuaApi_Render()
	-- Draw Super Mario
	Lua_TextureDraw(
			g_TxI[1]
		,	(g_AniIdx[1]+0) * g_TxW[1]/18, 0
		,	(g_AniIdx[1]+1) * g_TxW[1]/18,	g_TxH[1]
		,	400
		,	300)

	
	-- Draw Animation BMP
	Lua_TextureDraw(
			g_TxI[2]
		,	(g_AniIdx[2]+0) * g_TxW[2]/30,	0
		,	(g_AniIdx[2]+1) * g_TxW[2]/30,	g_TxH[2]
		,	g_MouseX
		,	g_MouseY)


	-- ���� ����
	local msg = "���콺: " .. g_MouseX .. " " .. g_MouseY .. " " .. g_MouseZ
	-- ���ڿ� ���
	Lua_FontDraw(g_Fnt[2], 40, 30, msg, "0xFFFF00FF")

	return 0
end


