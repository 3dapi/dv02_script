

#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>


lua_State* g_pL;



int		g_dScnX;
int		g_dScnY;
int		g_dScnW;
int		g_dScnH;

char	g_sCls[256];
int		g_bFull;


// Basic LuaApi Call Function
int LuaApi_Create();
int LuaApi_Init();
int LuaApi_Destroy();
int LuaApi_FrameMove();
int	LuaApi_Render();


// Lua Glue Function
static int Lua_Create(lua_State *g_pL);
static int Lua_Release(lua_State *g_pL);
static int Lua_Sleep(lua_State *g_pL);


int main()
{
	printf("Super Simple Game Loop with Lua\n");
	
	g_pL = lua_open();
	
	// load Lua libraries
	luaL_openlibs(g_pL);

	// register lua glue function
	lua_register(g_pL, "Lua_Sleep", Lua_Sleep);
	lua_register(g_pL, "Lua_Create", Lua_Create);
	lua_register(g_pL, "Lua_Release", Lua_Create);

	// do script file
	luaL_dofile(g_pL, "script/Script.lua");

	// call lua api for Create
	if(FAILED(LuaApi_Create()))
	{
		printf("Game Init Failed\n");
		return -1;
	}

	// call lua api for Init
	LuaApi_Init();

	
	printf("Engine Run\n");

	while(1)
	{
		// call lua api for FrameMove
		if(FAILED(LuaApi_FrameMove()))
			break;

		// call lua api for Render
		if(FAILED(LuaApi_Render()))
			break;
	}

	LuaApi_Destroy();
	
	lua_close(g_pL);

	return 1;
}




int LuaApi_Create()
{
	int hr;

	printf("Engine Begin\n");

	// Scirpt�� �ִ� �Լ� ȣ��
	lua_getglobal(g_pL, "LuaApi_Create");
	lua_call(g_pL, 0, 1);

	// get the result
	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 1;
}

int LuaApi_Init()
{
	int hr;

	printf("Engine Start\n");

	lua_getglobal(g_pL, "LuaApi_Init");
	lua_call(g_pL, 0, 1);

	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 1;
}



int LuaApi_Destroy()
{
	int hr;

	lua_getglobal(g_pL, "LuaApi_Destroy");
	lua_call(g_pL, 0, 1);

	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	printf("Engine Destroy\n");

	if(FAILED(hr))
		return -1;

	return 1;
}



int LuaApi_FrameMove()
{
	int hr;

	lua_getglobal(g_pL, "LuaApi_FrameMove");
	lua_call(g_pL, 0, 1);

	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 1;
}


int LuaApi_Render()
{
	int hr;

	lua_getglobal(g_pL, "LuaApi_Render");
	lua_call(g_pL, 0, 1);

	hr = (int)lua_tonumber(g_pL, -1);
	lua_pop(g_pL, 1);

	if(FAILED(hr))
		return -1;

	return 1;
}




// Lua Glue Function

static int Lua_Create(lua_State *g_pL)
{
	int n = lua_gettop(g_pL);

	if(n<4)
		return 0;

	g_dScnX = (int)lua_tonumber(g_pL, 1);
	g_dScnY = (int)lua_tonumber(g_pL, 2);
	g_dScnW = (int)lua_tonumber(g_pL, 3);
	g_dScnH = (int)lua_tonumber(g_pL, 4);

	g_sCls[256];
	memset(g_sCls, 0, sizeof(g_sCls));
	strcpy(g_sCls, lua_tostring(g_pL, 5));

//	strcpy(g_sCls ,luaL_optstring(g_pL, 5, NULL));

	g_bFull = (int)lua_tonumber(g_pL, 6);

	printf("Screen: %d %d %d %d %s %d\n", g_dScnX, g_dScnY, g_dScnW, g_dScnH, g_sCls, g_bFull);


	lua_pushnumber(g_pL, 1);
	// lua_pushnumber �� ��ŭ ����
	return 1;
}


static int Lua_Release(lua_State *g_pL)
{
	printf("Lua Release\n");
	
	return 0;
}


static int Lua_Sleep(lua_State *g_pL)
{
	int n = lua_gettop(g_pL);

	if(n<1)
		Sleep(1000);

	int nMilliSecond = (int)lua_tonumber(g_pL, 1);

//	nMilliSecond = luaL_optint(g_pL, 1, NULL);
	
	Sleep(nMilliSecond);

	return 0;
}

