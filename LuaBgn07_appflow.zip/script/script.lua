-- Simple LUA Program

function LuaApi_Create()
	print("Script LuaApi_Create")

	succeed = Lua_Create(100, 100, 800, 600, "mackerel", 0)

	print("Succeed", succeed)
	return succeed
end

function LuaApi_Init()
	print("Script LuaApi_Init")
	return 0
end

function LuaApi_Destroy()
	print("Script LuaApi_Destroy")

	return 0
end

c = 0

function LuaApi_FrameMove()
	Lua_Sleep(500)

	c = c+10

	if c>100 then
		return -1
	end

	print("Script LuaApi_FrameMove:", c)

	return 0
end

d = 0

function LuaApi_Render()
	Lua_Sleep(500)

	d = d+30

	if c>100 then
		return -1
	end

	print("Script LuaApi_Render:", d)

	return 0
end
