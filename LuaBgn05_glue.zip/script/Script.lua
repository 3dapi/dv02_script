Rcv1 = Lua_SendNumber()
Rcv2 = Lua_SendString()

Rcv3, Rcv4, Rcv5, Rcv6 = Lua_SendComplex()

print( "Receive:", Rcv1)
print( "Receive:", Rcv2)
print( "Receive:", Rcv3)
print( "Receive:", Rcv4)
print( "Receive:", Rcv5)
print( "Receive:", Rcv6)