

#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>


lua_State* g_pL;



static int Lua_SendNumber(lua_State *g_pL)
{
	int number =12345678;

	// Number�� ���ÿ� �ִ´�.
	lua_pushnumber(g_pL, number);

	//	1���� Argument�� �����Ѵ�.
	return 1;
}


static int Lua_SendString(lua_State *g_pL)
{
	char	sMsg[128];
	strcpy(sMsg, "Send String");

	// ���ڿ��� ���ÿ� �ִ´�.
	lua_pushstring(g_pL, sMsg);

	//	1���� Argument�� �����Ѵ�.
	return 1;
}



static int Lua_SendComplex(lua_State *g_pL)
{
	int number1 =1111;
	lua_pushnumber(g_pL, number1);

	number1 =2222;
	lua_pushnumber(g_pL, number1);

	char	sMsg[128];
	strcpy(sMsg, "Send String One");
	lua_pushstring(g_pL, sMsg);

	sMsg[128];
	strcpy(sMsg, "Send String Two");
	lua_pushstring(g_pL, sMsg);

//	4���� Argument�� �����Ѵ�.
	return 4;
}



void main()
{
	printf("Calling User Define Function in Script\n");

	g_pL = lua_open();

	// load Lua libraries
	luaL_openlibs(g_pL);

	lua_register(g_pL, "Lua_SendNumber", Lua_SendNumber);
	lua_register(g_pL, "Lua_SendString", Lua_SendString);
	lua_register(g_pL, "Lua_SendComplex", Lua_SendComplex);


	luaL_dofile(g_pL, "script/Script.lua");

	lua_close(g_pL);
}


