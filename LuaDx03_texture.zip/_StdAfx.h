//
//
////////////////////////////////////////////////////////////////////////////////


#pragma once


#ifndef __StdAfx_H_
#define __StdAfx_H_


#pragma warning( disable : 4018)
#pragma warning( disable : 4100)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)
#pragma warning( disable : 4996)


#define STRICT
#define _WIN32_WINNT			0x0400
#define _WIN32_WINDOWS			0x0400
#define DIRECTINPUT_VERSION		0x0800


#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "DxErr.lib")

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "dsound.lib")
#pragma comment(lib, "dxguid.lib")

#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif


#include <vector>

#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tchar.h>

#include <d3dx9.h>
#include <DxErr.h>

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>

#ifndef _DEBUG
	#pragma comment(lib, "lib/DsSprite.lib")
#else
	#pragma comment(lib, "lib/DsSprite_.lib")
#endif


#include "include/IDsSprite.h"
#include "include/IDsTexture.h"

#include "DXUtil.h"
#include "D3DEnum.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DUtil.h"

#include "resource.h"

#include "McInput.h"
#include "LuaGlue.h"




#include "Main.h"

#endif


