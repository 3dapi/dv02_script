-------------------------------------------------------------------------------
-- Reseverd Function
-- LuaApi_Create()		: ���α׷� ����
-- LuaApi_Init()		: ���� ������ �ʱ�ȭ
-- LuaApi_Destroy()		: ���� ������ ����
-- LuaApi_FrameMove()	: ���� ������ ����
-- LuaApi_Render()		: ���� ������ ������
-------------------------------------------------------------------------------
-- Mouse Position
g_MouseX = 0
g_MouseY = 0
g_MouseZ = 0

-- Mouse Event 1: Down, 2: Up, 3: Press
g_MouseL = 0
g_MouseR = 0
g_MouseM = 0


function LuaApi_Create()
	hr = Lua_WindowCreate(100, 10, 1024, 768, "mackerel", 0)
	return hr
end


g_TxI	={}	-- Texture Id
g_TxW	={}	-- Texture Width
g_TxH	={}	-- Texture Height

function LuaApi_Init()
	Lua_WindowTitle("Texture Draw")
	g_TxI[1]	= Lua_TextureCreate("Texture/lena.png")
	g_TxW[1]	= Lua_TextureWidth (g_TxI[1])
	g_TxH[1]	= Lua_TextureHeight(g_TxI[1])

	g_TxI[2]	= Lua_TextureCreate("Texture/mario.png")
	g_TxW[2]	= Lua_TextureWidth (g_TxI[2])
	g_TxH[2]	= Lua_TextureHeight(g_TxI[2])

	return 0
end


function LuaApi_Destroy()
	Lua_TextureDestroy(g_TxI[1])
	Lua_TextureDestroy(g_TxI[2])

	return 0
end


function LuaApi_FrameMove()
	-- ���콺 ó��
	g_MouseX, g_MouseY, g_MouseZ = Lua_MousePos()
	g_MouseL, g_MouseR, g_MouseM = Lua_MouseEvnt()

	local msg = string.format("%d %d %d", g_MouseX, g_MouseY, g_MouseZ)
	Lua_WindowTitle(msg)

end


function LuaApi_Render()
	-- �׸� �׸���
	Lua_TextureDraw(g_TxI[1], 0,0, g_TxW[1], g_TxH[1], 20, 10)
	Lua_TextureDraw(g_TxI[2]
						, 250, 0, 300, 66, g_MouseX, g_MouseY)
	return 0
end


