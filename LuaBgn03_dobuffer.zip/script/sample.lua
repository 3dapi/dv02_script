-- Simple LUA Program

print "Start"

for i=1,10 do
   print(i) 
end

print "End"


function AppFunction(n)
  return n * 3
end

return AppFunction(123)