// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _CMain_H_
#define _CMain_H_

struct McTexture
{
	static DWORD		m_nKeyTx;

	DWORD				nKey;
	char				sFile[256];
	LPDIRECT3DTEXTURE9	pTx;
	D3DXIMAGE_INFO		pImg;

	McTexture()
	{
		memset(sFile, 0, sizeof(sFile));
		pTx	= NULL;

		nKey = ++m_nKeyTx;
	}

	~McTexture()
	{
		SAFE_RELEASE(	pTx	);
	}
};


struct McSound
{
	static DWORD	m_nKeySnd;
	
	DWORD			nKey;
	char			sFile[256];
	CSound*			pSnd;

	McSound()
	{
		memset(sFile, 0, sizeof(sFile));
		pSnd = NULL;

		nKey = ++m_nKeySnd;
	}

	~McSound()
	{
		SAFE_DELETE(	pSnd	);
	}
};



struct McFont
{
	static DWORD	m_nKeyFnt;
	
	DWORD			nKey;
	char			sName[64];
	ID3DXFont*		pFnt;
	LONG			lH;

	McFont()
	{
		memset(sName, 0, sizeof(sName));
		pFnt = NULL;
		lH = 0;

		nKey = ++m_nKeyFnt;
	}

	~McFont()
	{
		SAFE_RELEASE(	pFnt	);
	}
};

typedef std::vector<McTexture* >	lsPDTx;
typedef std::vector<McSound* >		lsMcSnd;
typedef std::vector<McFont* >		lsDxFnt;


class CMain : public CD3DApplication
{
public:
	ID3DXFont*		m_pD3DXFont;        // D3DX font 
	PDTX			m_pLoadingTx;
	D3DXIMAGE_INFO	m_pLoadingImg;
	
	CSoundManager*	m_pSndMn;			// DirectSound manager class
	CSound*			m_pSound;			// Bounce sound

public:
	BYTE			m_KeyCur[256];
	int				m_mouseX;
	int				m_mouseY;
	int				m_mouseZ;
	int				m_mouseEvnt;

	lsPDTx			m_vTx	;			// Texture
	lsMcSnd			m_vSnd	;			// Sound
	lsDxFnt			m_vFnt	;			// Font
	DWORD			m_dColor;


public:
	CMain();
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
	
	virtual HRESULT Init();
	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	virtual HRESULT Destroy();
	virtual HRESULT Render();
	virtual HRESULT FrameMove();
	
	HRESULT			RenderText();

public:
	virtual int		LuaCreateWindow();
	void			SetWindowTitle(char* sMsg);

	INT				m_bShowState;
};


extern CMain*		g_pApp;
extern HINSTANCE	g_hInst;

#endif

