// Implementation of the Utility Functions.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <d3d9.h>
#include <d3dx9.h>
#include <DxErr.h>

#include "_McType.h"
#include "McUtil.h"


static HANDLE	g_hCon;
static DWORD	g_dWritten;
static BOOL	g_bCon = 0;


void McUtil_ErrMsgBox(TCHAR *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)
		return;
	
//	MessageBox(NULL, s, "Err", MB_OK | MB_ICONERROR);

	if(g_bCon)
	{
		WriteConsole(g_hCon, s, strlen(s), &g_dWritten, NULL);
		WriteConsole(g_hCon, "\n", strlen("\n"), &g_dWritten, NULL);

		printf("%s\n", s);
	}
}



void McUtil_GetLastError(HWND hWnd)
{
	char	sMsg[2048];

	LPVOID lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM,
				  NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
				  (LPTSTR) &lpMsgBuf, 0, NULL);

	MessageBox(hWnd, (LPTSTR)lpMsgBuf, "GetLastError", MB_OK|MB_ICONERROR);

	if(g_bCon)
	{
		sprintf(sMsg, "%GetLastError: %s", (LPTSTR)lpMsgBuf);
		WriteConsole(g_hCon, sMsg, strlen(sMsg), &g_dWritten, NULL);
	}

	LocalFree(lpMsgBuf);
}



char* McUtil_GetSmallTime()
{
	static char tm_str[128 + 1];
	SYSTEMTIME st;

	GetLocalTime(&st);
	strcpy(tm_str,
		McUtil_Forming("'%04d-%02d-%02d\t'%02d:%02d:%02d.%03d",
		(INT)st.wYear, (INT)st.wMonth, (INT)st.wDay,
		(INT)st.wHour, (INT)st.wMinute, (INT)st.wSecond, (INT)st.wMilliseconds));

	return(tm_str);
}



void McUtil_OutputDebug(const char * format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	::OutputDebugString(s);
}




char*	McUtil_Forming(const char *fmt, ...)
{
#define FORMING_1CALL_STR_TOTAL 512
#define FORMING_RECALL_TOTAL 32
#define FORMING_BUF_TOTAL (FORMING_1CALL_STR_TOTAL * FORMING_RECALL_TOTAL)
	static char formingbuf[FORMING_BUF_TOTAL], formingfmt[FORMING_1CALL_STR_TOTAL + 1];
	static INT index_formingbuf;
	va_list arglist;
	char *strp;
	
	va_start(arglist, fmt);
	vsprintf(formingfmt, fmt, arglist);
	va_end(arglist);

	if (index_formingbuf + strlen(formingfmt) + 1 >= FORMING_BUF_TOTAL)
		index_formingbuf = 0;

	strp = formingbuf + index_formingbuf;

	strcpy(strp, formingfmt);

	index_formingbuf += strlen(formingfmt) + 1;

	return(strp);
}




void McUtil_GetDxError(HRESULT hr, char* pBufferPointer)
{
	char* s = (char*) malloc(2048);

	if(pBufferPointer)
	{
		sprintf(s
			,	"File:%s\n"
				"Error Line:%d\n"
				"Error Msg: %s\n"
				"Error Desc:%s\n"
				"Error Pointer: %s\n"
				,	__FILE__
				,	__LINE__
				,	DXGetErrorString(hr)
				,	DXGetErrorDescription(hr)
				,	pBufferPointer );
	}

	else
	{
		sprintf(s
			,	"File:%s\n"
				"Error Line:%d\n"
				"Error Msg: %s\n"
				"Error Desc:%s\n"
				,	__FILE__
				,	__LINE__
				,	DXGetErrorString(hr)
				,	DXGetErrorDescription(hr));
	
	}

	OutputDebugString( s );
	McUtil_ErrMsgBox(s);
	free(s);
}



// Texture Load
INT McUtil_TextureLoad(TCHAR * sFileName, void* pDevice, PDTX & texture, DWORD _color, D3DXIMAGE_INFO *pSrcInfo, DWORD Filter, DWORD MipFilter, D3DFORMAT d3dFormat)
{
	LPDIRECT3DDEVICE9 pdev = (LPDIRECT3DDEVICE9)pDevice;
	if ( FAILED(D3DXCreateTextureFromFileEx(
		pdev
		, sFileName
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat				// D3DFMT_UNKNOWN
		, D3DPOOL_MANAGED
		, Filter				// D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR
		, MipFilter				// D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR
		, _color
		, pSrcInfo
		, NULL
		, &texture
		)) )
	{
		texture = NULL;
		return -1;
	}
	
	return 1;
}




void	McUtil_SetConsole(BOOL bCon)
{
	g_bCon = bCon;

	if(g_bCon)
	{
		if(!g_hCon)
		{
			AllocConsole();
			g_hCon = GetStdHandle(STD_OUTPUT_HANDLE);
		}
	}

	else
	{
		CloseHandle(g_hCon);
		FreeConsole();
		g_hCon = 0;
	}
}

void McUtil_AllocConsole()
{
	if(!g_bCon)
		return;

	AllocConsole();
	g_hCon = GetStdHandle(STD_OUTPUT_HANDLE);
}


void	McUtil_SendConsole(TCHAR *s)
{
	if(g_bCon)
	{
		WriteConsole(g_hCon, s, strlen(s), &g_dWritten, NULL);
		printf(s);
	}
}
