// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)

#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "DxErr.lib")

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "dsound.lib")
#pragma comment(lib, "dxguid.lib")

#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif


#define _WIN32_WINNT			0x0400
#define DIRECTSOUND_VERSION		0x0800

#include <vector>


#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>

#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>

#include <d3d9.h>
#include <d3dx9.h>
#include <DxErr.h>
#include <dsound.h>

#include "_McType.h"
#include "McUtil.h"

#include "DXUtil.h"
#include "D3DUtil.h"
#include "dsutil.h"

#include "D3DEnum.h"
#include "D3DSettings.h"
#include "D3DApp.h"

#include "resource.h"

#include "LnLua.h"


#include "Main.h"



DWORD	McTexture::m_nKeyTx = 0;
DWORD	McSound::m_nKeySnd = 0;
DWORD	McFont::m_nKeyFnt	= 0;


CMain*		g_pApp  = NULL;
HINSTANCE	g_hInst = NULL;
CLnLua		m_pLua;


INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR pCmdLine, INT )
{
	CMain d3dApp;
	
	g_pApp  = &d3dApp;
	g_hInst = hInst;


	if(FAILED(m_pLua.Init(pCmdLine)))
		return -1;
	
	InitCommonControls();
	
	if( FAILED( d3dApp.Create( hInst ) ) )
	{
		m_pLua.Destroy();
		return 0;
	}
	
	d3dApp.Run();

	m_pLua.Destroy();

	return 1;
}


CMain::CMain()
{
	m_dScnX	= 100;
	m_dScnY	= 100;

	m_dScnW	= 800;
	m_dScnH	= 600;

	memset(m_KeyCur, 0, sizeof(m_KeyCur));

	m_mouseX =0;
	m_mouseY =0;
	m_mouseZ =0;
	m_mouseEvnt=0;

	m_dWindowStyle = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_VISIBLE;

	strcpy(m_sCls, "LuaApp" );
	
	m_bStartFull				= false;
	m_bShowCursorWhenFullscreen	= true;
	
	m_pD3DXFont					= NULL;
	m_pLoadingTx				= NULL;
	m_pSndMn					= NULL;
	m_pSound					= NULL;

	m_dColor = 0xFF006699;

	m_bShowState	= TRUE;

	srand( timeGetTime() );
}



HRESULT CMain::Init()
{
	HRESULT hr;

	hr=D3DXCreateTextureFromResourceEx(m_pd3dDevice
		, GetModuleHandle( NULL )
		, MAKEINTRESOURCE(IDB_LOADING)
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, D3DFMT_UNKNOWN
		, D3DPOOL_MANAGED
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, m_dColor
		, &m_pLoadingImg
		, NULL
		, &m_pLoadingTx);



	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, m_dColor, 1.0f, 0L );

	m_pd3dDevice->BeginScene();

		RECT rc={0,0, m_pLoadingImg.Width, m_pLoadingImg.Height};

		m_pd3dSprite->Begin(D3DXSPRITE_ALPHABLEND);
		m_pd3dSprite->Draw(m_pLoadingTx, &rc, NULL, NULL, D3DXCOLOR(1,1,1,1));
		m_pd3dSprite->End();

	m_pd3dDevice->EndScene();
	m_pd3dDevice->Present(0,0,0,0);


	D3DXFONT_DESC hFont = { 20, 0, FW_BOLD, 1, FALSE,
		HANGUL_CHARSET, OUT_DEFAULT_PRECIS,
		ANTIALIASED_QUALITY, FF_DONTCARE, "Arial" };


	if( FAILED( hr = D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return DXTRACE_ERR( "D3DXCreateFont", hr );
	
	m_pSndMn = new CSoundManager();
	
	if( FAILED( hr = m_pSndMn->Initialize( m_hWnd, DSSCL_PRIORITY ) ) )
		return DXTRACE_ERR( TEXT("m_pSndMn->Initialize"), hr );
	
	if( FAILED( hr = m_pSndMn->SetPrimaryBufferFormat( 2, 22050, 16 ) ) )
		return DXTRACE_ERR( TEXT("m_pSndMn->SetPrimaryBufferFormat"), hr );
	
	m_pSndMn->Create( &m_pSound, "Sound/bounce.wav", 0, GUID_NULL, 1 );


	
	if(FAILED(m_pLua.Lua_Init()))
		return -1;

	return S_OK;
}



HRESULT CMain::Destroy()
{
	int i=0;
	SAFE_RELEASE(	m_pD3DXFont	);
	
	if(FAILED(m_pLua.Lua_Destroy()))
		return -1;


	// ��Ʈ�� �����..
	int iSize = m_vFnt.size();

	for(i=0; i<iSize; ++i)
	{
		SAFE_DELETE(	m_vFnt[i]	);
	}

	m_vFnt.clear();


	// �ؽ��縦 �����
	iSize = m_vTx.size();

	for(i=0; i<iSize; ++i)
	{
		SAFE_DELETE(	m_vTx[i]	);
	}

	m_vTx.clear();


	// ���带 �����.
	iSize = m_vSnd.size();

	for(i=0; i<iSize; ++i)
	{
		SAFE_DELETE(	m_vSnd[i]	);
	}

	m_vSnd.clear();


	SAFE_DELETE( m_pSound );
	SAFE_DELETE( m_pSndMn );

	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pd3dDevice->SetRenderState( D3DRS_FOGENABLE, FALSE);
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE);


	m_pD3DXFont->OnResetDevice();

	int iSize = m_vFnt.size();

	for(int i=0; i<iSize; ++i)
	{
		m_vFnt[i]->pFnt->OnResetDevice();
	}
	
	
	return S_OK;
}


HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	int iSize = m_vFnt.size();

	for(int i=0; i<iSize; ++i)
	{
		m_vFnt[i]->pFnt->OnLostDevice();
	}
	
	return S_OK;
}


HRESULT CMain::FrameMove()
{
//	if( m_pSound )
//		m_pSound->Play();

	// Keyboard�� ���콺�� �����Ѵ�.
	POINT mouse;
	
	memset(m_KeyCur, 0, sizeof(m_KeyCur));
	::GetKeyboardState(m_KeyCur);

	for(int i=0; i<256; ++i)
		m_KeyCur[i] = (m_KeyCur[i] & 0x80) ? 1: 0;
	
	::GetCursorPos(&mouse);
	::ScreenToClient(m_hWnd, &mouse );
	
	m_mouseX = mouse.x;
	m_mouseY = mouse.y;

	
	if(FAILED(m_pLua.Lua_FrameMove()))
		return -1;

	
	return S_OK;
}





HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, m_dColor, 1.0f, 0L );
	
	if(FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	
	if(FAILED(m_pLua.Lua_Render()))
		return -1;
	

	if(m_bShowState)
		RenderText();

	m_pd3dDevice->EndScene();
	
	return S_OK;
}




HRESULT CMain::RenderText()
{
	D3DCOLOR fontColor		= D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH]	= TEXT("");
	RECT rc;

	sprintf( szMsg, "%s %s", m_strDeviceStats , m_strFrameStats );

	rc.top		= 1;
	rc.bottom	= rc.top + 20;
	rc.left		= 2;
	rc.right	= m_d3dsdBackBuffer.Width - 20;
	
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, fontColor );
	
	return S_OK;
}










LRESULT CMain::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	WPARAM wHi = HIWORD(wParam);
	WPARAM wLo = LOWORD(wParam);

	switch(uMsg)
	{
		case WM_MOUSEWHEEL:
		{
			m_mouseZ += short( wHi);

			return 0;
		}

		case WM_LBUTTONDOWN	:
		{
			return 0;
		}
		case WM_LBUTTONUP:
		{
			return 0;
		}
		case WM_LBUTTONDBLCLK:
		{
			return 0;
		}

		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				TCHAR strMsg[MAX_PATH];
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				RECT rc;
				GetClientRect( hWnd, &rc );
				DrawText( hDC, strMsg, -1, &rc, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, uMsg, wParam, lParam );
}


void CMain::SetWindowTitle(char* sMsg)
{
	SetWindowText(m_hWnd, sMsg);
}



int CMain::LuaCreateWindow()
{
	if(FAILED(m_pLua.Lua_CreateWindow()))
		return -1;

	return 1;
}
