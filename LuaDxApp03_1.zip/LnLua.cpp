// Implementation of the CLnLua class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>

#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>

#include <d3d9.h>
#include <d3dx9.h>
#include <DxErr.h>
#include <dsound.h>

#include "_McType.h"
#include "McUtil.h"

#include "DXUtil.h"
#include "D3DUtil.h"
#include "dsutil.h"

#include "D3DEnum.h"
#include "D3DSettings.h"
#include "D3DApp.h"

#include "LnLua.h"


#include "Main.h"


CLnLua::CLnLua()
{

}

CLnLua::~CLnLua()
{

}


INT CLnLua::Init(char* sFile)
{
	m_pLua = lua_open();
	
	// load Lua libraries
	luaL_openlibs(m_pLua);



	lua_register(m_pLua, "Mcl_CreateWindow"	,	Mcl_CreateWindow	);
	lua_register(m_pLua, "Mcl_Release"		,	Mcl_Release			);
	lua_register(m_pLua, "Mcl_Sleep"		,	Mcl_Sleep			);

	lua_register(m_pLua, "Mcl_KeyboardAll"	,	Mcl_KeyboardAll		);
	lua_register(m_pLua, "Mcl_KeyboardOne"	,	Mcl_KeyboardOne		);
	lua_register(m_pLua, "Mcl_MousePos"		,	Mcl_MousePos		);
	lua_register(m_pLua, "Mcl_MouseEvnt"	,	Mcl_MouseEvnt		);

	lua_register(m_pLua, "Mcl_SetWindowTitle"	,	Mcl_SetWindowTitle	);
	lua_register(m_pLua, "Mcl_MessageBox"		,	Mcl_MessageBox	);
	
	lua_register(m_pLua, "Mcl_GetScnSize"		,	Mcl_GetScnSize		);
	lua_register(m_pLua, "Mcl_GetWindowStyle"	,	Mcl_GetWindowStyle	);
	lua_register(m_pLua, "Mcl_SetWindowStyle"	,	Mcl_SetWindowStyle	);
	lua_register(m_pLua, "Mcl_ShowState"		,	Mcl_ShowState		);
	lua_register(m_pLua, "Mcl_ChangeMode"		,	Mcl_ChangeMode		);
	lua_register(m_pLua, "Mcl_SetClearColor"	,	Mcl_SetClearColor	);
	lua_register(m_pLua, "Mcl_GetClearColor"	,	Mcl_GetClearColor	);

	lua_register(m_pLua, "Mcl_TextureLoad"		,	Mcl_TextureLoad		);
	lua_register(m_pLua, "Mcl_TextureRelease"	,	Mcl_TextureRelease	);
	lua_register(m_pLua, "Mcl_TextureWidth"		,	Mcl_TextureWidth	);
	lua_register(m_pLua, "Mcl_TextureHeight"	,	Mcl_TextureHeight	);
	lua_register(m_pLua, "Mcl_TextureDraw"		,	Mcl_TextureDraw		);

	lua_register(m_pLua, "Mcl_SoundLoad"		,	Mcl_SoundLoad		);
	lua_register(m_pLua, "Mcl_SoundRelease"		,	Mcl_SoundRelease	);
	lua_register(m_pLua, "Mcl_SoundPlay"		,	Mcl_SoundPlay		);
	lua_register(m_pLua, "Mcl_SoundStop"		,	Mcl_SoundStop		);
	lua_register(m_pLua, "Mcl_SoundReset"		,	Mcl_SoundReset		);

	lua_register(m_pLua, "Mcl_FontLoad"		,	Mcl_FontLoad		);
	lua_register(m_pLua, "Mcl_FontRelease"	,	Mcl_FontRelease		);
	lua_register(m_pLua, "Mcl_FontDraw"		,	Mcl_FontDraw		);

	lua_register(m_pLua, "Mcl_GetTime"		,	Mcl_GetTime			);
	lua_register(m_pLua, "Mcl_Mod"			,	Mcl_Mod				);
	lua_register(m_pLua, "Mcl_Rand"			,	Mcl_Rand			);
	lua_register(m_pLua, "Mcl_SetConsole"	,	Mcl_SetConsole		);
	lua_register(m_pLua, "Mcl_SendConsole"	,	Mcl_SendConsole		);
	lua_register(m_pLua, "Mcl_CastInt"		,	Mcl_CastInt			);
	
	int hr =-1;

	if(sFile && strlen(sFile))
	{
		strcpy(m_sF, sFile);
		hr = luaL_dofile(m_pLua, m_sF);		
	}
	else
	{
		hr = luaL_dofile(m_pLua, "main.lua");
	}

	return 1;
}


void CLnLua::Destroy()
{
	lua_close(m_pLua);
}





int CLnLua::Lua_CreateWindow()
{
	int hr;

	lua_getglobal(m_pLua, "Lua_Create");
	
	if (lua_pcall(m_pLua, 0, 1, 0) != 0)
	{
		McUtil_ErrMsgBox(McUtil_Forming("Lua_Create Failed: %s",  lua_tostring(m_pLua, -1)));
		return -1;
	}

	// get the result
	hr = (int)lua_tonumber(m_pLua, -1);
	lua_pop(m_pLua, 1);

	if(FAILED(hr))
		return -1;

	return 1;
}





int CLnLua::Lua_Init()
{
	int hr=-1;
	// Lua�� �ִ� Lua_Init()�Լ��� ȣ��
	lua_getglobal(m_pLua, "Lua_Init");

	if (lua_pcall(m_pLua, 0, 1, 0) != 0)
	{
		McUtil_ErrMsgBox(McUtil_Forming("Lua_Init Failed: %s",  lua_tostring(m_pLua, -1)));
		return -1;
	}

	// get the result
	hr = (HRESULT)lua_tonumber(m_pLua, -1);
	lua_pop(m_pLua, 1);

	if(FAILED(hr))
		return -1;

	return 1;
}



int CLnLua::Lua_Destroy()
{
	int hr=-1;

	// ��ũ��Ʈ�� �ִ� Lua_Destroy() �Լ��� ȣ��
	lua_getglobal(m_pLua, "Lua_Destroy");
	
	if (lua_pcall(m_pLua, 0, 1, 0) != 0)
	{
		McUtil_ErrMsgBox(McUtil_Forming("Lua_Destroy Failed: %s",  lua_tostring(m_pLua, -1)));
		return -1;
	}

	hr = (int)lua_tonumber(m_pLua, -1);
	lua_pop(m_pLua, 1);

	printf("Engine Destroy\n");

	if(FAILED(hr))
		return -1;

	return 1;
}



int	CLnLua::Lua_FrameMove()
{
	int hr=-1;

	// ��� �Լ��� ȣ���Ѵ�.
	lua_getglobal(m_pLua, "Lua_FrameMove");

//	lua_call(m_pLua, 0, 1);

	if (lua_pcall(m_pLua, 0, 1, 0) != 0)
	{
		McUtil_ErrMsgBox(McUtil_Forming("Lua_FrameMove Failed: %s",  lua_tostring(m_pLua, -1)));
		return -1;
	}

	// get the result
	hr = (int)lua_tonumber(m_pLua, -1);
	lua_pop(m_pLua, 1);


	if(FAILED(hr))
		return -1;

	return 1;
}




int CLnLua::Lua_Render()
{
	int hr=-1;

	// ��� �Լ��� ȣ���Ѵ�.
	lua_getglobal(m_pLua, "Lua_Render");
	
	if (lua_pcall(m_pLua, 0, 1, 0) != 0)
	{
		McUtil_ErrMsgBox(McUtil_Forming("Lua_Render Failed: %s",  lua_tostring(m_pLua, -1)));
		return -1;
	}

	// get the result
	hr = (int)lua_tonumber(m_pLua, -1);
	lua_pop(m_pLua, 1);

	return 1;
}






static int Mcl_CreateWindow(lua_State *pLua)
{
	int hr=-1;

	// ��ũ��Ʈ�� �����͸� �޾Ƽ�..
	int n = lua_gettop(pLua);

	if(n<4)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	g_pApp->m_dScnX = (int)lua_tonumber(pLua, 1);
	g_pApp->m_dScnY = (int)lua_tonumber(pLua, 2);
	g_pApp->m_dScnW = (int)lua_tonumber(pLua, 3);
	g_pApp->m_dScnH = (int)lua_tonumber(pLua, 4);

	strcpy(g_pApp->m_sCls, lua_tostring(pLua, 5));

	g_pApp->m_bStartFull = (int)lua_tonumber(pLua, 6)? true : false;

	return 0;
}


static int Mcl_Release(lua_State *pLua)
{
//	printf("Lua Release\n");
	
	return 0;
}


static int Mcl_Sleep(lua_State *pLua)
{
	int n = lua_gettop(pLua);

	if(n<1)
		Sleep(1000);

	int nMilliSecond = (int)lua_tonumber(pLua, 1);
	
	Sleep(nMilliSecond);

	return 0;
}



static int Mcl_KeyboardAll(lua_State *pLua)
{
	for(int i=0; i<256; ++i)
		lua_pushnumber(pLua, g_pApp->m_KeyCur[i]);
	
	return 256;
}


static int Mcl_KeyboardOne(lua_State *pLua)
{
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		g_pApp->m_bShowState = FALSE;
		return 0;
	}

	int _nKey = (int)lua_tonumber(pLua, 1);

	lua_pushnumber(pLua, g_pApp->m_KeyCur[_nKey]);
	return 1;
}




static int Mcl_MousePos(lua_State *pLua)
{
	lua_pushnumber(pLua, g_pApp->m_mouseX);
	lua_pushnumber(pLua, g_pApp->m_mouseY);
	lua_pushnumber(pLua, g_pApp->m_mouseZ);

	return 3;
}


static int Mcl_MouseEvnt(lua_State *pLua)
{
	lua_pushnumber(pLua, g_pApp->m_KeyCur[VK_LBUTTON]);
	lua_pushnumber(pLua, g_pApp->m_KeyCur[VK_RBUTTON]);
	lua_pushnumber(pLua, g_pApp->m_KeyCur[VK_MBUTTON]);

	return 3;
}


static int Mcl_GetScnSize(lua_State *pLua)
{
	lua_pushnumber(pLua, g_pApp->m_dScnW);
	lua_pushnumber(pLua, g_pApp->m_dScnH);
	
	return 1;
}



static int Mcl_SetWindowTitle(lua_State *pLua)
{
	char sMsg[1024];

	int n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	memset(sMsg, 0, sizeof(sMsg));

	for(int i=1; i<=n; ++i)
	{
		char sRcv[32];
		memset(sRcv, 0, sizeof(sRcv));

		if (!lua_isnumber(pLua, i)) 
		{
			sprintf(sRcv, " %s", lua_tostring(pLua, i));
			strcat(sMsg, sRcv);
		}
		
		else
		{
			double fRcvNumber = lua_tonumber(pLua, i);
			sprintf(sRcv, " %6.3f", fRcvNumber);
			strcat(sMsg, sRcv);
		}
	}

	g_pApp->SetWindowTitle(sMsg);
	
	return 0;
}


static int Mcl_MessageBox(lua_State *pLua)
{
	char sMsg[1024];
	char sTitle[1024];

	int n = lua_gettop(pLua);

	if(n<1)
	{
		MessageBox(g_pApp->m_hWnd, NULL, NULL, 0);
		return 0;
	}

	if(n<2)
	{
		memset(sMsg, 0, sizeof(sMsg));
		sprintf(sMsg, "%s", lua_tostring(pLua, 1));
		MessageBox(g_pApp->m_hWnd, sMsg, NULL, 0);

		return 0;
	}

	if(n<3)
	{
		memset(sMsg, 0, sizeof(sMsg));
		memset(sTitle, 0, sizeof(sTitle));

		sprintf(sMsg, "%s", lua_tostring(pLua, 1));
		sprintf(sTitle, "%s", lua_tostring(pLua, 2));

		MessageBox(g_pApp->m_hWnd, sMsg, sTitle, 0);

		return 0;
	}

	if(n<4)
	{
		memset(sMsg, 0, sizeof(sMsg));
		memset(sTitle, 0, sizeof(sTitle));

		sprintf(sMsg, "%s", lua_tostring(pLua, 1));
		sprintf(sTitle, "%s", lua_tostring(pLua, 2));
		int uType = (int)lua_tonumber(pLua, 3);

		MessageBox(g_pApp->m_hWnd, sMsg, sTitle, uType);

		return 0;
	}
	
	return 0;
}


static int Mcl_SetWindowStyle(lua_State *pLua)
{
	return 0;
}

static int Mcl_GetWindowStyle(lua_State *pLua)
{
	lua_pushnumber(pLua, g_pApp->m_dWindowStyle);

	return 1;
}


static int	Mcl_ShowState(lua_State *pLua)
{
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		g_pApp->m_bShowState = FALSE;
		return 0;
	}

	g_pApp->m_bShowState = (INT)lua_tonumber(pLua, 1);
	return 0;
}


static int	Mcl_ChangeMode(lua_State *pLua)
{
	g_pApp->ToggleFullscreen();
	return 0;
}


static int	Mcl_SetClearColor(lua_State *pLua)
{
	int		n = lua_gettop(pLua);
	char	sColor[32];

	if(n<1)
	{
		g_pApp->m_bShowState = FALSE;
		return 0;
	}
	memset(sColor, 0, sizeof(sColor));
	strcpy(sColor, lua_tostring(pLua, 1));
	sscanf(sColor, "%x", &g_pApp->m_dColor);

	return 0;
}

static int	Mcl_GetClearColor(lua_State *pLua)
{
	lua_pushnumber(pLua, g_pApp->m_dColor);
	return 1;
}


// Texture
static int	Mcl_TextureLoad(lua_State *pLua)
{
	int		n = lua_gettop(pLua);
	char	sFile[512];
	char	sColor[32];
	DWORD	dc=0x00FFFFFF;

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	else if(n < 2)
	{
		memset(sFile, 0, sizeof(sFile));
		strcpy(sFile, lua_tostring(pLua, 1));
	}

	else if(n < 3)
	{
		memset(sFile, 0, sizeof(sFile));
		memset(sColor, 0, sizeof(sColor));
		strcpy(sFile, lua_tostring(pLua, 1));
		strcpy(sColor, lua_tostring(pLua, 2));
		
		sscanf(sColor, "%x", &dc);
	}

	else
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	

	PDTX			pTx	= NULL;
	D3DXIMAGE_INFO	pImg;

	if(FAILED(D3DXCreateTextureFromFileEx(
		g_pApp->m_pd3dDevice
		, sFile
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, D3DFMT_UNKNOWN
		, D3DPOOL_MANAGED
		, D3DX_FILTER_NONE
		, D3DX_FILTER_NONE
		, dc
		, &pImg
		, NULL
		, &pTx
		)) )
	{
		printf("Create Texture Failed: %s\n", sFile);
		pTx = NULL;

		lua_pushnumber(pLua, -1);
		return 1;
	}

	McTexture*	p = new McTexture;

	p->pTx = pTx;
	strcpy(p->sFile, sFile);
	memcpy(&p->pImg, &pImg, sizeof(D3DXIMAGE_INFO));

	g_pApp->m_vTx.push_back(p);

	// Key�� ���� �ش�.
	lua_pushnumber(pLua, p->nKey);

	return 1;
}




static int Mcl_TextureRelease(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = g_pApp->m_vTx.size();
	int	nIdx=-1;
	int i=0;

	for(i=0; i<iSize; ++i)
	{
		if(g_pApp->m_vTx[i]->nKey == _nKey)
		{
			nIdx = i;
			break;
		}
	}

	if(i>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}


	lsPDTx::iterator	it;

	it = g_pApp->m_vTx.begin() + nIdx;
	SAFE_DELETE(	g_pApp->m_vTx[nIdx]	);
	g_pApp->m_vTx.erase(it);

	iSize = g_pApp->m_vTx.size();

	// ���� �ִ� ����� �����ش�.
	lua_pushnumber(pLua, iSize);
	
	return 1;
}


static int Mcl_TextureWidth(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = g_pApp->m_vTx.size();
	int	nIdx=-1;
	int i=0;

	for(i=0; i<iSize; ++i)
	{
		if(g_pApp->m_vTx[i]->nKey == _nKey)
		{
			nIdx = i;
			break;
		}
	}

	if(i>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	lua_pushnumber(pLua, (int)g_pApp->m_vTx[nIdx]->pImg.Width);
	return 1;
}


static int Mcl_TextureHeight(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = g_pApp->m_vTx.size();
	int	nIdx=-1;
	int i=0;

	for(i=0; i<iSize; ++i)
	{
		if(g_pApp->m_vTx[i]->nKey == _nKey)
		{
			nIdx = i;
			break;
		}
	}

	if(i>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	lua_pushnumber(pLua, (int)g_pApp->m_vTx[nIdx]->pImg.Height);
	return 1;
}



static int Mcl_TextureDraw(lua_State *pLua)
{
	DWORD	_nKey;
	RECT	pRc;
	VEC3	pPos(0,0,0);
	VEC3*	pScaling = NULL;
	VEC3*	pRot= NULL;
	FLOAT	fAngle = 0;
	DWORD	dC=D3DXCOLOR(1,1,1,1);

	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	pRc.left	= (LONG)lua_tonumber(pLua, 2);
	pRc.top		= (LONG)lua_tonumber(pLua, 3);
	pRc.right	= (LONG)lua_tonumber(pLua, 4);
	pRc.bottom	= (LONG)lua_tonumber(pLua, 5);

	pPos.x		= (FLOAT)lua_tonumber(pLua, 6);
	pPos.y		= (FLOAT)lua_tonumber(pLua, 7);


	int iSize = g_pApp->m_vTx.size();
	int	nIdx=-1;
	int i=0;

	for(i=0; i<iSize; ++i)
	{
		if(g_pApp->m_vTx[i]->nKey == _nKey)
		{
			nIdx = i;
			break;
		}
	}

	if(i>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	PDTX		 pTx =  g_pApp->m_vTx[nIdx]->pTx;
	LPD3DXSPRITE pSp = g_pApp->m_pd3dSprite;

	//g_pApp->m_pd3dSprite->Draw(pTx, &pRc, pScaling, pRot, fAngle, &pPos, dC);

	pSp->Begin(D3DXSPRITE_ALPHABLEND);
	pSp->Draw(pTx, &pRc, NULL, &pPos, dC);
	pSp->End();

	return 0;
}



// sound
static int	Mcl_SoundLoad(lua_State *pLua)
{
	int		n = lua_gettop(pLua);
	char	sFile[512];

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}
	else if(n < 2)
	{
		memset(sFile, 0, sizeof(sFile));
		strcpy(sFile, lua_tostring(pLua, 1));
	}
	else
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}


	CSound* pSnd = NULL;
	g_pApp->m_pSndMn->Create( &pSnd, sFile, 0, GUID_NULL, 1 );

	McSound* p = new McSound;

	p->pSnd = pSnd;
	strcpy(p->sFile, sFile);

	g_pApp->m_vSnd.push_back(p);

	// Key�� ���� �ش�.
	lua_pushnumber(pLua, p->nKey);

	return 1;
}



static int Mcl_SoundRelease(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = g_pApp->m_vSnd.size();
	int	nIdx=-1;
	int i=0;

	for(i=0; i<iSize; ++i)
	{
		if(g_pApp->m_vSnd[i]->nKey == _nKey)
		{
			nIdx = i;
			break;
		}
	}

	if(i>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}


	lsMcSnd::iterator	it;

	it = g_pApp->m_vSnd.begin() + nIdx;
	SAFE_DELETE(	g_pApp->m_vSnd[nIdx]	);
	g_pApp->m_vSnd.erase(it);

	iSize = g_pApp->m_vSnd.size();

	// ���� �ִ� ����� �����ش�.
	lua_pushnumber(pLua, iSize);
	
	return 1;
}



static int Mcl_SoundPlay(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = g_pApp->m_vSnd.size();
	int	nIdx=-1;
	int i=0;

	for(i=0; i<iSize; ++i)
	{
		if(g_pApp->m_vSnd[i]->nKey == _nKey)
		{
			nIdx = i;
			break;
		}
	}

	if(i>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	lua_pushnumber(pLua, g_pApp->m_vSnd[nIdx]->pSnd->Play());
	return 1;
}



static int Mcl_SoundStop(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = g_pApp->m_vSnd.size();
	int	nIdx=-1;
	int i=0;

	for(i=0; i<iSize; ++i)
	{
		if(g_pApp->m_vSnd[i]->nKey == _nKey)
		{
			nIdx = i;
			break;
		}
	}

	if(i>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	lua_pushnumber(pLua, g_pApp->m_vSnd[nIdx]->pSnd->Stop());
	return 1;
}




static int Mcl_SoundReset(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = g_pApp->m_vSnd.size();
	int	nIdx=-1;
	int i=0;

	for(i=0; i<iSize; ++i)
	{
		if(g_pApp->m_vSnd[i]->nKey == _nKey)
		{
			nIdx = i;
			break;
		}
	}

	if(i>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	lua_pushnumber(pLua, g_pApp->m_vSnd[nIdx]->pSnd->Reset());
	return 1;
}







// Font
// Name, Height, Font Weight , Italic
static int	Mcl_FontLoad(lua_State *pLua)
{
	int		n = lua_gettop(pLua);
	char	sName[64];
	LONG	lH =10;
	LONG	lW =FW_NORMAL;
	BYTE	iL =0;


	if(n<3)
	{
		lua_pushnumber(pLua, -1);
//		MessageBox(0, 0, 0, 0);
		McUtil_ErrMsgBox("Font Load Error");
		return 1;
	}

	memset(sName, 0, sizeof(sName));
	strcpy(sName, lua_tostring(pLua, 1));
	lH = (DWORD)lua_tonumber(pLua, 2);
	lW = (BYTE)lua_tonumber(pLua, 3);
	iL = (BYTE)lua_tonumber(pLua, 4);
	

	if(0 == lW)
		lW = FW_THIN;
	else if(1 == lW)
		lW = FW_NORMAL;
	else 
		lW = FW_BOLD;

	D3DXFONT_DESC hFont = { lH, 0, lW, 1, iL,
		HANGUL_CHARSET, OUT_DEFAULT_PRECIS,
		ANTIALIASED_QUALITY, FF_DONTCARE, "" };

	strcpy(hFont.FaceName, sName);

	ID3DXFont*	pFnt;

	if( FAILED( D3DXCreateFontIndirect( g_pApp->m_pd3dDevice, &hFont, &pFnt ) ) )
	{
		printf("Create Font Failed: %s\n", sName);
		lua_pushnumber(pLua, -1);
		return 1;
	}

	McFont*	p = new McFont;

	p->pFnt = pFnt;
	p->lH	= lH;
	strcpy(p->sName, sName);
	

	g_pApp->m_vFnt.push_back(p);

	// Key�� ���� �ش�.
	lua_pushnumber(pLua, p->nKey);

	return 1;
}




static int Mcl_FontRelease(lua_State *pLua)
{
	DWORD	_nKey;
	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey = (DWORD)lua_tonumber(pLua, 1);

	int iSize = g_pApp->m_vFnt.size();
	int	nIdx=-1;
	int i=0;

	for(i=0; i<iSize; ++i)
	{
		if(g_pApp->m_vFnt[i]->nKey == _nKey)
		{
			nIdx = i;
			break;
		}
	}

	if(i>=iSize)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}


	lsDxFnt::iterator	it;

	it = g_pApp->m_vFnt.begin() + nIdx;
	SAFE_DELETE(	g_pApp->m_vFnt[nIdx]	);
	g_pApp->m_vFnt.erase(it);

	iSize = g_pApp->m_vFnt.size();

	// ���� �ִ� ����� �����ش�.
	lua_pushnumber(pLua, iSize);
	
	return 1;
}



static int Mcl_FontDraw(lua_State *pLua)
{
	char	sMsg[1024];
	DWORD	_nKey;
	RECT	pRc;
	
	DWORD	fontColor=D3DXCOLOR(1,1,1,1);
	char	sColor[32];

	int		n = lua_gettop(pLua);

	if(n<1)
	{
		lua_pushnumber(pLua, -1);
		return 1;
	}

	_nKey =		 (DWORD)lua_tonumber(pLua, 1);
	strcpy(sMsg,		lua_tostring(pLua, 2));
	pRc.left	= (LONG)lua_tonumber(pLua, 3);
	pRc.top		= (LONG)lua_tonumber(pLua, 4);
	
	strcpy(sColor, lua_tostring(pLua, 5));
	sscanf(sColor,"%x", &fontColor);

	int iSize = g_pApp->m_vFnt.size();
	int	nIdx=-1;
	int i=0;

	for(i=0; i<iSize; ++i)
	{
		if(g_pApp->m_vFnt[i]->nKey == _nKey)
		{
			nIdx = i;
			break;
		}
	}

	if(i>=iSize)
	{
//		MessageBox(0,0,0,0);
		McUtil_ErrMsgBox("Font Draw Error");
		lua_pushnumber(pLua, -1);
		return 1;
	}

	pRc.right	= pRc.left + (strlen(sMsg) +1) * g_pApp->m_vFnt[nIdx]->lH;
	pRc.bottom	= pRc.top + g_pApp->m_vFnt[nIdx]->lH + 2;

	ID3DXFont*	pFnt =  g_pApp->m_vFnt[nIdx]->pFnt;

	pFnt->DrawText(NULL, sMsg, -1, &pRc, 0, fontColor );

	return 0;
}



static int	Mcl_GetTime(lua_State *pLua)
{
	lua_pushnumber(pLua, g_pApp->m_fTimeCur);
	return 1;
}


static int	Mcl_Mod(lua_State *pLua)
{
	DWORD v1= (DWORD)lua_tonumber(pLua, 1);
	DWORD v2= (DWORD)lua_tonumber(pLua, 2);

	DWORD v3 = v1 %v2;
	
	lua_pushnumber(pLua, v3);

	return 1;
}



static int Mcl_Rand(lua_State *pLua)
{
	DWORD v1= (DWORD)lua_tonumber(pLua, 1);
	DWORD v3 = rand() %v1;
	
	lua_pushnumber(pLua, v3);

	return 1;
}


static int Mcl_SetConsole(lua_State *pLua)
{
	INT v1= (INT)lua_tonumber(pLua, 1);
	McUtil_SetConsole(v1);

	return 0;
}



static int Mcl_SendConsole(lua_State *pLua)
{
	char* v1= (char*)lua_tostring(pLua, 1);
	McUtil_SendConsole(v1);

	return 0;
}


static int	Mcl_CastInt(lua_State *pLua)
{
	INT v1= (INT)lua_tonumber(pLua, 1);

	lua_pushnumber(pLua, v1);

	return 1;
}