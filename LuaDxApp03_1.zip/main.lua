-- File: script.lua
-- Owner: Heesung Oh, copy reft
-- Date: 2005-03-08
-- Update:
-- LuaApp.exe File call script.lua. script.lua is main script file.

-- Reseverd Function.
-- Lua_Create()
-- Lua_Init()
-- Lua_Destroy()
-- Lua_FrameMove()
-- Lua_Render()


-- Mcl_ Functions.

-- Mcl_CreateWindow(position_x, position_y, "title", FullMode)			// Window Create		
-- Mcl_Release()														// Window Release
-- Mcl_Sleep( time_milli_sceond)										// Sleep

-- Mcl_KeyboardAll()													// keyboard All Key
-- Mcl_KeyboardOne( ascii )												// keyboard One Key
-- Mcl_MousePos()														// Mouse Position x, y, z
-- Mcl_MouseEvnt()														// Mouse Event Left, Right and M Button

-- Mcl_SetWindowTitle("title")											// Window Title
-- Mcl_MessageBox("Message", "Title", option)							// Window Box

-- Mcl_GetScnSize()														// ȭ���� ũ�⸦ ��������
-- Mcl_GetWindowStyle()												
-- Mcl_SetWindowStyle( style)											// window Style
-- Mcl_ShowState( Show )												// State ���̱� Show value is 1 or 0
-- Mcl_ChangeMode()														// Full <--> Window
-- Mcl_SetClearColor( Color )											// ���ȭ�� Ŭ���� ������ Color is ARGB color
-- Mcl_GetClearColor()													// ���ȭ�� Ŭ���� ���� ��������

-- Mcl_TextureLoad( "File_Name" )										// �̹��� ���� �ε� return texture index
-- Mcl_TextureRelease( index )											// �̹��� ���� ����
-- Mcl_TextureWidth( index )											// �̹��� ���� �ʺ�
-- Mcl_TextureHeight( index	)											// �̹��� ���� ����
-- Texture index, image region left, top, right, bottom
	-- screen position x, screen position y

-- Mcl_TextureDraw( texture_index
--					, Image_left
--					, Image_top
--					, Image_right
--					, Image_bottom
--					, screen_position_x
--					, screen_position_y	)								// �̹��� �׸���

-- Mcl_SoundLoad( "File_Name")											// ���� ���� �ε� return sound index
-- Mcl_SoundRelease( index )											// ���� ���� ����
-- Mcl_SoundPlay( index )												// ���� �÷���
-- Mcl_SoundStop( index )												// ���� Stop
-- Mcl_SoundReset( index )												// ���� Reset

-- Mcl_FontLoad("Font_Name", Height, Style:Thin,Normal,Bold, Italic?)	// ��Ʈ �ε� return font index
-- Mcl_FontRelease( index )												// ��Ʈ ����
-- Mcl_FontDraw( index, "String", screen_position_x, screen_position_y, "color")

-- Mcl Utilities
-- Mcl_GetTime()														// return time value after program start
-- Mcl_Mod(v1, v2)														// Modulate return v1 % v2
-- Mcl_Rand(v1)															// Randdom return rand()%v1
-- Mcl_SetConsole(v1)													// Console window. For error or message
-- Mcl_SendConsole(v1)													// Send String to colsole
-- Mcl_CastInt(v1)														// Casting Integer


-- Input script file load.
dofile("script/Input.lua")

-- Game loop script file load.
dofile("script/game.lua")


function Lua_Create()
	-- Using Console window
	Mcl_SetConsole(1)

	-- Window create. position x, position y, screen width, screen height, , title, fullmode?...
	hr = Mcl_CreateWindow(10, 10, 800, 600, "mackerel", 0)
	return hr
end


function Lua_Init()
	return GameInit()
end


function Lua_Destroy()
	return GameDestroy()
end


-- Data update
function Lua_FrameMove()
	UpdateInput()
	GameUpdate()
	return 1
	
end

function Lua_Render()
	return	GameRender()
end