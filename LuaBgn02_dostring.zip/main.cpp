

#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif


#include <stdio.h>
#include <string.h>

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>


lua_State* g_pL;


const char *ScriptString = 
{
	"--Scritp Application Function	\n"
	
	"function AppFunction1(x)		\n"
	"  return x * 2					\n"
	"end							\n"

	"function AppFunction2(x, y)	\n"
	"  return x * y					\n"
	"end							\n"
};

void main()
{
	printf("LUA String Script Load.\n\n");
	
	g_pL = lua_open();
	
	// load Lua libraries
	luaL_openlibs(g_pL);
	
		
	lua_dostring(g_pL, ScriptString);
	
	double x =11.0;
	double y =22.0;
	double z =.0;

	lua_getglobal(g_pL, "AppFunction1");
	lua_pushnumber(g_pL, x);

	lua_pcall(g_pL, 1, 1, 0);
		

	// Let's get the result from the stack
	int nIdx = lua_gettop(g_pL);

	z = lua_tonumber(g_pL, nIdx);
	printf("The result was: %lf\n", z);
		
	lua_pop(g_pL, 1);	// Clean-up the stack



	lua_getglobal(g_pL, "AppFunction2");
	lua_pushnumber(g_pL, x);
	lua_pushnumber(g_pL, y);

	lua_pcall(g_pL, 2, 1, 0);

	nIdx = lua_gettop(g_pL);
	z = lua_tonumber(g_pL, nIdx);
	printf("The result was: %lf\n", z);

	lua_pop(g_pL, 1);

	
	
	lua_gettop(g_pL);	// Verify the stack and clean-up the LUA state

	lua_close(g_pL);
}