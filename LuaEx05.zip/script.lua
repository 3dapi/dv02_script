-- Simple LUA Program


a = array.new(1000)
a[10] = 3.4         -- setarray
c= a[10]
print(c)

print("------------------------------")

b = vector3(1,2,3)

b.x = 30
b.y = 40
b.z = 50

print(b.x)
print(b.y)
print(b.z)

