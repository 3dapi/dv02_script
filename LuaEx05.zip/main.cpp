

#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>


struct NumArray
{
	int		size;
	double	values[1];
};


static int	Mcl_ArrNew(lua_State *L);
static int	Mcl_ArrSet(lua_State *L);
static int	Mcl_ArrGet(lua_State *L);
static int	Mcl_ArrSize(lua_State* L);
static int	LuaOpenLibArr(lua_State *L);


static NumArray* Mcl_checkArray(lua_State *L)
{
	void *ud = luaL_checkudata(L, 1, "LcLua.array");
	luaL_argcheck(L, ud != NULL, 1, "'array' expected");
	return (NumArray *)ud;
}

static int Mcl_ArrNew(lua_State *L)
{
	int n = luaL_checkint(L, 1);
	size_t nbytes = sizeof(NumArray) + (n - 1)*sizeof(double);
	
	// �޸𸮸� �����Ѵ�.
	NumArray *a = (NumArray *)lua_newuserdata(L, nbytes);
	
	luaL_getmetatable(L, "LcLua.array");
	lua_setmetatable(L, -2);
	a->size = n;
	return 1;  /* new userdatum is already on the stack */
}

static int Mcl_ArrSet(lua_State *L)
{
	NumArray *a = (NumArray *)lua_touserdata(L, 1);
	int index = luaL_checkint(L, 2);
	double value = luaL_checknumber(L, 3);
	
	luaL_argcheck(L, a != NULL, 1, "array expected");
	luaL_argcheck(L, 1 <= index && index <= a->size, 2, "index out of range");
	
	a->values[index-1] = value;
	return 0;
}

static int Mcl_ArrGet(lua_State *L)
{
	NumArray *a = (NumArray *)lua_touserdata(L, 1);
	int index = luaL_checkint(L, 2);
	
	luaL_argcheck(L, a != NULL, 1, "array expected");
	luaL_argcheck(L, 1 <= index && index <= a->size, 2, "index out of range");
	
	lua_pushnumber(L, a->values[index-1]);
	return 1;
}

static int Mcl_ArrSize(lua_State* L)
{
	NumArray *a = Mcl_checkArray(L);
	lua_pushnumber(L, a->size);
	return 1;
	
}

static const struct luaL_reg ArrLib [] =
{
	{"new"	,	Mcl_ArrNew},
	{"set"	,	Mcl_ArrSet},
	{"get"	,	Mcl_ArrGet},
	{"size"	,	Mcl_ArrSize},
	{NULL, NULL}
};



int LuaOpenLibArr(lua_State *L)
{
	luaL_newmetatable(L, "LcLua.array");
	luaL_openlib(L, "array", ArrLib, 0);
	
	// now the stack has the metatable at index 1 and
	// array at index -2
	// metatable is at index -3
	// "structA" is at index -4
	
	lua_pushstring(L, "__index");
	lua_pushstring(L, "get");
	lua_gettable(L, -3);  /* get array.get */
	lua_settable(L, -4);  /* metatable.__index = array.get */
	
	lua_pushstring(L, "__newindex");
	lua_pushstring(L, "set");
	lua_gettable(L, -3); /* get array.set */
	lua_settable(L, -4); /* metatable.__newindex = array.set */
	
	return 0;
}



typedef struct { double a[3]; } vector3;


struct CLuaVec3
{
	//Lua API.
	static int	New(lua_State*);
	static int	Set(lua_State*);
	static int	Get(lua_State*);
	static int	Open(lua_State*);
};


int	CLuaVec3::New(lua_State *L)
{
	int n = luaL_checkint(L, 1);
	int _cnt = lua_gettop(L);

	// �޸𸮸� �����Ѵ�.
	vector3* v = (vector3 *)lua_newuserdata(L, sizeof(vector3));

//	v=(vector3*)lua_touserdata(L,-1);
	
	if (_cnt>1)
	{
		v->a[0]=luaL_check_number(L,1);
		v->a[1]=luaL_check_number(L,2);
		v->a[2]=luaL_check_number(L,3);
	}
	else
		v->a[0] = v->a[1] = v->a[2] = 0;

	luaL_getmetatable(L, "LcLua.vectors");
	lua_setmetatable(L, -2);				// �̰� �߿��ϴ�. �̰��� ������ ��Ÿ ���̺��� ������ �ȵȴ�.

	return 1;	// new userdatum is already on the stack
}

int CLuaVec3::Set(lua_State *L)
{
	vector3 *v	=	(vector3 *)lua_touserdata(L, 1);
	const char* i=luaL_check_string(L,2);
	double t=luaL_check_number(L,3);
	
	switch (*i)	 /* lazy! */
	{
		case 'x': case 'r': v->a[0]=t; break;
		case 'y': case 'g': v->a[1]=t; break;
		case 'z': case 'b': v->a[2]=t; break;
		default: break;
	}
	
	return 0;
}


int CLuaVec3::Get(lua_State *L)
{
	vector3*	v = (vector3 *)lua_touserdata(L, 1);
	const char* i =luaL_check_string(L,2);
	
	switch (*i) /* lazy! */
	{
		case 'x': case 'r': lua_pushnumber(L,v->a[0]); break;
		case 'y': case 'g': lua_pushnumber(L,v->a[1]); break;
		case 'z': case 'b': lua_pushnumber(L,v->a[2]); break;
		default: lua_pushnumber(L,0.0); break;
	}
	
	return 1;
}


static const luaL_reg LuaVec3 [] =
{
	{"set",		CLuaVec3::Set},
	{"get",		CLuaVec3::Get},
	{NULL, NULL}
};



int CLuaVec3::Open(lua_State *L)
{
	lua_register(L, "vector3",	CLuaVec3::New);
	luaL_newmetatable(L, "LcLua.vectors");
	luaL_openlib(L, "vectors", LuaVec3, 0);
	
	// now the stack has the metatable at index 1 and
	// vector3 at index -2
	// metatable is at index -3
	// "structA" is at index -4
	
	lua_pushstring(L, "__index");
	lua_pushstring(L, "get");
	lua_gettable(L, -3);  /* get vector3.get */
	lua_settable(L, -4);  /* metatable.__index = vector3.get */
	
	lua_pushstring(L, "__newindex");
	lua_pushstring(L, "set");
	lua_gettable(L, -3); /* get vector3.set */
	lua_settable(L, -4); /* metatable.__newindex = vector3.set */
	
	return 0;
}


lua_State* g_pL;


void main()
{
	g_pL = lua_open();
	
	luaL_openlibs(g_pL);

	LuaOpenLibArr(g_pL);

	CLuaVec3::Open(g_pL);
	
	luaL_dofile(g_pL, "Script.lua");

	lua_close(g_pL);
}

