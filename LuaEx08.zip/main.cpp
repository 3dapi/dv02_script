/*
  Created by Fibergeek - fibergeek@codegurus.be

  You are free to use this code in any way you want.
  If you feel it was usefull to you, let me know, thanks...
*/


#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"	)	// Release Lua.lib
#else
	#pragma comment(lib, "Lua_.lib"	)	// Debug Lua.lib
#endif


#include <crtdbg.h>
#include <process.h>
#include <conio.h>
#include <windows.h>

#include "dialog.h"
#include "mylua.h"

volatile INT bAbortScript;     // 0 = running, 1 = normal close, 2 = script aborted because of close, 3 = script has exited with exit()
volatile HANDLE hCloseProgram; // an event handle
volatile HANDLE hThreadDone;   // an event handle

static int clrscr_glue(lua_State *L)
{
  // We need 0 parameters, no more, no less
  if(lua_gettop(L) != 0)
  {
    lua_pushstring(L, "clrscr: parameter mismatch");
    lua_error(L);
  }

  // Clear the console screen
  SMALL_RECT sr = {0, 0, 80 - 1, 25 - 1};
  CHAR_INFO  ci = {0, 7};
  COORD cs = {0, 25};
  ScrollConsoleScreenBuffer(GetStdHandle(STD_OUTPUT_HANDLE), &sr, NULL, cs, &ci);

  // And move the cursor to the upper-left
  COORD cp = {0, 0};
  SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cp);

  // No results
  return 0;
}

static int gotoxy_glue(lua_State *L)
{
  // We need 2 parameters, no more, no less
  if(lua_gettop(L) != 2)
  {
    lua_pushstring(L, "gotoxy: parameter mismatch");
    lua_error(L);
  }

  // Get the coordinates
  SHORT X = (SHORT) lua_tonumber(L, 1);
  SHORT Y = (SHORT) lua_tonumber(L, 2);

  // Verify the coordinates
  if((X < 0) || (X >= 80) || (Y < 0) || (Y >= 25))
  {
    lua_pushstring(L, "gotoxy: invalid position");
    lua_error(L);
  }

  // And change the position in the console
  COORD c = {X, Y};
  SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);

  // No results
  return 0;
}

static int getx_glue(lua_State *L)
{
  // We need 0 parameters, no more, no less
  if(lua_gettop(L) != 0)
  {
    lua_pushstring(L, "getx: parameter mismatch");
    lua_error(L);
  }

  // Get the cursor position
  CONSOLE_SCREEN_BUFFER_INFO csbi;
  GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);

  // Push the number on the stack
  lua_pushnumber(L, csbi.dwCursorPosition.X);

  // 1 result
  return 1;
}

static int gety_glue(lua_State *L)
{
  // We need 0 parameters, no more, no less
  if(lua_gettop(L) != 0)
  {
    lua_pushstring(L, "gety: parameter mismatch");
    lua_error(L);
  }

  // Get the cursor position
  CONSOLE_SCREEN_BUFFER_INFO csbi;
  GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);

  // Push the number on the stack
  lua_pushnumber(L, csbi.dwCursorPosition.Y);

  // 1 result
  return 1;
}

static int print_glue(lua_State *L)
{
  // Get the number of parameters
  int n = lua_gettop(L);
  for(int i = 1; i <= n; i ++)
  {
    const char *s = lua_tostring(L, i);
    cprintf("%s", s);
  }

  // No results
  return 0;
}

static int exit_glue(lua_State *L)
{
  // We need 1 or 0 parameters, no more
  if(lua_gettop(L) > 1)
  {
    lua_pushstring(L, "delay: parameter mismatch");
    lua_error(L);
  }

  // Indicate a clean exit
  // (set bAbortScript in order to let the hook function abort LUA's work)
  bAbortScript = 3;

  // No results
  return 0;
}

static int delay_glue(lua_State *L)
{
  // We need 1 parameter, no more, no less
  if(lua_gettop(L) != 1)
  {
    lua_pushstring(L, "delay: parameter mismatch");
    lua_error(L);
  }

  // Wait for X milliseconds
  // Or return immediatly if hCloseProgram is signaled
  DWORD Duration = (DWORD) lua_tonumber(L, 1);
  WaitForSingleObject(hCloseProgram, Duration);

  // No results
  return 0;
}

static int kbhit_glue(lua_State *L)
{
  // We need 0 parameters, no more, no less
  if(lua_gettop(L) != 0)
  {
    lua_pushstring(L, "kbhit: parameter mismatch");
    lua_error(L);
  }

  //
  lua_pushboolean(L, _kbhit());

  // 1 result
  return 1;
}

static void HookRoutine(lua_State *L, lua_Debug *ar)
{
  if(ar->event == LUA_HOOKLINE)
  {
    if(bAbortScript)
    {
      // Change the state to 2 to indicate a abort occurred
      if(bAbortScript == 1)
        bAbortScript = 2;

      // Ok, let's quit the program
      if(bAbortScript == 2)
        lua_pushstring(L, "HookRoutine: Abort requested!");
      else
        lua_pushstring(L, "HookRoutine: Clean Exit detected!");
      lua_error(L);
    }
  }
}

static BOOL WINAPI ConsoleHandlerRoutine(DWORD dwCtrlType)
{
  // Don't respond to Ctrl-C & Ctrl-Break
  if((dwCtrlType == CTRL_C_EVENT) || (dwCtrlType == CTRL_BREAK_EVENT))
    return FALSE;

  // We received a close event, raise an event and also tell the script to abort
  SetEvent(hCloseProgram);
  bAbortScript = 1;
  return TRUE;
}

static void ThreadRoutine(void *l)
{
  //
  lua_State *L = (lua_State *) l;

  //
  SetConsoleTitle("Script is executing...");

  // Set a hook for LUA_MASKLINE
  lua_sethook(L, HookRoutine, LUA_MASKLINE, 0);

  // Try to execute the script
  SetConsoleTitle("Script is executing...");

  // Execute the loaded command...
  // The function takes 0 parameters and will always not return a result
  if(lua_pcall(L, 0, 0, 0) == 0)
  {
    //
    SetConsoleTitle("Script has finished its job: idle...");
  }
  else
  {
    // There has only been a real error if the script wasn't aborted
    if(bAbortScript == 3)
      SetConsoleTitle("Script has been terminated explicitly");
    else if(bAbortScript != 2)
      SetConsoleTitle("Script execution error!");

    // There was an error!
    // Clean-up the stack
    const char *errmsg = lua_popstring(L);

    // Display the error message
    if(bAbortScript != 2 && bAbortScript != 3)
      MessageBox(HWND_DESKTOP, errmsg, "LUA Demo 3 - Error", MB_OK);
  }

  // We're finished
  SetEvent(hThreadDone);
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int)
{
  //
  const char *defaultscript = 
  {
    "-- This is the default script --\r\n"
    "\r\n"
    "print('row 1')\r\n"
    "gotoxy(40, 12)\r\n"
    "print('center')\r\n"
    "gotoxy(getx() - 6, gety() - 1)\r\n"
    "print('above the center')\r\n"
    "gotoxy(79, 24)\r\n"
    "delay(1500)\r\n"
    "gotoxy(30, 24)\r\n"
    "print('PRESS A KEY TO STOP THE SCRIPT')\r\n"
    "gotoxy(79, 24)\r\n"
    "\r\n"
    "while(not kbhit())\r\n"
    "do\r\n"
    "end\r\n"
    "\r\n"
    "clrscr()\r\n"
  };

  // Initialize LUA
  lua_State *L = lua_open();

  // Endless loop
  char *script = strdup(defaultscript);
  const char *errmsg = NULL;
  while(1)
  {
    // Let's first get the script we will execute
    if(DoDialog(hInstance, &script, errmsg) == IDCANCEL)
      return 0;

    // Load the script;
    if(lua_loadstring(L, script, "test function") == 0)
      break;

    // There was an error loading the script, display it
    errmsg = lua_popstring(L);
  }

  // Release the memory used for loading the script
  free(script);

  // Register our functions
  lua_register(L, "clrscr", clrscr_glue);
  lua_register(L, "gotoxy", gotoxy_glue);
  lua_register(L, "getx",   getx_glue);
  lua_register(L, "gety",   gety_glue);
  lua_register(L, "print",  print_glue);
  lua_register(L, "delay",  delay_glue);
  lua_register(L, "exit",   exit_glue);
  lua_register(L, "kbhit",  kbhit_glue);

  // Start our program
  bAbortScript  = 0;
  hCloseProgram = CreateEvent(NULL, TRUE, FALSE, NULL);
  hThreadDone   = CreateEvent(NULL, TRUE, FALSE, NULL);

  //
  COORD c = {80, 25};
  AllocConsole();
  SetConsoleScreenBufferSize(GetStdHandle(STD_OUTPUT_HANDLE), c);
  SetConsoleCtrlHandler(ConsoleHandlerRoutine, TRUE);

  // Ask the user how to execute...
  if(MessageBox(HWND_DESKTOP, "How do you want this program to run?\n\nYes = Use a thread\nNo = Don't use a thread (program will terminate when the script has finished!)", "LUA Demo 3", MB_YESNO) == IDYES)
  {
    // Start the thread
    _beginthread(ThreadRoutine, 0, (void *) L);

    // Let's loop forever until the user closes the program
    WaitForSingleObject(hCloseProgram, INFINITE);

    // Let's wait 1.5 seconds for the thread to end
    if(WaitForSingleObject(hThreadDone, 1500) == WAIT_TIMEOUT)
    {
      // We can't exit properly :(
      MessageBox(HWND_DESKTOP, "Warning:\tThe LUA script has blocked the system!\n\tThe program exit will not be a clean one... :-(", "LUA Demo 3", MB_OK);
      return -1;
    }
  }
  else
  {
    // Call the thread-routine from our main thread
    // NOTE: it will not run in a seperate thread this way!
    ThreadRoutine(L);
  }

  // Verify the stack and clean-up the LUA state
  _ASSERT(lua_gettop(L) == 0);
  lua_close(L);

  return 0;
}