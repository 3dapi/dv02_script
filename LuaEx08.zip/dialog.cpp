//
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


/*
  Created by Fibergeek - fibergeek@codegurus.be

  You are free to use this code in any way you want.
  If you feel it was usefull to you, let me know, thanks...
*/

#include "dialog.h"
#include "resource.h"

#include <stdio.h>

static char lastpath[MAX_PATH]       = "";
static unsigned long lastfilterindex = 0;

typedef struct MYDLGPARAM
{
  LPSTR *lpScript;
  LPCSTR errmsg;
} MYDLGPARAM;

static BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  switch(uMsg)
  {
    case WM_INITDIALOG:
    {
      //
      MYDLGPARAM *p = (MYDLGPARAM *) lParam;

      // Store the user-data (the pointer to our MYDLGPARAM structure)
      SetWindowLong(hwndDlg, DWL_USER, (LPARAM) p);

      // Set the initial script
      if(p->lpScript)
        SetDlgItemText(hwndDlg, IDC_EDIT, *p->lpScript);

      // Use a timer to display the error once the dialog has been displayed
      if(p->errmsg != NULL)
        SetTimer(hwndDlg, 1, 10, NULL);
      return TRUE;
    }
    case WM_TIMER:
    {
      // Only continue if the dialog has been displayed
      if(!IsWindowVisible(hwndDlg))
        return TRUE;

      // Destroy the timer, we don't need it anymore
      KillTimer(hwndDlg, wParam);

      //
      MYDLGPARAM *p = (MYDLGPARAM *) GetWindowLong(hwndDlg, DWL_USER);

      // Display the error message
      MessageBox(hwndDlg, p->errmsg, "LUA Demo 3 - Error", MB_OK);
      return TRUE;
    }
    case WM_COMMAND:
    {
      WORD wNotifyCode = HIWORD(wParam); // notification code 
      WORD wID         = LOWORD(wParam); // item, control, or accelerator identifier 
      HWND hwndCtl     = (HWND) lParam;  // handle of control 

      switch(wID)
      {
        case IDOK:
        {
          //
          MYDLGPARAM *p = (MYDLGPARAM *) GetWindowLong(hwndDlg, DWL_USER);

          // Free the old script
          if(*p->lpScript != NULL)
            free(*p->lpScript);

          // Get the new script
          DWORD l = GetWindowTextLength(GetDlgItem(hwndDlg, IDC_EDIT));
          *p->lpScript = (LPSTR) malloc(l + 1);
          if(*p->lpScript != NULL)
            GetDlgItemText(hwndDlg, IDC_EDIT, *p->lpScript, l + 1);

          // Close the dialog-box: OK
          EndDialog(hwndDlg, IDOK);
          return TRUE;
        }
        case IDCANCEL: 
        {
          // Close the dialog-box: Cancel
          EndDialog(hwndDlg, IDCANCEL);
          return TRUE;
        }
        case IDC_SAVE:
        {
          // Set up a structure used to get the filename
          OPENFILENAME ofn;
          ZeroMemory(&ofn, sizeof(ofn));
          ofn.Flags        = OFN_PATHMUSTEXIST;
          ofn.hInstance    = (HINSTANCE) GetWindowLong(hwndDlg, GWL_HINSTANCE);
          ofn.hwndOwner    = hwndDlg;
          ofn.lpstrDefExt  = NULL;
          ofn.lpstrFile    = lastpath;
          ofn.lpstrFilter  = "LUA script files (*.lua)\0*.lua\0All files (*.*)\0*.*\0";
          ofn.lStructSize  = sizeof(ofn);
          ofn.nFilterIndex = lastfilterindex;
          ofn.nMaxFile     = MAX_PATH;

          // Get the filename
          if(GetSaveFileName(&ofn))
          {
            // Add the default extension if it's needed & possible
            // And only if the "*.lua" has been selected as the filter
            // We're smart, we add "LUA" if the last letter of the filename is an upper one
            //              we add "lua" if the last letter isn't an upper one
            if(ofn.nFileExtension == 0 && ofn.nFilterIndex == 1)
              if(strlen(ofn.lpstrFile) + 4 < MAX_PATH)
                if(isupper(ofn.lpstrFile[strlen(ofn.lpstrFile) - 1]))
                  strcat(ofn.lpstrFile, ".LUA");
                else
                  strcat(ofn.lpstrFile, ".lua");

            // Let's get the contents from the script into memory
            DWORD l = GetWindowTextLength(GetDlgItem(hwndDlg, IDC_EDIT));
            LPSTR m = (LPSTR) malloc(l + 1);
            if(m != NULL)
            {
              // Get the contents
              GetDlgItemText(hwndDlg, IDC_EDIT, m, l + 1);

              // Create the file
              FILE *f = fopen(ofn.lpstrFile, "wb");
              if(f != NULL)
              {
                // Write the contents away
                if(fwrite(m, strlen(m), 1, f) == 1)
                  MessageBox(HWND_DESKTOP, "The file has been saved.", "LUA Demo 3", MB_OK);
                else
                  MessageBox(HWND_DESKTOP, "The file couldn't be written to!", "LUA Demo 3 - Error", MB_OK);

                // Close the file
                fclose(f);
              }
              else
                MessageBox(HWND_DESKTOP, "The file couldn't be created!", "LUA Demo 3 - Error", MB_OK);

              // Release the memory used
              free(m);
            }
            else
              MessageBox(HWND_DESKTOP, "The script is too big for this program!", "LUA Demo 3 - Error", MB_OK);

            // Let's remember the last filter index used
            // (we're being friendly to the user)
            lastfilterindex = ofn.nFilterIndex;
          }

          return TRUE;
        }
        case IDC_LOAD:
        {
          // Set up a structure used to get the filename
          OPENFILENAME ofn;
          ZeroMemory(&ofn, sizeof(ofn));
          ofn.Flags        = OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
          ofn.hInstance    = (HINSTANCE) GetWindowLong(hwndDlg, GWL_HINSTANCE);
          ofn.hwndOwner    = hwndDlg;
          ofn.lpstrDefExt  = NULL;
          ofn.lpstrFile    = lastpath;
          ofn.lpstrFilter  = "LUA script files (*.lua)\0*.lua\0All files (*.*)\0*.*\0";
          ofn.lStructSize  = sizeof(ofn);
          ofn.nFilterIndex = lastfilterindex;
          ofn.nMaxFile     = MAX_PATH;

          // Get the filename
          if(GetOpenFileName(&ofn))
          {
            // Open the file
            FILE *f = fopen(ofn.lpstrFile, "rb");
            if(f != NULL)
            {
              // Go to the end of the file (to determine the length)
              fseek(f, 0, SEEK_END);
              unsigned long l = ftell(f);
              fseek(f, 0, SEEK_SET);

              // Allocate memory for reading the script
              LPSTR m = (LPSTR) malloc(l + 1);
              if(m != NULL)
              {
                // Read the data
                if(fread(m, l, 1, f) == 1)
                {
                  // Set the contents
                  m[l] = '\0';
                  SetDlgItemText(hwndDlg, IDC_EDIT, m);
                }
                else
                  MessageBox(HWND_DESKTOP, "The file couldn't be read from!", "LUA Demo 3 - Error", MB_OK);

                // Release the temponary memory
                free(m);
              }
              else
                MessageBox(HWND_DESKTOP, "The file is too big for this program!", "LUA Demo 3 - Error", MB_OK);

              fclose(f);
            }
            else
              MessageBox(HWND_DESKTOP, "The file couldn't be opened!", "LUA Demo 3 - Error", MB_OK);

            // Let's remember the last filter index used
            // (we're being friendly to the user)
            lastfilterindex = ofn.nFilterIndex;
          }

          return TRUE;
        }
      }

      break;
    }
  }

  return FALSE;
}

UINT DoDialog(HINSTANCE hInstance, LPSTR *lpScript, LPCSTR errmsg)
{
  // Our user-data
  MYDLGPARAM p;
  p.lpScript = lpScript;
  p.errmsg   = errmsg;

  // Execute the dialog box
  UINT rv = DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_SCRIPTDIALOG), HWND_DESKTOP, DialogProc, (LPARAM) &p);

  return rv;
}