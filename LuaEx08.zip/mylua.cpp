/*
  Created by Fibergeek - fibergeek@codegurus.be

  You are free to use this code in any way you want.
  If you feel it was usefull to you, let me know, thanks...
*/

#include "mylua.h"
#include <string.h>

typedef struct luaMemFile
{
  const char *text;
  size_t size;
} luaMemFile;

static const char *readMemFile(lua_State *, void *ud, size_t *size)
{
  // Convert the ud pointer (UserData) to a pointer of our structure
  luaMemFile *luaMF = (luaMemFile *) ud;

  // Are we done?
  if(luaMF->size == 0)
    return NULL;

  // Read everything at once
  // And set size to zero to tell the next call we're done
  *size = luaMF->size;
  luaMF->size = 0;

  // Return a pointer to the readed text
  return luaMF->text;
}

LUA_API int lua_loadstring(lua_State *L, const char *data, const char *chunkname)
{
  luaMemFile luaMF;
  luaMF.text = data;
  luaMF.size = strlen(data);
  return lua_load(L, readMemFile, &luaMF, chunkname);
}
