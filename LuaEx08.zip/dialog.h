/*
  Created by Fibergeek - fibergeek@codegurus.be

  You are free to use this code in any way you want.
  If you feel it was usefull to you, let me know, thanks...
*/

#ifndef LUADEMO3_DIALOG_H
#define LUADEMO3_DIALOG_H

#include <windows.h>

UINT DoDialog(HINSTANCE hInstance, LPSTR *lpScript, LPCSTR errmsg = NULL);

#endif