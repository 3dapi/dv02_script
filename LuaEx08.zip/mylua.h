/*
  Created by Fibergeek - fibergeek@codegurus.be

  You are free to use this code in any way you want.
  If you feel it was usefull to you, let me know, thanks...
*/

#ifndef MYLUA_H
#define MYLUA_H

#include <lua/lua.h>


LUA_API int lua_loadstring(lua_State *L, const char *data, const char *chunkname);

inline LUA_API lua_Number lua_popnumber(lua_State *L)
{
  register lua_Number tmp = lua_tonumber(L, lua_gettop(L));
  lua_pop(L, 1);
  return tmp;
}

inline LUA_API const char *lua_popstring(lua_State *L)
{
  register const char *tmp = lua_tostring(L, lua_gettop(L));
  lua_pop(L, 1);
  return tmp;
}

#endif